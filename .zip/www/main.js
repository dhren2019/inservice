(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5 lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-controller_8.entry.js",
		"common",
		13
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-ios.entry.js",
		"common",
		14
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-md.entry.js",
		"common",
		15
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-ios.entry.js",
		"common",
		16
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-md.entry.js",
		"common",
		17
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-ios.entry.js",
		1,
		"common",
		18
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-md.entry.js",
		1,
		"common",
		19
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-ios.entry.js",
		"common",
		20
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-md.entry.js",
		"common",
		21
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-ios.entry.js",
		"common",
		22
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-md.entry.js",
		"common",
		23
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-ios.entry.js",
		0,
		"common",
		24
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-md.entry.js",
		0,
		"common",
		25
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-ios.entry.js",
		"common",
		26
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-md.entry.js",
		"common",
		27
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-ios.entry.js",
		"common",
		28
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-md.entry.js",
		"common",
		29
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-ios.entry.js",
		"common",
		30
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-md.entry.js",
		"common",
		31
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-ios.entry.js",
		"common",
		32
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-md.entry.js",
		"common",
		33
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-col_3.entry.js",
		34
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-ios.entry.js",
		"common",
		35
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-md.entry.js",
		"common",
		36
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-ios.entry.js",
		"common",
		37
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-md.entry.js",
		"common",
		38
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-img.entry.js",
		39
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-ios.entry.js",
		"common",
		40
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-md.entry.js",
		"common",
		41
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-ios.entry.js",
		"common",
		42
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-md.entry.js",
		"common",
		43
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-ios.entry.js",
		"common",
		44
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-md.entry.js",
		"common",
		45
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-ios.entry.js",
		"common",
		46
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-md.entry.js",
		"common",
		47
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-ios.entry.js",
		"common",
		48
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-md.entry.js",
		"common",
		49
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-ios.entry.js",
		0,
		"common",
		50
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-md.entry.js",
		0,
		"common",
		51
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-ios.entry.js",
		1,
		"common",
		52
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-md.entry.js",
		1,
		"common",
		53
	],
	"./ion-nav_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-nav_4.entry.js",
		1,
		"common",
		54
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-ios.entry.js",
		1,
		"common",
		55
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-md.entry.js",
		1,
		"common",
		56
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-ios.entry.js",
		"common",
		57
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-md.entry.js",
		"common",
		58
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-ios.entry.js",
		"common",
		59
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-md.entry.js",
		"common",
		60
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-ios.entry.js",
		"common",
		61
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-md.entry.js",
		"common",
		62
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-ios.entry.js",
		"common",
		63
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-md.entry.js",
		"common",
		64
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-ios.entry.js",
		"common",
		65
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-md.entry.js",
		"common",
		66
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-ripple-effect.entry.js",
		67
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-route_4.entry.js",
		"common",
		68
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-ios.entry.js",
		"common",
		69
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-md.entry.js",
		"common",
		70
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-ios.entry.js",
		"common",
		71
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-md.entry.js",
		"common",
		72
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-ios.entry.js",
		"common",
		73
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-md.entry.js",
		"common",
		74
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-ios.entry.js",
		"common",
		75
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-md.entry.js",
		"common",
		76
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-spinner.entry.js",
		"common",
		77
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-ios.entry.js",
		78
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-md.entry.js",
		79
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-ios.entry.js",
		"common",
		80
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-md.entry.js",
		"common",
		81
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab_2.entry.js",
		"common",
		10
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-text.entry.js",
		"common",
		82
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-ios.entry.js",
		"common",
		83
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-md.entry.js",
		"common",
		84
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-ios.entry.js",
		"common",
		85
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-md.entry.js",
		"common",
		86
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-ios.entry.js",
		"common",
		87
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-md.entry.js",
		"common",
		88
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-virtual-scroll.entry.js",
		89
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../pages/appoinments-list/appoinments-list.module": [
		"./src/app/pages/appoinments-list/appoinments-list.module.ts",
		"pages-appoinments-list-appoinments-list-module"
	],
	"../pages/home/home.module": [
		"./src/app/pages/home/home.module.ts",
		"pages-home-home-module"
	],
	"../pages/near-by/near-by.module": [
		"./src/app/pages/near-by/near-by.module.ts",
		"pages-near-by-near-by-module"
	],
	"../pages/notification/notification.module": [
		"./src/app/pages/notification/notification.module.ts",
		"pages-notification-notification-module"
	],
	"../pages/profile/profile.module": [
		"./src/app/pages/profile/profile.module.ts",
		"pages-profile-profile-module"
	],
	"./pages/book-appointment/book-appointment.module": [
		"./src/app/pages/book-appointment/book-appointment.module.ts",
		"pages-book-appointment-book-appointment-module"
	],
	"./pages/booking-detail/booking-detail.module": [
		"./src/app/pages/booking-detail/booking-detail.module.ts",
		"pages-booking-detail-booking-detail-module"
	],
	"./pages/forgot-password/forgot-password.module": [
		"./src/app/pages/forgot-password/forgot-password.module.ts",
		"pages-forgot-password-forgot-password-module"
	],
	"./pages/otpverification/otpverification.module": [
		"./src/app/pages/otpverification/otpverification.module.ts",
		"pages-otpverification-otpverification-module"
	],
	"./pages/phone-verification/phone-verification.module": [
		"./src/app/pages/phone-verification/phone-verification.module.ts",
		"pages-phone-verification-phone-verification-module"
	],
	"./pages/salon-detail/salon-detail.module": [
		"./src/app/pages/salon-detail/salon-detail.module.ts",
		"pages-salon-detail-salon-detail-module"
	],
	"./pages/select-service/select-service.module": [
		"./src/app/pages/select-service/select-service.module.ts",
		"pages-select-service-select-service-module"
	],
	"./pages/sign-in/sign-in.module": [
		"./src/app/pages/sign-in/sign-in.module.ts",
		"pages-sign-in-sign-in-module"
	],
	"./pages/sign-up/sign-up.module": [
		"./src/app/pages/sign-up/sign-up.module.ts",
		"pages-sign-up-sign-up-module"
	],
	"./pages/slider/slider.module": [
		"./src/app/pages/slider/slider.module.ts",
		"pages-slider-slider-module"
	],
	"./pages/starter/starter.module": [
		"./src/app/pages/starter/starter.module.ts",
		"pages-starter-starter-module"
	],
	"./tabs/tabs.module": [
		"./src/app/tabs/tabs.module.ts",
		"tabs-tabs-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    { path: '', redirectTo: 'starter', pathMatch: 'full' },
    { path: 'tabs', loadChildren: './tabs/tabs.module#TabsPageModule' },
    {
        path: 'starter',
        loadChildren: './pages/starter/starter.module#StarterPageModule'
    },
    {
        path: 'sign-in',
        loadChildren: './pages/sign-in/sign-in.module#SignInPageModule'
    },
    {
        path: 'sign-up',
        loadChildren: './pages/sign-up/sign-up.module#SignUpPageModule'
    },
    {
        path: 'forgot-password',
        loadChildren: './pages/forgot-password/forgot-password.module#ForgotPasswordPageModule'
    },
    {
        path: 'slider',
        loadChildren: './pages/slider/slider.module#SliderPageModule'
    },
    {
        path: 'phone-verification',
        loadChildren: './pages/phone-verification/phone-verification.module#PhoneVerificationPageModule'
    },
    {
        path: 'otpverification',
        loadChildren: './pages/otpverification/otpverification.module#OTPVerificationPageModule'
    },
    {
        path: 'book-appointment',
        loadChildren: './pages/book-appointment/book-appointment.module#BookAppointmentPageModule'
    },
    {
        path: 'select-service',
        loadChildren: './pages/select-service/select-service.module#SelectServicePageModule'
    },
    {
        path: 'booking-detail',
        loadChildren: './pages/booking-detail/booking-detail.module#BookingDetailPageModule'
    },
    {
        path: 'salon-detail',
        loadChildren: './pages/salon-detail/salon-detail.module#SalonDetailPageModule'
    }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, modalCtrl, router, toastController) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.modalCtrl = modalCtrl;
        this.router = router;
        this.toastController = toastController;
        this.lastTimeBackPress = 0;
        this.timePeriodToExit = 2000;
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleLightContent();
            _this.splashScreen.hide();
            _this.backButtonEvent();
        });
    };
    AppComponent.prototype.backButtonEvent = function () {
        var _this = this;
        this.platform.backButton.subscribe(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
            var element, error_1;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.modalCtrl.getTop()];
                    case 1:
                        element = _a.sent();
                        if (element) {
                            element.dismiss();
                            return [2 /*return*/];
                        }
                        return [3 /*break*/, 3];
                    case 2:
                        error_1 = _a.sent();
                        console.log(error_1);
                        return [3 /*break*/, 3];
                    case 3:
                        this.routerOutlets.forEach(function (outlet) {
                            if (outlet && outlet.canGoBack()) {
                                outlet.pop();
                            }
                            else if (_this.router.url === '/tabs/home' ||
                                _this.router.url === '/tabs/nearBy' ||
                                _this.router.url === '/tabs/profile' ||
                                _this.router.url === '/tabs/notification' ||
                                _this.router.url === '/tabs/appoinment' ||
                                _this.router.url === '/starter' ||
                                _this.router.url === '/sign-in') {
                                if (new Date().getTime() - _this.lastTimeBackPress <
                                    _this.timePeriodToExit) {
                                    navigator['app'].exitApp(); // work in ionic 4
                                }
                                else {
                                    _this.showToast();
                                    _this.lastTimeBackPress = new Date().getTime();
                                }
                            }
                        });
                        return [2 /*return*/];
                }
            });
        }); });
    };
    AppComponent.prototype.showToast = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: 'press back again to exit App.',
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonRouterOutlet"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["QueryList"])
    ], AppComponent.prototype, "routerOutlets", void 0);
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _pages_image_modal_image_modal_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/image-modal/image-modal.module */ "./src/app/pages/image-modal/image-modal.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _pages_filter_filter_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/filter/filter.page */ "./src/app/pages/filter/filter.page.ts");
/* harmony import */ var _pages_enable_location_enable_location_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/enable-location/enable-location.page */ "./src/app/pages/enable-location/enable-location.page.ts");
/* harmony import */ var _pages_share_share_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/share/share.page */ "./src/app/pages/share/share.page.ts");
/* harmony import */ var _pages_booking_successfully_booking_successfully_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/booking-successfully/booking-successfully.page */ "./src/app/pages/booking-successfully/booking-successfully.page.ts");
/* harmony import */ var _pages_code_send_modal_code_send_modal_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/code-send-modal/code-send-modal.page */ "./src/app/pages/code-send-modal/code-send-modal.page.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _pages_near_salon_list_near_salon_list_page__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./pages/near-salon-list/near-salon-list.page */ "./src/app/pages/near-salon-list/near-salon-list.page.ts");

















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_8__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_15__["AppComponent"],
                _pages_code_send_modal_code_send_modal_page__WEBPACK_IMPORTED_MODULE_7__["CodeSendModalPage"],
                _pages_booking_successfully_booking_successfully_page__WEBPACK_IMPORTED_MODULE_6__["BookingSuccessfullyPage"],
                _pages_near_salon_list_near_salon_list_page__WEBPACK_IMPORTED_MODULE_16__["NearSalonListPage"],
                _pages_share_share_page__WEBPACK_IMPORTED_MODULE_5__["SharePage"],
                _pages_enable_location_enable_location_page__WEBPACK_IMPORTED_MODULE_4__["EnableLocationPage"],
                _pages_filter_filter_page__WEBPACK_IMPORTED_MODULE_3__["FilterPage"]
            ],
            entryComponents: [
                _pages_code_send_modal_code_send_modal_page__WEBPACK_IMPORTED_MODULE_7__["CodeSendModalPage"],
                _pages_booking_successfully_booking_successfully_page__WEBPACK_IMPORTED_MODULE_6__["BookingSuccessfullyPage"],
                _pages_near_salon_list_near_salon_list_page__WEBPACK_IMPORTED_MODULE_16__["NearSalonListPage"],
                _pages_share_share_page__WEBPACK_IMPORTED_MODULE_5__["SharePage"],
                _pages_enable_location_enable_location_page__WEBPACK_IMPORTED_MODULE_4__["EnableLocationPage"],
                _pages_filter_filter_page__WEBPACK_IMPORTED_MODULE_3__["FilterPage"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_11__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_14__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _pages_image_modal_image_modal_module__WEBPACK_IMPORTED_MODULE_1__["ImageModalPageModule"]
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_13__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_12__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_10__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_15__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/pages/booking-successfully/booking-successfully.page.html":
/*!***************************************************************************!*\
  !*** ./src/app/pages/booking-successfully/booking-successfully.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div class=\"lock_circle\">\n    <ion-icon src=\"../../../assets/images/General/_ionicons_svg_md-checkmark.svg\" alt=\"\"></ion-icon>\n  </div>\n  <h3 class=\"title ion-text-center\">Your appointment booking <br> is successfully.</h3>\n  <p class=\"description ion-text-center\">You can view the appointment booking info <br> in the\n    <span>“Appointment”</span> section.</p>\n  <ion-button class=\"btn-done ion-text-capitalize\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\"\n    (click)=\"continueBooking()\">\n    Continue Booking\n  </ion-button>\n  <ion-button class=\"btn-go\" mode=\"md\" size=\"small\" expand=\"block\" fill=\"clear\" (click)=\"gotoAppoinment()\">\n    Go to appointment\n  </ion-button>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/booking-successfully/booking-successfully.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/pages/booking-successfully/booking-successfully.page.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content .lock_circle {\n  height: 70px;\n  width: 70px;\n  border: 4px solid var(--ion-color-orange);\n  border-radius: 50%;\n  padding: 8px 0px;\n  margin: 42px auto 0px;\n  text-align: center; }\n  ion-content .lock_circle ion-icon {\n    font-size: 48px;\n    color: var(--ion-color-orange); }\n  ion-content .title {\n  font-size: 20px;\n  font-family: 'tofini_bold';\n  margin-top: 30px; }\n  ion-content .description {\n  font-size: 14px;\n  font-family: 'tofini_regular';\n  color: var(--ion-color-lightGray);\n  margin-top: 15px;\n  line-height: 23px; }\n  ion-content .description span {\n    color: var(--ion-color-black);\n    font-family: 'tofini_medium'; }\n  ion-content .btn-done {\n  --color: var(--ion-color-white);\n  height: 44px;\n  margin: 22px 27px 0px 28px;\n  font-size: 16px;\n  --box-shadow: none;\n  font-family: 'tofini_regular';\n  --background: var(--ion-color-gradiant); }\n  ion-content .btn-go {\n  font-size: 14px;\n  font-family: 'tofini_regular';\n  --color: var(--ion-color-simpleDark);\n  --color-activated: var(--ion-color-simpleDark);\n  text-transform: initial;\n  margin-top: 20px;\n  margin-bottom: 16px;\n  --ripple-color: var(--ion-color-white); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYm9va2luZy1zdWNjZXNzZnVsbHkvRDpcXGlvbmljIDRcXEJvb2sgQSBQb2ludC9zcmNcXGFwcFxccGFnZXNcXGJvb2tpbmctc3VjY2Vzc2Z1bGx5XFxib29raW5nLXN1Y2Nlc3NmdWxseS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxZQUFZO0VBQ1osV0FBVztFQUNYLHlDQUF5QztFQUN6QyxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHFCQUFxQjtFQUNyQixrQkFBa0IsRUFBQTtFQVJ0QjtJQVdNLGVBQWU7SUFDZiw4QkFBOEIsRUFBQTtFQVpwQztFQWdCSSxlQUFlO0VBQ2YsMEJBQTBCO0VBQzFCLGdCQUFnQixFQUFBO0VBbEJwQjtFQXFCSSxlQUFlO0VBQ2YsNkJBQTZCO0VBQzdCLGlDQUFpQztFQUNqQyxnQkFBZ0I7RUFDaEIsaUJBQWlCLEVBQUE7RUF6QnJCO0lBMkJNLDZCQUE2QjtJQUM3Qiw0QkFBNEIsRUFBQTtFQTVCbEM7RUFnQ0ksK0JBQVE7RUFDUixZQUFZO0VBQ1osMEJBQTBCO0VBQzFCLGVBQWU7RUFDZixrQkFBYTtFQUNiLDZCQUE2QjtFQUM3Qix1Q0FBYSxFQUFBO0VBdENqQjtFQXlDSSxlQUFlO0VBQ2YsNkJBQTZCO0VBQzdCLG9DQUFRO0VBQ1IsOENBQWtCO0VBQ2xCLHVCQUF1QjtFQUN2QixnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLHNDQUFlLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ib29raW5nLXN1Y2Nlc3NmdWxseS9ib29raW5nLXN1Y2Nlc3NmdWxseS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLmxvY2tfY2lyY2xlIHtcclxuICAgIGhlaWdodDogNzBweDtcclxuICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgYm9yZGVyOiA0cHggc29saWQgdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBwYWRkaW5nOiA4cHggMHB4O1xyXG4gICAgbWFyZ2luOiA0MnB4IGF1dG8gMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgZm9udC1zaXplOiA0OHB4O1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC50aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9ib2xkJztcclxuICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgfVxyXG4gIC5kZXNjcmlwdGlvbiB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHRHcmF5KTtcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjNweDtcclxuICAgIHNwYW4ge1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWJsYWNrKTtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgIH1cclxuICB9XHJcbiAgLmJ0bi1kb25lIHtcclxuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICBtYXJnaW46IDIycHggMjdweCAwcHggMjhweDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZ3JhZGlhbnQpO1xyXG4gIH1cclxuICAuYnRuLWdvIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNpbXBsZURhcmspO1xyXG4gICAgLS1jb2xvci1hY3RpdmF0ZWQ6IHZhcigtLWlvbi1jb2xvci1zaW1wbGVEYXJrKTtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgICAtLXJpcHBsZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICB9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/booking-successfully/booking-successfully.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/booking-successfully/booking-successfully.page.ts ***!
  \*************************************************************************/
/*! exports provided: BookingSuccessfullyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingSuccessfullyPage", function() { return BookingSuccessfullyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var BookingSuccessfullyPage = /** @class */ (function () {
    function BookingSuccessfullyPage(modalController, navCrtl) {
        this.modalController = modalController;
        this.navCrtl = navCrtl;
    }
    BookingSuccessfullyPage.prototype.ngOnInit = function () { };
    BookingSuccessfullyPage.prototype.continueBooking = function () {
        this.modalController.dismiss();
        this.navCrtl.navigateRoot('salon-detail');
    };
    BookingSuccessfullyPage.prototype.gotoAppoinment = function () {
        this.modalController.dismiss();
        this.navCrtl.navigateRoot('tabs/profile');
    };
    BookingSuccessfullyPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-booking-successfully',
            template: __webpack_require__(/*! ./booking-successfully.page.html */ "./src/app/pages/booking-successfully/booking-successfully.page.html"),
            styles: [__webpack_require__(/*! ./booking-successfully.page.scss */ "./src/app/pages/booking-successfully/booking-successfully.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], BookingSuccessfullyPage);
    return BookingSuccessfullyPage;
}());



/***/ }),

/***/ "./src/app/pages/code-send-modal/code-send-modal.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/code-send-modal/code-send-modal.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div class=\"lock_circle\">\n    <img src=\"../../../assets/images/General/noun_passcode_975430.svg\" alt=\"\">\n  </div>\n  <h3 class=\"title ion-text-center\">Code has been sent to reset <br> a new password.</h3>\n  <p class=\"description ion-text-center\">You’ll shortly receive an email with a code <br> to setup a new password.</p>\n  <ion-button class=\"btn-done ion-text-capitalize\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\" (click)=\"done()\">\n    Done\n  </ion-button>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/code-send-modal/code-send-modal.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/code-send-modal/code-send-modal.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content .lock_circle {\n  height: 70px;\n  width: 70px;\n  border: 4px solid var(--ion-color-orange);\n  border-radius: 50%;\n  padding: 8px 0px;\n  margin: 42px auto 0px;\n  text-align: center; }\n  ion-content .lock_circle img {\n    width: 34px;\n    height: 43px; }\n  ion-content .title {\n  font-size: 20px;\n  font-family: 'tofini_bold';\n  margin-top: 30px; }\n  ion-content .description {\n  font-size: 14px;\n  font-family: 'tofini_regular';\n  color: var(--ion-color-lightGray);\n  margin-top: 25px;\n  line-height: 23px; }\n  ion-content .btn-done {\n  --color: var(--ion-color-white);\n  height: 44px;\n  margin: 36px 27px 40px 28px;\n  font-size: 16px;\n  --box-shadow: none;\n  font-family: 'tofini_regular';\n  --background: var(--ion-color-gradiant); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY29kZS1zZW5kLW1vZGFsL0Q6XFxpb25pYyA0XFxCb29rIEEgUG9pbnQvc3JjXFxhcHBcXHBhZ2VzXFxjb2RlLXNlbmQtbW9kYWxcXGNvZGUtc2VuZC1tb2RhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxZQUFZO0VBQ1osV0FBVztFQUNYLHlDQUF5QztFQUN6QyxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHFCQUFxQjtFQUNyQixrQkFBa0IsRUFBQTtFQVJ0QjtJQVdNLFdBQVc7SUFDWCxZQUFZLEVBQUE7RUFabEI7RUFnQkksZUFBZTtFQUNmLDBCQUEwQjtFQUMxQixnQkFBZ0IsRUFBQTtFQWxCcEI7RUFxQkksZUFBZTtFQUNmLDZCQUE2QjtFQUM3QixpQ0FBaUM7RUFDakMsZ0JBQWdCO0VBQ2hCLGlCQUFpQixFQUFBO0VBekJyQjtFQTRCSSwrQkFBUTtFQUNSLFlBQVk7RUFDWiwyQkFBMkI7RUFDM0IsZUFBZTtFQUNmLGtCQUFhO0VBQ2IsNkJBQTZCO0VBQzdCLHVDQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9jb2RlLXNlbmQtbW9kYWwvY29kZS1zZW5kLW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAubG9ja19jaXJjbGUge1xyXG4gICAgaGVpZ2h0OiA3MHB4O1xyXG4gICAgd2lkdGg6IDcwcHg7XHJcbiAgICBib3JkZXI6IDRweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHBhZGRpbmc6IDhweCAwcHg7XHJcbiAgICBtYXJnaW46IDQycHggYXV0byAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gICAgaW1nIHtcclxuICAgICAgd2lkdGg6IDM0cHg7XHJcbiAgICAgIGhlaWdodDogNDNweDtcclxuICAgIH1cclxuICB9XHJcbiAgLnRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX2JvbGQnO1xyXG4gICAgbWFyZ2luLXRvcDogMzBweDtcclxuICB9XHJcbiAgLmRlc2NyaXB0aW9uIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodEdyYXkpO1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyM3B4O1xyXG4gIH1cclxuICAuYnRuLWRvbmUge1xyXG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIG1hcmdpbjogMzZweCAyN3B4IDQwcHggMjhweDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZ3JhZGlhbnQpO1xyXG4gIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/code-send-modal/code-send-modal.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/code-send-modal/code-send-modal.page.ts ***!
  \***************************************************************/
/*! exports provided: CodeSendModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CodeSendModalPage", function() { return CodeSendModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var CodeSendModalPage = /** @class */ (function () {
    function CodeSendModalPage(modalCtrl, navCtrl) {
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
    }
    CodeSendModalPage.prototype.ngOnInit = function () { };
    CodeSendModalPage.prototype.done = function () {
        this.modalCtrl.dismiss();
        this.navCtrl.navigateRoot("/sign-in");
    };
    CodeSendModalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-code-send-modal",
            template: __webpack_require__(/*! ./code-send-modal.page.html */ "./src/app/pages/code-send-modal/code-send-modal.page.html"),
            styles: [__webpack_require__(/*! ./code-send-modal.page.scss */ "./src/app/pages/code-send-modal/code-send-modal.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], CodeSendModalPage);
    return CodeSendModalPage;
}());



/***/ }),

/***/ "./src/app/pages/enable-location/enable-location.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/enable-location/enable-location.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div class=\"lock_circle\">\n    <img src=\"../../../assets/images/near-by/ic_location.svg\" alt=\"\">\n  </div>\n  <h3 class=\"title ion-text-center\">Enable your Location</h3>\n  <p class=\"description ion-text-center\">Please allow to use your location to show <br> nearby services on the map.</p>\n  <ion-button class=\"btn-done ion-text-capitalize\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\" (click)=\"done()\">\n    Done\n  </ion-button>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/enable-location/enable-location.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/enable-location/enable-location.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content .lock_circle {\n  height: 70px;\n  width: 70px;\n  border: 4px solid var(--ion-color-orange);\n  border-radius: 50%;\n  padding: 12px 0px;\n  margin: 35px auto 0px;\n  text-align: center; }\n  ion-content .lock_circle img {\n    width: 28px;\n    height: 39px; }\n  ion-content .title {\n  font-size: 20px;\n  font-family: 'tofini_bold';\n  margin-top: 30px; }\n  ion-content .description {\n  font-size: 14px;\n  font-family: 'tofini_regular';\n  color: var(--ion-color-lightGray);\n  margin-top: 25px;\n  line-height: 23px; }\n  ion-content .btn-done {\n  --color: var(--ion-color-white);\n  height: 44px;\n  margin: 25px 27px 35px 28px;\n  font-size: 16px;\n  --box-shadow: none;\n  font-family: 'tofini_regular';\n  --background: var(--ion-color-gradiant); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZW5hYmxlLWxvY2F0aW9uL0Q6XFxpb25pYyA0XFxCb29rIEEgUG9pbnQvc3JjXFxhcHBcXHBhZ2VzXFxlbmFibGUtbG9jYXRpb25cXGVuYWJsZS1sb2NhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxZQUFZO0VBQ1osV0FBVztFQUNYLHlDQUF5QztFQUN6QyxrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLHFCQUFxQjtFQUNyQixrQkFBa0IsRUFBQTtFQVJ0QjtJQVdNLFdBQVc7SUFDWCxZQUFZLEVBQUE7RUFabEI7RUFnQkksZUFBZTtFQUNmLDBCQUEwQjtFQUMxQixnQkFBZ0IsRUFBQTtFQWxCcEI7RUFxQkksZUFBZTtFQUNmLDZCQUE2QjtFQUM3QixpQ0FBaUM7RUFDakMsZ0JBQWdCO0VBQ2hCLGlCQUFpQixFQUFBO0VBekJyQjtFQTRCSSwrQkFBUTtFQUNSLFlBQVk7RUFDWiwyQkFBMkI7RUFDM0IsZUFBZTtFQUNmLGtCQUFhO0VBQ2IsNkJBQTZCO0VBQzdCLHVDQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9lbmFibGUtbG9jYXRpb24vZW5hYmxlLWxvY2F0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAubG9ja19jaXJjbGUge1xyXG4gICAgaGVpZ2h0OiA3MHB4O1xyXG4gICAgd2lkdGg6IDcwcHg7XHJcbiAgICBib3JkZXI6IDRweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHBhZGRpbmc6IDEycHggMHB4O1xyXG4gICAgbWFyZ2luOiAzNXB4IGF1dG8gMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiAyOHB4O1xyXG4gICAgICBoZWlnaHQ6IDM5cHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC50aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9ib2xkJztcclxuICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgfVxyXG4gIC5kZXNjcmlwdGlvbiB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHRHcmF5KTtcclxuICAgIG1hcmdpbi10b3A6IDI1cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjNweDtcclxuICB9XHJcbiAgLmJ0bi1kb25lIHtcclxuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICBtYXJnaW46IDI1cHggMjdweCAzNXB4IDI4cHg7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWdyYWRpYW50KTtcclxuICB9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/enable-location/enable-location.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/enable-location/enable-location.page.ts ***!
  \***************************************************************/
/*! exports provided: EnableLocationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EnableLocationPage", function() { return EnableLocationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var EnableLocationPage = /** @class */ (function () {
    function EnableLocationPage(modalController) {
        this.modalController = modalController;
    }
    EnableLocationPage.prototype.ngOnInit = function () { };
    EnableLocationPage.prototype.done = function () {
        this.modalController.dismiss();
    };
    EnableLocationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-enable-location',
            template: __webpack_require__(/*! ./enable-location.page.html */ "./src/app/pages/enable-location/enable-location.page.html"),
            styles: [__webpack_require__(/*! ./enable-location.page.scss */ "./src/app/pages/enable-location/enable-location.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"]])
    ], EnableLocationPage);
    return EnableLocationPage;
}());



/***/ }),

/***/ "./src/app/pages/filter/filter.page.html":
/*!***********************************************!*\
  !*** ./src/app/pages/filter/filter.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" mode=\"md\">\n      <ion-button class=\"btn-header\" mode=\"md\" fill=\"clear\" text-capitalize (click)=\"cancel()\">\n        Cancel\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Filter</ion-title>\n    <ion-buttons slot=\"end\" mode=\"md\">\n      <ion-button class=\"btn-header\" mode=\"md\" fill=\"clear\" text-capitalize (click)=\"reset()\">\n        Reset\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"service-section\">\n    <h4 class=\"title\">Services</h4>\n    <div style=\"display: inline-block;\">\n      <div class=\"service\" [ngClass]=\"{'active': activeSerice==s}\" *ngFor=\"let s of serviceList\"\n        (click)=\"setService(s)\">\n        {{s}}\n      </div>\n    </div>\n  </div>\n  <div class=\"rating-section\">\n    <h4 class=\"title\">Rating</h4>\n    <ion-icon (click)=\"setRating(1)\" [ngClass]=\"ratingValue >= 1 ? 'yellow-star' :'gray-star'\"\n      src=\"../../../assets/images/General/_ionicons_svg_ios-star.svg\"></ion-icon>\n    <ion-icon (click)=\"setRating(2)\" [ngClass]=\"ratingValue >= 2 ? 'yellow-star' :'gray-star'\"\n      src=\"../../../assets/images/General/_ionicons_svg_ios-star.svg\"></ion-icon>\n    <ion-icon (click)=\"setRating(3)\" [ngClass]=\"ratingValue >= 3 ? 'yellow-star' :'gray-star'\"\n      src=\"../../../assets/images/General/_ionicons_svg_ios-star.svg\"></ion-icon>\n    <ion-icon (click)=\"setRating(4)\" [ngClass]=\"ratingValue >= 4 ? 'yellow-star' :'gray-star'\"\n      src=\"../../../assets/images/General/_ionicons_svg_ios-star.svg\"></ion-icon>\n    <ion-icon (click)=\"setRating(5)\" [ngClass]=\"ratingValue == 5 ? 'yellow-star' :'gray-star'\"\n      src=\"../../../assets/images/General/_ionicons_svg_ios-star.svg\">\n    </ion-icon>\n    <p class=\"count-rating\">{{ratingValue}}.0 Star</p>\n  </div>\n  <div class=\"gender-section\">\n    <h4 class=\"title\">Gender</h4>\n    <ion-radio-group [(ngModel)]=\"gender\">\n      <ion-row class=\"ion-no-padding\">\n        <ion-col class=\"ion-no-padding\">\n          <ion-item class=\"ion-no-padding\" lines=\"none\">\n            <ion-label>Man</ion-label>\n            <ion-radio slot=\"start\" mode=\"md\" value=\"Man\" checked></ion-radio>\n          </ion-item>\n        </ion-col>\n        <ion-col class=\"ion-no-padding\">\n          <ion-item class=\"ion-no-padding\" lines=\"none\">\n            <ion-label>Woman</ion-label>\n            <ion-radio slot=\"start\" mode=\"md\" value=\"Woman\"></ion-radio>\n          </ion-item>\n        </ion-col>\n        <ion-col class=\"ion-no-padding\">\n          <ion-item class=\"ion-no-padding\" lines=\"none\">\n            <ion-label>Other</ion-label>\n            <ion-radio slot=\"start\" mode=\"md\" value=\"Other\"></ion-radio>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n    </ion-radio-group>\n  </div>\n  <div class=\"distance-section\">\n    <h4 class=\"title\">Distance</h4>\n    <span class=\"km-label\">{{((distance.upper)-(distance.lower)).toFixed(1)}} km</span>\n    <ion-item lines=\"none\" class=\"ion-no-padding\">\n      <ion-range min=\"0\" max=\"10\" mode=\"md\" [(ngModel)]=\"distance\" dualKnobs=\"true\" snaps=\"false\" step=\"0.1\">\n      </ion-range>\n    </ion-item>\n  </div>\n  <div class=\"sort-section\">\n    <h4 class=\"title\">Sort by</h4>\n    <ion-list mode=\"md\" class=\"ion-no-padding\">\n      <ion-radio-group>\n        <ion-item lines=\"none\" [ngClass]=\"{'active': activeSortType=='Most Popular'}\" class=\"ion-no-padding\"\n          (click)=\"setSortType('Most Popular')\">\n          <ion-label>Most Popular</ion-label>\n          <ion-icon *ngIf=\"activeSortType=='Most Popular'\"\n            src=\"../../../assets/images/General/_ionicons_svg_ios-checkmark.svg\"></ion-icon>\n        </ion-item>\n\n        <ion-item lines=\"none\" [ngClass]=\"{'active': activeSortType=='Cost Low to High'}\" class=\"ion-no-padding active\"\n          (click)=\"setSortType('Cost Low to High')\">\n          <ion-label>Cost Low to High</ion-label>\n          <ion-icon *ngIf=\"activeSortType=='Cost Low to High'\"\n            src=\"../../../assets/images/General/_ionicons_svg_ios-checkmark.svg\"></ion-icon>\n        </ion-item>\n\n        <ion-item lines=\"none\" [ngClass]=\"{'active': activeSortType=='Cost High to Low'}\" class=\"ion-no-padding\"\n          (click)=\"setSortType('Cost High to Low')\">\n          <ion-label>Cost High to Low</ion-label>\n          <ion-icon *ngIf=\"activeSortType=='Cost High to Low'\"\n            src=\"../../../assets/images/General/_ionicons_svg_ios-checkmark.svg\"></ion-icon>\n        </ion-item>\n      </ion-radio-group>\n    </ion-list>\n  </div>\n  <div class=\"price-section\">\n    <h4 class=\"title\">Price</h4>\n    <ion-row class=\"ion-no-padding \">\n      <ion-col class=\"no-left-padding\">\n        <div class=\"price-type\" [ngClass]=\"{'active': activePrice==1}\" (click)=\"setPrice(1)\">$</div>\n      </ion-col>\n      <ion-col>\n        <div class=\"price-type\" [ngClass]=\"{'active': activePrice==2}\" (click)=\"setPrice(2)\">$$</div>\n      </ion-col>\n      <ion-col class=\"no-right-padding\">\n        <div class=\"price-type\" [ngClass]=\"{'active': activePrice==3}\" (click)=\"setPrice(3)\">$$$</div>\n      </ion-col>\n    </ion-row>\n  </div>\n  <ion-button class=\"btn-apply\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\" (click)=\"applyFilter()\">\n    Apply Filter\n  </ion-button>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/filter/filter.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pages/filter/filter.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: var(--ion-color-white-light);\n  border-bottom: 1px solid var(--ion-border-color); }\n\nion-header ion-title {\n  font-size: 16px;\n  font-family: 'tofini_medium';\n  text-align: center;\n  color: var(--ion-color-black); }\n\nion-header .btn-header {\n  font-size: 16px;\n  font-family: 'tofini_medium';\n  --color: var(--ion-color-orange); }\n\nion-content {\n  --padding-end: 16px;\n  --padding-start: 16px;\n  --padding-top: 23px; }\n\nion-content .title {\n    font-size: 16px;\n    margin-top: 0px;\n    font-family: 'tofini_bold'; }\n\nion-content .service-section {\n    padding-bottom: 25px; }\n\nion-content .service-section .service {\n      padding: 9px 17px 6px 16px;\n      border: 1px solid var(--ion-border-color);\n      width: -webkit-fit-content;\n      width: -moz-fit-content;\n      width: fit-content;\n      border-radius: 17px;\n      font-size: 15px;\n      font-family: 'tofini_regular';\n      margin-right: 10px;\n      margin-bottom: 10px;\n      display: inline-block; }\n\nion-content .service-section .active {\n      background-color: var(--ion-color-orange);\n      color: var(--ion-color-white);\n      border-color: var(--ion-color-orange); }\n\nion-content .rating-section {\n    padding-bottom: 15px; }\n\nion-content .rating-section ion-icon {\n      width: 32px;\n      height: 32px;\n      margin-right: 7px; }\n\nion-content .rating-section .yellow-star {\n      color: var(--ion-color-darkYellow); }\n\nion-content .rating-section .gray-star {\n      color: var(--ion-border-color); }\n\nion-content .rating-section .count-rating {\n      display: inline-block;\n      position: relative;\n      top: -7px;\n      left: 23px;\n      font-size: 14px;\n      font-family: 'tofini_regular';\n      color: var(--ion-color-lightGray); }\n\nion-content .gender-section {\n    padding-bottom: 25px; }\n\nion-content .gender-section .title {\n      margin-bottom: 0px; }\n\nion-content .gender-section ion-radio {\n      --border-width: 1px;\n      --color: var(--ion-color-orange);\n      --color-checked: var(--ion-color-orange);\n      margin-right: 11px; }\n\nion-content .gender-section ion-label {\n      font-size: 16px;\n      font-family: 'tofini_regular';\n      color: var(--ion-color-lightDark); }\n\nion-content .distance-section {\n    padding-bottom: 25px;\n    position: relative; }\n\nion-content .distance-section .title {\n      margin-bottom: 0px; }\n\nion-content .distance-section ion-item {\n      --min-height: 39px;\n      --inner-padding-end: 0px; }\n\nion-content .distance-section .km-label {\n      right: 0px;\n      position: absolute;\n      top: 10px;\n      z-index: 1000;\n      font-size: 14px;\n      font-family: 'tofini_regular';\n      color: var(--ion-color-lightGray); }\n\nion-content .distance-section ion-range {\n      --knob-size: 30px;\n      --bar-height: 4px;\n      --knob-background: var(--ion-color-orange);\n      --bar-background: #e4e4e4;\n      --bar-background-active: var(--ion-color-gradiant);\n      --bar-border-radius: 3px;\n      padding-top: 0px;\n      padding-bottom: 0px; }\n\nion-content .sort-section {\n    padding-bottom: 28px; }\n\nion-content .sort-section .title {\n      margin-bottom: 0px; }\n\nion-content .sort-section ion-item {\n      --inner-padding-end: 0px;\n      --min-height: 34px;\n      height: 34px;\n      font-size: 15px;\n      font-family: 'tofini_regular';\n      --color: var(--ion-color-lightDark); }\n\nion-content .sort-section ion-item ion-icon {\n        font-size: 36px;\n        color: var(--ion-color-orange); }\n\nion-content .sort-section .active {\n      --color: var(--ion-color-orange); }\n\nion-content .price-section .title {\n    margin-bottom: 6px; }\n\nion-content .price-section .price-type {\n    padding: 9px 0px 6px 0px;\n    border: 1px solid var(--ion-border-color);\n    width: 100%;\n    border-radius: 17px;\n    font-size: 15px;\n    text-align: center;\n    font-family: 'tofini_regular';\n    margin-right: 10px; }\n\nion-content .price-section .active {\n    color: var(--ion-color-white);\n    background: var(--ion-color-orange); }\n\nion-content .price-section .no-left-padding {\n    padding-left: 0px; }\n\nion-content .price-section .no-right-padding {\n    padding-right: 0px; }\n\nion-content .btn-apply {\n    --color: var(--ion-color-white);\n    height: 44px;\n    margin: 27px 8px 57px 8px;\n    font-size: 15px;\n    --box-shadow: none;\n    font-family: 'tofini_regular';\n    --background: var(--ion-color-gradiant);\n    text-transform: inherit; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZmlsdGVyL0Q6XFxpb25pYyA0XFxCb29rIEEgUG9pbnQvc3JjXFxhcHBcXHBhZ2VzXFxmaWx0ZXJcXGZpbHRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSwwQ0FBYTtFQUNiLGdEQUFnRCxFQUFBOztBQUhwRDtFQU9JLGVBQWU7RUFDZiw0QkFBNEI7RUFDNUIsa0JBQWtCO0VBQ2xCLDZCQUE2QixFQUFBOztBQVZqQztFQWFJLGVBQWU7RUFDZiw0QkFBNEI7RUFDNUIsZ0NBQVEsRUFBQTs7QUFHWjtFQUNFLG1CQUFjO0VBQ2QscUJBQWdCO0VBQ2hCLG1CQUFjLEVBQUE7O0FBSGhCO0lBS0ksZUFBZTtJQUNmLGVBQWU7SUFDZiwwQkFBMEIsRUFBQTs7QUFQOUI7SUFVSSxvQkFBb0IsRUFBQTs7QUFWeEI7TUFZTSwwQkFBMEI7TUFDMUIseUNBQXlDO01BQ3pDLDBCQUFrQjtNQUFsQix1QkFBa0I7TUFBbEIsa0JBQWtCO01BQ2xCLG1CQUFtQjtNQUNuQixlQUFlO01BQ2YsNkJBQTZCO01BQzdCLGtCQUFrQjtNQUNsQixtQkFBbUI7TUFDbkIscUJBQXFCLEVBQUE7O0FBcEIzQjtNQXVCTSx5Q0FBeUM7TUFDekMsNkJBQTZCO01BQzdCLHFDQUFxQyxFQUFBOztBQXpCM0M7SUE2Qkksb0JBQW9CLEVBQUE7O0FBN0J4QjtNQStCTSxXQUFXO01BQ1gsWUFBWTtNQUNaLGlCQUFpQixFQUFBOztBQWpDdkI7TUFvQ00sa0NBQWtDLEVBQUE7O0FBcEN4QztNQXVDTSw4QkFBOEIsRUFBQTs7QUF2Q3BDO01BMENNLHFCQUFxQjtNQUNyQixrQkFBa0I7TUFDbEIsU0FBUztNQUNULFVBQVU7TUFDVixlQUFlO01BQ2YsNkJBQTZCO01BQzdCLGlDQUFpQyxFQUFBOztBQWhEdkM7SUFvREksb0JBQW9CLEVBQUE7O0FBcER4QjtNQXNETSxrQkFBa0IsRUFBQTs7QUF0RHhCO01BeURNLG1CQUFlO01BQ2YsZ0NBQVE7TUFDUix3Q0FBZ0I7TUFDaEIsa0JBQWtCLEVBQUE7O0FBNUR4QjtNQStETSxlQUFlO01BQ2YsNkJBQTZCO01BQzdCLGlDQUFpQyxFQUFBOztBQWpFdkM7SUFxRUksb0JBQW9CO0lBQ3BCLGtCQUFrQixFQUFBOztBQXRFdEI7TUF3RU0sa0JBQWtCLEVBQUE7O0FBeEV4QjtNQTJFTSxrQkFBYTtNQUNiLHdCQUFvQixFQUFBOztBQTVFMUI7TUErRU0sVUFBVTtNQUNWLGtCQUFrQjtNQUNsQixTQUFTO01BQ1QsYUFBYTtNQUNiLGVBQWU7TUFDZiw2QkFBNkI7TUFDN0IsaUNBQWlDLEVBQUE7O0FBckZ2QztNQXdGTSxpQkFBWTtNQUNaLGlCQUFhO01BQ2IsMENBQWtCO01BQ2xCLHlCQUFpQjtNQUNqQixrREFBd0I7TUFDeEIsd0JBQW9CO01BQ3BCLGdCQUFnQjtNQUNoQixtQkFBbUIsRUFBQTs7QUEvRnpCO0lBbUdJLG9CQUFvQixFQUFBOztBQW5HeEI7TUFxR00sa0JBQWtCLEVBQUE7O0FBckd4QjtNQXdHTSx3QkFBb0I7TUFDcEIsa0JBQWE7TUFDYixZQUFZO01BQ1osZUFBZTtNQUNmLDZCQUE2QjtNQUM3QixtQ0FBUSxFQUFBOztBQTdHZDtRQWdIUSxlQUFlO1FBQ2YsOEJBQThCLEVBQUE7O0FBakh0QztNQXFITSxnQ0FBUSxFQUFBOztBQXJIZDtJQTBITSxrQkFBa0IsRUFBQTs7QUExSHhCO0lBNkhNLHdCQUF3QjtJQUN4Qix5Q0FBeUM7SUFDekMsV0FBVztJQUNYLG1CQUFtQjtJQUNuQixlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLDZCQUE2QjtJQUM3QixrQkFBa0IsRUFBQTs7QUFwSXhCO0lBdUlNLDZCQUE2QjtJQUM3QixtQ0FBbUMsRUFBQTs7QUF4SXpDO0lBMklNLGlCQUFpQixFQUFBOztBQTNJdkI7SUE4SU0sa0JBQWtCLEVBQUE7O0FBOUl4QjtJQWtKSSwrQkFBUTtJQUNSLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGtCQUFhO0lBQ2IsNkJBQTZCO0lBQzdCLHVDQUFhO0lBQ2IsdUJBQXVCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9maWx0ZXIvZmlsdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXdoaXRlLWxpZ2h0KTtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tYm9yZGVyLWNvbG9yKTtcclxuICB9XHJcblxyXG4gIGlvbi10aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9tZWRpdW0nO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjayk7XHJcbiAgfVxyXG4gIC5idG4taGVhZGVyIHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICB9XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xyXG4gIC0tcGFkZGluZy10b3A6IDIzcHg7XHJcbiAgLnRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX2JvbGQnO1xyXG4gIH1cclxuICAuc2VydmljZS1zZWN0aW9uIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAyNXB4O1xyXG4gICAgLnNlcnZpY2Uge1xyXG4gICAgICBwYWRkaW5nOiA5cHggMTdweCA2cHggMTZweDtcclxuICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWJvcmRlci1jb2xvcik7XHJcbiAgICAgIHdpZHRoOiBmaXQtY29udGVudDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMTdweDtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB9XHJcbiAgICAuYWN0aXZlIHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICAucmF0aW5nLXNlY3Rpb24ge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDE1cHg7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIHdpZHRoOiAzMnB4O1xyXG4gICAgICBoZWlnaHQ6IDMycHg7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogN3B4O1xyXG4gICAgfVxyXG4gICAgLnllbGxvdy1zdGFyIHtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrWWVsbG93KTtcclxuICAgIH1cclxuICAgIC5ncmF5LXN0YXIge1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWJvcmRlci1jb2xvcik7XHJcbiAgICB9XHJcbiAgICAuY291bnQtcmF0aW5nIHtcclxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIHRvcDogLTdweDtcclxuICAgICAgbGVmdDogMjNweDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodEdyYXkpO1xyXG4gICAgfVxyXG4gIH1cclxuICAuZ2VuZGVyLXNlY3Rpb24ge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDI1cHg7XHJcbiAgICAudGl0bGUge1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tcmFkaW8ge1xyXG4gICAgICAtLWJvcmRlci13aWR0aDogMXB4O1xyXG4gICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgICAgLS1jb2xvci1jaGVja2VkOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAxMXB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWxhYmVsIHtcclxuICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodERhcmspO1xyXG4gICAgfVxyXG4gIH1cclxuICAuZGlzdGFuY2Utc2VjdGlvbiB7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMjVweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC50aXRsZSB7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgIH1cclxuICAgIGlvbi1pdGVtIHtcclxuICAgICAgLS1taW4taGVpZ2h0OiAzOXB4O1xyXG4gICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgICB9XHJcbiAgICAua20tbGFiZWwge1xyXG4gICAgICByaWdodDogMHB4O1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIHRvcDogMTBweDtcclxuICAgICAgei1pbmRleDogMTAwMDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodEdyYXkpO1xyXG4gICAgfVxyXG4gICAgaW9uLXJhbmdlIHtcclxuICAgICAgLS1rbm9iLXNpemU6IDMwcHg7XHJcbiAgICAgIC0tYmFyLWhlaWdodDogNHB4O1xyXG4gICAgICAtLWtub2ItYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICAgIC0tYmFyLWJhY2tncm91bmQ6ICNlNGU0ZTQ7XHJcbiAgICAgIC0tYmFyLWJhY2tncm91bmQtYWN0aXZlOiB2YXIoLS1pb24tY29sb3ItZ3JhZGlhbnQpO1xyXG4gICAgICAtLWJhci1ib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICAgIHBhZGRpbmctdG9wOiAwcHg7XHJcbiAgICAgIHBhZGRpbmctYm90dG9tOiAwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5zb3J0LXNlY3Rpb24ge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDI4cHg7XHJcbiAgICAudGl0bGUge1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICB9XHJcbiAgICBpb24taXRlbSB7XHJcbiAgICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcclxuICAgICAgLS1taW4taGVpZ2h0OiAzNHB4O1xyXG4gICAgICBoZWlnaHQ6IDM0cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodERhcmspO1xyXG5cclxuICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMzZweDtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5hY3RpdmUge1xyXG4gICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgIH1cclxuICB9XHJcbiAgLnByaWNlLXNlY3Rpb24ge1xyXG4gICAgLnRpdGxlIHtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogNnB4O1xyXG4gICAgfVxyXG4gICAgLnByaWNlLXR5cGUge1xyXG4gICAgICBwYWRkaW5nOiA5cHggMHB4IDZweCAwcHg7XHJcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1ib3JkZXItY29sb3IpO1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMTdweDtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICB9XHJcbiAgICAuYWN0aXZlIHtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgfVxyXG4gICAgLm5vLWxlZnQtcGFkZGluZyB7XHJcbiAgICAgIHBhZGRpbmctbGVmdDogMHB4O1xyXG4gICAgfVxyXG4gICAgLm5vLXJpZ2h0LXBhZGRpbmcge1xyXG4gICAgICBwYWRkaW5nLXJpZ2h0OiAwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5idG4tYXBwbHkge1xyXG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIG1hcmdpbjogMjdweCA4cHggNTdweCA4cHg7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWdyYWRpYW50KTtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBpbmhlcml0O1xyXG4gIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/filter/filter.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/filter/filter.page.ts ***!
  \*********************************************/
/*! exports provided: FilterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterPage", function() { return FilterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var FilterPage = /** @class */ (function () {
    function FilterPage(navCtrl, modalCtrl) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.serviceList = [
            'Hairstyle',
            'Makeup',
            'Hair Coloring',
            'Spa',
            'Facial Makeup',
            'Trim & Saving'
        ];
        this.activeSerice = 'Facial Makeup';
        this.activeSortType = 'Most Popular';
        this.ratingValue = 3;
        this.gender = 'Woman';
        this.distance = { lower: 0, upper: 5 };
        this.activePrice = 2;
    }
    FilterPage.prototype.ngOnInit = function () { };
    FilterPage.prototype.cancel = function () {
        this.modalCtrl.dismiss();
    };
    FilterPage.prototype.reset = function () {
        this.modalCtrl.dismiss();
    };
    FilterPage.prototype.setRating = function (val) {
        this.ratingValue = val;
    };
    FilterPage.prototype.setService = function (service) {
        this.activeSerice = service;
    };
    FilterPage.prototype.setSortType = function (type) {
        this.activeSortType = type;
    };
    FilterPage.prototype.setPrice = function (type) {
        this.activePrice = type;
    };
    FilterPage.prototype.applyFilter = function () {
        this.modalCtrl.dismiss();
    };
    FilterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-filter',
            template: __webpack_require__(/*! ./filter.page.html */ "./src/app/pages/filter/filter.page.html"),
            styles: [__webpack_require__(/*! ./filter.page.scss */ "./src/app/pages/filter/filter.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"]])
    ], FilterPage);
    return FilterPage;
}());



/***/ }),

/***/ "./src/app/pages/image-modal/image-modal.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/image-modal/image-modal.module.ts ***!
  \*********************************************************/
/*! exports provided: ImageModalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageModalPageModule", function() { return ImageModalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _image_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./image-modal.page */ "./src/app/pages/image-modal/image-modal.page.ts");







var routes = [
    {
        path: '',
        component: _image_modal_page__WEBPACK_IMPORTED_MODULE_6__["ImageModalPage"]
    }
];
var ImageModalPageModule = /** @class */ (function () {
    function ImageModalPageModule() {
    }
    ImageModalPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_image_modal_page__WEBPACK_IMPORTED_MODULE_6__["ImageModalPage"]]
        })
    ], ImageModalPageModule);
    return ImageModalPageModule;
}());



/***/ }),

/***/ "./src/app/pages/image-modal/image-modal.page.html":
/*!*********************************************************!*\
  !*** ./src/app/pages/image-modal/image-modal.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content fullscreen>\n  <ion-item class=\"close-fake\" lines=\"none\" text-center>\n    <ion-button (click)=\"close()\" fill=\"clear\" color=\"light\">\n      <ion-icon name=\"close\" slot=\"start\"></ion-icon>\n      Back\n    </ion-button>\n\n    <ion-button (click)=\"zoom(true)\" fill=\"clear\" color=\"light\">\n      <ion-icon name=\"add\" slot=\"start\"></ion-icon>\n      in\n    </ion-button>\n\n    <ion-button (click)=\"zoom(false)\" fill=\"clear\" color=\"light\">\n      <ion-icon name=\"remove\" slot=\"start\"></ion-icon>\n      out\n    </ion-button>\n  </ion-item>\n\n  <ion-slides [options]=\"sliderOpts\" #slider>\n    <ion-slide *ngFor=\"let i of img\">\n      <div class=\"swiper-zoom-container\">\n        <img src=\"{{ i }}\" />\n      </div>\n    </ion-slide>\n  </ion-slides>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/image-modal/image-modal.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/image-modal/image-modal.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".close-fake {\n  --background: transparent;\n  margin-top: 40px; }\n  .close-fake ion-icon {\n    font-size: 2rem; }\n  ion-content {\n  --background: rgba(44, 39, 45, 0.84); }\n  ion-slides {\n  height: 80%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaW1hZ2UtbW9kYWwvRDpcXGlvbmljIDRcXEJvb2sgQSBQb2ludC9zcmNcXGFwcFxccGFnZXNcXGltYWdlLW1vZGFsXFxpbWFnZS1tb2RhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBYTtFQUliLGdCQUFnQixFQUFBO0VBTHBCO0lBR1EsZUFBZSxFQUFBO0VBS3ZCO0VBQ0ksb0NBQWEsRUFBQTtFQUdqQjtFQUNJLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ltYWdlLW1vZGFsL2ltYWdlLW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jbG9zZS1mYWtlIHtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAycmVtO1xyXG4gICAgfVxyXG4gICAgbWFyZ2luLXRvcDogNDBweDtcclxufVxyXG4gXHJcbmlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiYSg0NCwgMzksIDQ1LCAwLjg0KTtcclxufVxyXG4gXHJcbmlvbi1zbGlkZXMge1xyXG4gICAgaGVpZ2h0OiA4MCU7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/image-modal/image-modal.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/image-modal/image-modal.page.ts ***!
  \*******************************************************/
/*! exports provided: ImageModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageModalPage", function() { return ImageModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var ImageModalPage = /** @class */ (function () {
    function ImageModalPage(navParams, modalController) {
        var _this = this;
        this.navParams = navParams;
        this.modalController = modalController;
        this.img = [];
        this.sliderOpts = {
            zoom: {
                maxRatio: 5
            }
        };
        setTimeout(function () {
            _this.slider.nativeElement.slideTo(_this.defaultOpen);
        }, 100);
    }
    ImageModalPage.prototype.ngOnInit = function () {
        this.img = this.navParams.get('img');
        this.defaultOpen = this.navParams.get('index');
    };
    ImageModalPage.prototype.zoom = function (zoomIn) {
        var zoom = this.slider.nativeElement.swiper.zoom;
        if (zoomIn) {
            zoom.in();
        }
        else {
            zoom.out();
        }
    };
    ImageModalPage.prototype.close = function () {
        this.modalController.dismiss();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('slider', { read: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], ImageModalPage.prototype, "slider", void 0);
    ImageModalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-image-modal',
            template: __webpack_require__(/*! ./image-modal.page.html */ "./src/app/pages/image-modal/image-modal.page.html"),
            styles: [__webpack_require__(/*! ./image-modal.page.scss */ "./src/app/pages/image-modal/image-modal.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], ImageModalPage);
    return ImageModalPage;
}());



/***/ }),

/***/ "./src/app/pages/near-salon-list/near-salon-list.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/near-salon-list/near-salon-list.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <div class=\"line\"></div>\n    <h4 class=\"title\">Salon Nearby</h4>\n    <p class=\"count-label\">Found <span>320 place</span> near <span>San Francisco</span></p>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item lines=\"none\" class=\"ion-no-padding\" *ngFor=\"let salon of salonList\">\n    <ion-thumbnail slot=\"start\">\n      <img [src]=\"salon.image\">\n    </ion-thumbnail>\n    <ion-label>\n      <h5 class=\"salon-name\">{{salon.name}} <span class=\"distance ion-float-right\">\n          <ion-icon src=\"../../../assets/images/General/ic_location.svg\">\n          </ion-icon>{{salon.distance}}\n        </span></h5>\n      <p class=\"salon-address\">{{salon.address}}</p>\n      <p class=\"salon-start\"><img src=\"../../../assets/images/General/ic_star.svg\" alt=\"\"> {{salon.star}}</p>\n      <p class=\"salon-time\">{{salon.time}}</p>\n      <ion-button mode=\"md\" class=\"btn-book\" size=\"small\" (click)=\"viewSalonDetauil()\">Book</ion-button>\n    </ion-label>\n  </ion-item>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/near-salon-list/near-salon-list.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/near-salon-list/near-salon-list.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  padding-left: 16px; }\n\nion-header .line {\n  margin: 5px auto 0px auto;\n  width: 54px;\n  height: 4px;\n  border-radius: 4px;\n  background-color: #cccccc; }\n\nion-header .title {\n  font-size: 18px;\n  font-family: 'tofini_bold';\n  color: var(--ion-color-black);\n  margin-bottom: 4px; }\n\nion-header .count-label {\n  font-size: 12px;\n  color: var(--ion-color-simpleDark);\n  margin: 0px;\n  font-family: 'tofini_regular'; }\n\nion-header .count-label span {\n    color: var(--ion-color-black); }\n\nion-content {\n  --padding-start: 16px; }\n\nion-content ion-item {\n    border-bottom: 2px solid #dbdbdb; }\n\nion-content ion-item ion-thumbnail {\n      width: 100px;\n      height: 83px; }\n\nion-content ion-item ion-thumbnail img {\n        border-radius: 10px; }\n\nion-content ion-item .salon-name {\n      font-size: 16px;\n      font-family: 'tofini_medium';\n      color: var(--ion-color-black); }\n\nion-content ion-item .salon-name .distance {\n        font-size: 12px;\n        margin-top: 5px;\n        font-family: 'tofini_regular';\n        color: var(--ion-color-simpleDark); }\n\nion-content ion-item .salon-name .distance ion-icon {\n          margin-bottom: -1px;\n          margin-right: 3px; }\n\nion-content ion-item .salon-address {\n      font-size: 12px;\n      font-family: 'tofini_regular';\n      color: var(--ion-color-lightGray);\n      margin: 0px;\n      line-height: 14px; }\n\nion-content ion-item .salon-start {\n      font-size: 13px;\n      font-family: 'tofini_medium';\n      margin: 0px;\n      color: var(--ion-color-lightGray); }\n\nion-content ion-item .salon-time {\n      color: var(--ion-color-orange);\n      margin-top: 6px;\n      font-family: 'tofini_regular';\n      font-size: 13px; }\n\nion-content ion-item .btn-book {\n      text-transform: initial;\n      --border-radius: 17px;\n      --padding-start: 19px;\n      --padding-end: 16px;\n      font-size: 15px;\n      font-family: 'tofini_medium';\n      position: absolute;\n      bottom: 10px;\n      right: 16px;\n      margin: 0px;\n      --box-shadow: none; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbmVhci1zYWxvbi1saXN0L0Q6XFxpb25pYyA0XFxCb29rIEEgUG9pbnQvc3JjXFxhcHBcXHBhZ2VzXFxuZWFyLXNhbG9uLWxpc3RcXG5lYXItc2Fsb24tbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxrQkFBa0IsRUFBQTs7QUFGdEI7RUFNSSx5QkFBeUI7RUFDekIsV0FBVztFQUNYLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIseUJBQXlCLEVBQUE7O0FBVjdCO0VBYUksZUFBZTtFQUNmLDBCQUEwQjtFQUMxQiw2QkFBNkI7RUFDN0Isa0JBQWtCLEVBQUE7O0FBaEJ0QjtFQW1CSSxlQUFlO0VBQ2Ysa0NBQWtDO0VBQ2xDLFdBQVc7RUFDWCw2QkFBNkIsRUFBQTs7QUF0QmpDO0lBd0JNLDZCQUE2QixFQUFBOztBQUluQztFQUNFLHFCQUFnQixFQUFBOztBQURsQjtJQUdJLGdDQUFnQyxFQUFBOztBQUhwQztNQUtNLFlBQVk7TUFDWixZQUFZLEVBQUE7O0FBTmxCO1FBUVEsbUJBQW1CLEVBQUE7O0FBUjNCO01BYU0sZUFBZTtNQUNmLDRCQUE0QjtNQUM1Qiw2QkFBNkIsRUFBQTs7QUFmbkM7UUFxQlEsZUFBZTtRQUNmLGVBQWU7UUFDZiw2QkFBNkI7UUFDN0Isa0NBQWtDLEVBQUE7O0FBeEIxQztVQWtCVSxtQkFBbUI7VUFDbkIsaUJBQWlCLEVBQUE7O0FBbkIzQjtNQTRCTSxlQUFlO01BQ2YsNkJBQTZCO01BQzdCLGlDQUFpQztNQUNqQyxXQUFXO01BQ1gsaUJBQWlCLEVBQUE7O0FBaEN2QjtNQW1DTSxlQUFlO01BQ2YsNEJBQTRCO01BQzVCLFdBQVc7TUFDWCxpQ0FBaUMsRUFBQTs7QUF0Q3ZDO01BeUNNLDhCQUE4QjtNQUM5QixlQUFlO01BQ2YsNkJBQTZCO01BQzdCLGVBQWUsRUFBQTs7QUE1Q3JCO01BK0NNLHVCQUF1QjtNQUN2QixxQkFBZ0I7TUFDaEIscUJBQWdCO01BQ2hCLG1CQUFjO01BQ2QsZUFBZTtNQUNmLDRCQUE0QjtNQUM1QixrQkFBa0I7TUFDbEIsWUFBWTtNQUNaLFdBQVc7TUFDWCxXQUFXO01BQ1gsa0JBQWEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL25lYXItc2Fsb24tbGlzdC9uZWFyLXNhbG9uLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgaW9uLXRvb2xiYXIge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xyXG4gIH1cclxuXHJcbiAgLmxpbmUge1xyXG4gICAgbWFyZ2luOiA1cHggYXV0byAwcHggYXV0bztcclxuICAgIHdpZHRoOiA1NHB4O1xyXG4gICAgaGVpZ2h0OiA0cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjY2NjY2NjO1xyXG4gIH1cclxuICAudGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfYm9sZCc7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWJsYWNrKTtcclxuICAgIG1hcmdpbi1ib3R0b206IDRweDtcclxuICB9XHJcbiAgLmNvdW50LWxhYmVsIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2ltcGxlRGFyayk7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgc3BhbiB7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xyXG4gIGlvbi1pdGVtIHtcclxuICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjZGJkYmRiO1xyXG4gICAgaW9uLXRodW1ibmFpbCB7XHJcbiAgICAgIHdpZHRoOiAxMDBweDtcclxuICAgICAgaGVpZ2h0OiA4M3B4O1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuc2Fsb24tbmFtZSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjayk7XHJcbiAgICAgIC5kaXN0YW5jZSB7XHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogLTFweDtcclxuICAgICAgICAgIG1hcmdpbi1yaWdodDogM3B4O1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2ltcGxlRGFyayk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5zYWxvbi1hZGRyZXNzIHtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodEdyYXkpO1xyXG4gICAgICBtYXJnaW46IDBweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDE0cHg7XHJcbiAgICB9XHJcbiAgICAuc2Fsb24tc3RhcnQge1xyXG4gICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICAgIG1hcmdpbjogMHB4O1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0R3JheSk7XHJcbiAgICB9XHJcbiAgICAuc2Fsb24tdGltZSB7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgICAgbWFyZ2luLXRvcDogNnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgfVxyXG4gICAgLmJ0bi1ib29rIHtcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XHJcbiAgICAgIC0tYm9yZGVyLXJhZGl1czogMTdweDtcclxuICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxOXB4O1xyXG4gICAgICAtLXBhZGRpbmctZW5kOiAxNnB4O1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgYm90dG9tOiAxMHB4O1xyXG4gICAgICByaWdodDogMTZweDtcclxuICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/near-salon-list/near-salon-list.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/near-salon-list/near-salon-list.page.ts ***!
  \***************************************************************/
/*! exports provided: NearSalonListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NearSalonListPage", function() { return NearSalonListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var NearSalonListPage = /** @class */ (function () {
    function NearSalonListPage(modalController, navCtrl) {
        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.salonList = [
            {
                name: "RedBox Barber",
                image: "../../../assets/images/General/Rectangle.png",
                address: "288 McClure Court, Arkansas",
                distance: "1.2 km",
                star: "3.5",
                time: "8:30 am - 9:00pm"
            },
            {
                name: "Beauty Plus Spa",
                image: "../../../assets/images/General/Rectangle.png",
                address: "34 McClure Court, Arkansas",
                distance: "3.0 km",
                star: "4.0",
                time: "8:30 am - 9:00pm"
            },
            {
                name: "Looks Unisex Salon",
                image: "../../../assets/images/General/Rectangle.png",
                address: "85 McClure Court, Arkansas",
                distance: "4.0 km",
                star: "3.5",
                time: "9:00 am - 8:00pm"
            }
        ];
    }
    NearSalonListPage.prototype.ngOnInit = function () { };
    NearSalonListPage.prototype.viewSalonDetauil = function () {
        this.modalController.dismiss();
        this.navCtrl.navigateForward("/salon-detail");
    };
    NearSalonListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-near-salon-list",
            template: __webpack_require__(/*! ./near-salon-list.page.html */ "./src/app/pages/near-salon-list/near-salon-list.page.html"),
            styles: [__webpack_require__(/*! ./near-salon-list.page.scss */ "./src/app/pages/near-salon-list/near-salon-list.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], NearSalonListPage);
    return NearSalonListPage;
}());



/***/ }),

/***/ "./src/app/pages/share/share.page.html":
/*!*********************************************!*\
  !*** ./src/app/pages/share/share.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-title>Share to</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row class=\"ion-no-padding\">\n    <ion-col size=\"4\" class=\"ion-no-padding ion-text-center\">\n      <img class=\"share-option-img\" src=\"../../../assets/images/share/contact.png\" alt=\"\">\n      <p class=\"type-label\">Friends</p>\n    </ion-col>\n    <ion-col size=\"4\" class=\"ion-no-padding ion-text-center\">\n      <img class=\"share-option-img\" src=\"../../../assets/images/share/facebook.png\" alt=\"\">\n      <p class=\"type-label\">Facebook</p>\n    </ion-col>\n    <ion-col size=\"4\" class=\"ion-no-padding ion-text-center\">\n      <img class=\"share-option-img\" src=\"../../../assets/images/share/messanger.png\" alt=\"\">\n      <p class=\"type-label\">Messenger</p>\n    </ion-col>\n  </ion-row>\n  <ion-row class=\"ion-no-padding\">\n    <ion-col size=\"4\" class=\"ion-no-padding ion-text-center\">\n      <img class=\"share-option-img\" src=\"../../../assets/images/share/message.png\" alt=\"\">\n      <p class=\"type-label\">Message</p>\n    </ion-col>\n    <ion-col size=\"4\" class=\"ion-no-padding ion-text-center\">\n      <img class=\"share-option-img\" src=\"../../../assets/images/share/email.png\" alt=\"\">\n      <p class=\"type-label\">Email</p>\n    </ion-col>\n    <ion-col size=\"4\" class=\"ion-no-padding ion-text-center\">\n      <img class=\"share-option-img\" src=\"../../../assets/images/share/pintrest.png\" alt=\"\">\n      <p class=\"type-label\">Pinterest</p>\n    </ion-col>\n  </ion-row>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/share/share.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/share/share.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header {\n  border-bottom: 1px solid var(--ion-border-color); }\n  ion-header ion-title {\n    font-size: 16px;\n    font-family: 'tofini_medium';\n    text-align: center;\n    color: var(--ion-color-black); }\n  ion-content {\n  --padding-top: 10px; }\n  ion-content ion-row {\n    padding: 0px 20px; }\n  ion-content .share-option-img {\n    height: 56px;\n    width: 56px;\n    border-radius: 50%;\n    margin-top: 16px; }\n  ion-content .type-label {\n    font-size: 13px;\n    font-family: 'tofini_medium';\n    margin-top: 3px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2hhcmUvRDpcXGlvbmljIDRcXEJvb2sgQSBQb2ludC9zcmNcXGFwcFxccGFnZXNcXHNoYXJlXFxzaGFyZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnREFBZ0QsRUFBQTtFQURsRDtJQUdJLGVBQWU7SUFDZiw0QkFBNEI7SUFDNUIsa0JBQWtCO0lBQ2xCLDZCQUE2QixFQUFBO0VBR2pDO0VBQ0UsbUJBQWMsRUFBQTtFQURoQjtJQUdJLGlCQUFpQixFQUFBO0VBSHJCO0lBTUksWUFBWTtJQUNaLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsZ0JBQWdCLEVBQUE7RUFUcEI7SUFZSSxlQUFlO0lBQ2YsNEJBQTRCO0lBQzVCLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NoYXJlL3NoYXJlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tYm9yZGVyLWNvbG9yKTtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1wYWRkaW5nLXRvcDogMTBweDtcclxuICBpb24tcm93IHtcclxuICAgIHBhZGRpbmc6IDBweCAyMHB4O1xyXG4gIH1cclxuICAuc2hhcmUtb3B0aW9uLWltZyB7XHJcbiAgICBoZWlnaHQ6IDU2cHg7XHJcbiAgICB3aWR0aDogNTZweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIG1hcmdpbi10b3A6IDE2cHg7XHJcbiAgfVxyXG4gIC50eXBlLWxhYmVsIHtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/share/share.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/share/share.page.ts ***!
  \*******************************************/
/*! exports provided: SharePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharePage", function() { return SharePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SharePage = /** @class */ (function () {
    function SharePage() {
    }
    SharePage.prototype.ngOnInit = function () {
    };
    SharePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-share',
            template: __webpack_require__(/*! ./share.page.html */ "./src/app/pages/share/share.page.html"),
            styles: [__webpack_require__(/*! ./share.page.scss */ "./src/app/pages/share/share.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SharePage);
    return SharePage;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\ionic 4\Book A Point\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map