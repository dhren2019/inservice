(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-select-service-select-service-module"],{

/***/ "./src/app/pages/select-service/select-service.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/select-service/select-service.module.ts ***!
  \***************************************************************/
/*! exports provided: SelectServicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectServicePageModule", function() { return SelectServicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _select_service_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./select-service.page */ "./src/app/pages/select-service/select-service.page.ts");







var routes = [
    {
        path: '',
        component: _select_service_page__WEBPACK_IMPORTED_MODULE_6__["SelectServicePage"]
    }
];
var SelectServicePageModule = /** @class */ (function () {
    function SelectServicePageModule() {
    }
    SelectServicePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_select_service_page__WEBPACK_IMPORTED_MODULE_6__["SelectServicePage"]]
        })
    ], SelectServicePageModule);
    return SelectServicePageModule;
}());



/***/ }),

/***/ "./src/app/pages/select-service/select-service.page.html":
/*!***************************************************************!*\
  !*** ./src/app/pages/select-service/select-service.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" mode=\"md\" (click)=\"backPage()\">\n        <ion-icon src=\"../../../assets/images/General/noun_Arrow_white_1256499.svg\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Book Appointment</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n  <div class=\"main-containt\">\n    <div class=\"scroll-div\">\n      <h4 class=\"title\">Gender</h4>\n      <ion-radio-group [(ngModel)]=\"gender\">\n        <ion-row class=\"ion-no-padding gender-row\">\n          <ion-col class=\"ion-no-padding\">\n            <ion-item class=\"ion-no-padding\" lines=\"none\">\n              <ion-label>Man</ion-label>\n              <ion-radio slot=\"start\" mode=\"md\" value=\"Man\" checked></ion-radio>\n            </ion-item>\n          </ion-col>\n          <ion-col class=\"ion-no-padding\">\n            <ion-item class=\"ion-no-padding\" lines=\"none\">\n              <ion-label>Woman</ion-label>\n              <ion-radio slot=\"start\" mode=\"md\" value=\"Woman\"></ion-radio>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </ion-radio-group>\n      <h4 class=\"title\" style=\"margin-bottom: 10px\">Choose your service <span class=\"ion-float-right total-label\">Total:\n          $15.00</span></h4>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col size=\"5\">\n          <p class=\"service-label\">Hair cut</p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <ion-select interface=\"alert\" [interfaceOptions]=\"selectOp1\" placeholder=\"Select type\" class=\"select\">\n            <ion-select-option value=\"f\">Test</ion-select-option>\n            <ion-select-option value=\"m\">Test</ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col size=\"5\">\n          <p class=\"service-label\">Spa</p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <ion-select [interfaceOptions]=\"selectOp2\" placeholder=\"Select type\" class=\"select\">\n            <ion-select-option value=\"f\">Test</ion-select-option>\n            <ion-select-option value=\"m\">Test</ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col size=\"5\">\n          <p class=\"service-label\">Make up</p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <ion-select [interfaceOptions]=\"selectOp3\" placeholder=\"Select type\" class=\"select\">\n            <ion-select-option value=\"f\">Test</ion-select-option>\n            <ion-select-option value=\"m\">Test</ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col size=\"5\">\n          <p class=\"service-label\">Facial</p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <ion-select [interfaceOptions]=\"selectOp4\" placeholder=\"Select type\" class=\"select\">\n            <ion-select-option value=\"f\">Test</ion-select-option>\n            <ion-select-option value=\"m\">Test</ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col size=\"5\">\n          <p class=\"service-label\">Hair color</p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <ion-select [interfaceOptions]=\"selectOp5\" placeholder=\" Select type\" class=\"select\">\n            <ion-select-option value=\"f\">Test</ion-select-option>\n            <ion-select-option value=\"m\">Test</ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col size=\"5\">\n          <p class=\"service-label\">Bridal</p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <ion-select [interfaceOptions]=\"selectOp6\" placeholder=\"Select type\" class=\"select\">\n            <ion-select-option value=\"f\">Test</ion-select-option>\n            <ion-select-option value=\"m\">Test</ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col size=\"5\">\n          <p class=\"service-label\">Nail</p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <ion-select [interfaceOptions]=\"selectOp7\" placeholder=\"Select type\" class=\"select\">\n            <ion-select-option value=\"f\">Test</ion-select-option>\n            <ion-select-option value=\"m\">Test</ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n      <ion-button class=\"btn-continue\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\" (click)=\"continue()\">\n        Continue\n      </ion-button>\n    </div>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/select-service/select-service.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/pages/select-service/select-service.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: transparent;\n  --ion-color-base: transparent !important; }\n\nion-header ion-title {\n  font-size: 19px;\n  color: var(--ion-color-white);\n  font-family: 'tofini_bold'; }\n\nion-header ion-button {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --ripple-color: var(--ion-color-white);\n  margin-left: 15px; }\n\nion-header ion-button ion-icon {\n    width: 23.74px;\n    height: 20px; }\n\nion-content {\n  --background: url('Rectangle.png') no-repeat\r\n    0px 0px / 100%; }\n\nion-content .main-containt {\n    padding: 3vh 24px 0px 24px;\n    background-color: var(--ion-color-white);\n    height: 100%;\n    position: fixed;\n    left: 0px;\n    right: 0px;\n    top: 28vh;\n    border-radius: 17px 17px 0px 0px; }\n\nion-content .main-containt .scroll-div {\n      height: 70vh;\n      overflow-y: scroll; }\n\nion-content .main-containt .scroll-div::-webkit-scrollbar {\n        display: none; }\n\nion-content .main-containt .title {\n      font-size: 16px;\n      font-family: 'tofini_bold';\n      margin-top: 0px;\n      margin-bottom: 0px; }\n\nion-content .main-containt .gender-row {\n      margin-bottom: 14px; }\n\nion-content .main-containt .gender-row ion-item {\n        --ripple-color: var(--ion-color-white); }\n\nion-content .main-containt .gender-row ion-radio {\n        --border-width: 1px;\n        --color: var(--ion-color-orange);\n        --color-checked: var(--ion-color-orange);\n        margin-right: 11px; }\n\nion-content .main-containt .gender-row ion-label {\n        font-size: 16px;\n        font-family: 'tofini_regular';\n        color: var(--ion-color-lightDark); }\n\nion-content .main-containt .total-label {\n      font-family: 'tofini_medium';\n      color: var(--ion-color-orange); }\n\nion-content .main-containt ion-select {\n      background: var(--ion-input-back);\n      height: 38px;\n      border-radius: 8px;\n      --padding-start: 15px;\n      font-family: 'tofini_regular';\n      font-size: 14px;\n      --padding-end: 12px;\n      --padding-top: 12px; }\n\nion-content .main-containt ion-select select-icon {\n        margin-top: -2px !important; }\n\nion-content .main-containt .service-label {\n      margin: 8px 0px;\n      font-size: 16px;\n      font-family: 'tofini_regular';\n      color: var(--ion-color-lightDark); }\n\nion-content .main-containt .btn-continue {\n      --color: var(--ion-color-white);\n      height: 44px;\n      margin: 30px 8px 10px 8px;\n      font-size: 15px;\n      --box-shadow: none;\n      font-family: 'tofini_regular';\n      --background: var(--ion-color-gradiant);\n      text-transform: inherit; }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2VsZWN0LXNlcnZpY2UvRDpcXGlvbmljIDRcXEJvb2sgQSBQb2ludC9zcmNcXGFwcFxccGFnZXNcXHNlbGVjdC1zZXJ2aWNlXFxzZWxlY3Qtc2VydmljZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSx5QkFBYTtFQUNiLHdDQUFpQixFQUFBOztBQUhyQjtFQU1JLGVBQWU7RUFDZiw2QkFBNkI7RUFDN0IsMEJBQTBCLEVBQUE7O0FBUjlCO0VBV0ksb0JBQWdCO0VBQ2hCLGtCQUFjO0VBQ2Qsc0NBQWU7RUFDZixpQkFBaUIsRUFBQTs7QUFkckI7SUFnQk0sY0FBYztJQUNkLFlBQVksRUFBQTs7QUFJbEI7RUFDRTtrQkFBYSxFQUFBOztBQURmO0lBSUksMEJBQTBCO0lBQzFCLHdDQUF3QztJQUN4QyxZQUFZO0lBQ1osZUFBZTtJQUNmLFNBQVM7SUFDVCxVQUFVO0lBQ1YsU0FBUztJQUNULGdDQUFnQyxFQUFBOztBQVhwQztNQWFNLFlBQVk7TUFDWixrQkFBa0IsRUFBQTs7QUFkeEI7UUFnQlEsYUFBYSxFQUFBOztBQWhCckI7TUFvQk0sZUFBZTtNQUNmLDBCQUEwQjtNQUMxQixlQUFlO01BQ2Ysa0JBQWtCLEVBQUE7O0FBdkJ4QjtNQTBCTSxtQkFBbUIsRUFBQTs7QUExQnpCO1FBNEJRLHNDQUFlLEVBQUE7O0FBNUJ2QjtRQStCUSxtQkFBZTtRQUNmLGdDQUFRO1FBQ1Isd0NBQWdCO1FBQ2hCLGtCQUFrQixFQUFBOztBQWxDMUI7UUFxQ1EsZUFBZTtRQUNmLDZCQUE2QjtRQUM3QixpQ0FBaUMsRUFBQTs7QUF2Q3pDO01BMkNNLDRCQUE0QjtNQUM1Qiw4QkFBOEIsRUFBQTs7QUE1Q3BDO01BK0NNLGlDQUFpQztNQUNqQyxZQUFZO01BQ1osa0JBQWtCO01BQ2xCLHFCQUFnQjtNQUNoQiw2QkFBNkI7TUFDN0IsZUFBZTtNQUNmLG1CQUFjO01BQ2QsbUJBQWMsRUFBQTs7QUF0RHBCO1FBd0RRLDJCQUEyQixFQUFBOztBQXhEbkM7TUE2RE0sZUFBZTtNQUNmLGVBQWU7TUFDZiw2QkFBNkI7TUFDN0IsaUNBQWlDLEVBQUE7O0FBaEV2QztNQW1FTSwrQkFBUTtNQUNSLFlBQVk7TUFDWix5QkFBeUI7TUFDekIsZUFBZTtNQUNmLGtCQUFhO01BQ2IsNkJBQTZCO01BQzdCLHVDQUFhO01BQ2IsdUJBQXVCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zZWxlY3Qtc2VydmljZS9zZWxlY3Qtc2VydmljZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgLS1pb24tY29sb3ItYmFzZTogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuICB9XHJcbiAgaW9uLXRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMTlweDtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfYm9sZCc7XHJcbiAgfVxyXG4gIGlvbi1idXR0b24ge1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcbiAgICAtLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgICAtLXJpcHBsZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICB3aWR0aDogMjMuNzRweDtcclxuICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoJy4uLy4uLy4uL2Fzc2V0cy9pbWFnZXMvR2VuZXJhbC9SZWN0YW5nbGUucG5nJykgbm8tcmVwZWF0XHJcbiAgICAwcHggMHB4IC8gMTAwJTtcclxuICAubWFpbi1jb250YWludCB7XHJcbiAgICBwYWRkaW5nOiAzdmggMjRweCAwcHggMjRweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwcHg7XHJcbiAgICByaWdodDogMHB4O1xyXG4gICAgdG9wOiAyOHZoO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTdweCAxN3B4IDBweCAwcHg7XHJcbiAgICAuc2Nyb2xsLWRpdiB7XHJcbiAgICAgIGhlaWdodDogNzB2aDtcclxuICAgICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xyXG4gICAgICAmOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLnRpdGxlIHtcclxuICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9ib2xkJztcclxuICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICB9XHJcbiAgICAuZ2VuZGVyLXJvdyB7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDE0cHg7XHJcbiAgICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAtLXJpcHBsZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgfVxyXG4gICAgICBpb24tcmFkaW8ge1xyXG4gICAgICAgIC0tYm9yZGVyLXdpZHRoOiAxcHg7XHJcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICAgICAgLS1jb2xvci1jaGVja2VkOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDExcHg7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodERhcmspO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAudG90YWwtbGFiZWwge1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9tZWRpdW0nO1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICB9XHJcbiAgICBpb24tc2VsZWN0IHtcclxuICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWlucHV0LWJhY2spO1xyXG4gICAgICBoZWlnaHQ6IDM4cHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAtLXBhZGRpbmctZW5kOiAxMnB4O1xyXG4gICAgICAtLXBhZGRpbmctdG9wOiAxMnB4O1xyXG4gICAgICBzZWxlY3QtaWNvbiB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogLTJweCAhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLnNlcnZpY2UtbGFiZWwge1xyXG4gICAgICBtYXJnaW46IDhweCAwcHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHREYXJrKTtcclxuICAgIH1cclxuICAgIC5idG4tY29udGludWUge1xyXG4gICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICAgIG1hcmdpbjogMzBweCA4cHggMTBweCA4cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZ3JhZGlhbnQpO1xyXG4gICAgICB0ZXh0LXRyYW5zZm9ybTogaW5oZXJpdDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/select-service/select-service.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/select-service/select-service.page.ts ***!
  \*************************************************************/
/*! exports provided: SelectServicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectServicePage", function() { return SelectServicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var SelectServicePage = /** @class */ (function () {
    function SelectServicePage(navCtrl) {
        this.navCtrl = navCtrl;
        this.gender = "Woman";
        this.selectOp1 = {
            header: "Hair Color"
        };
        this.selectOp2 = {
            header: "Spa"
        };
        this.selectOp3 = {
            header: "Make up"
        };
        this.selectOp4 = {
            header: "Facial"
        };
        this.selectOp5 = {
            header: "Hair color"
        };
        this.selectOp6 = {
            header: "Bridal"
        };
        this.selectOp7 = {
            header: "Nail"
        };
        // setTimeout(() => {
        //   document
        //     .querySelector('.select')
        //     .shadowRoot.querySelector('.select-icon')
        //     .setAttribute('style', 'margin-top: -2px;');
        //   document
        //     .querySelector('.select')
        //     .shadowRoot.querySelector('.select-icon .select-icon-inner')
        //     .setAttribute('style', 'opacity: 1');
        // }, 2000);
    }
    SelectServicePage.prototype.ngOnInit = function () { };
    SelectServicePage.prototype.backPage = function () {
        this.navCtrl.back();
    };
    SelectServicePage.prototype.continue = function () {
        this.navCtrl.navigateForward("/book-appointment");
    };
    SelectServicePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-select-service",
            template: __webpack_require__(/*! ./select-service.page.html */ "./src/app/pages/select-service/select-service.page.html"),
            styles: [__webpack_require__(/*! ./select-service.page.scss */ "./src/app/pages/select-service/select-service.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], SelectServicePage);
    return SelectServicePage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-select-service-select-service-module.js.map