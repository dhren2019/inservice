(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-sign-in-sign-in-module"],{

/***/ "./src/app/pages/sign-in/sign-in.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/sign-in/sign-in.module.ts ***!
  \*************************************************/
/*! exports provided: SignInPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignInPageModule", function() { return SignInPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _sign_in_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sign-in.page */ "./src/app/pages/sign-in/sign-in.page.ts");







var routes = [
    {
        path: '',
        component: _sign_in_page__WEBPACK_IMPORTED_MODULE_6__["SignInPage"]
    }
];
var SignInPageModule = /** @class */ (function () {
    function SignInPageModule() {
    }
    SignInPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_sign_in_page__WEBPACK_IMPORTED_MODULE_6__["SignInPage"]]
        })
    ], SignInPageModule);
    return SignInPageModule;
}());



/***/ }),

/***/ "./src/app/pages/sign-in/sign-in.page.html":
/*!*************************************************!*\
  !*** ./src/app/pages/sign-in/sign-in.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div class=\"content-section\">\n    <h1 class=\"ion-text-center title\">Welcome Back</h1>\n    <p class=\"ion-text-center\">Login to your account</p>\n    <form>\n      <ion-input class=\"email-input\" name=\"email\" [(ngModel)]=\"user.email\" placeholder=\"Email\" type=\"email\"></ion-input>\n\n      <ion-input placeholder=\"Password\" name=\"password\" [(ngModel)]=\"user.password\" type=\"password\"></ion-input>\n\n      <ion-button class=\"btn-login ion-text-capitalize\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\"\n        (click)=\"login()\">\n        Login\n      </ion-button>\n    </form>\n    <ion-button class=\"btn-forgot\" expand=\"full\" fill=\"clear\" (click)=\"forgotPassword()\">\n      Forgot your password?\n    </ion-button>\n\n    <p class=\"ion-text-center account-text\">Don’t have an account? <a (click)=\"signUp()\"> Sign up</a></p>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/sign-in/sign-in.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/sign-in/sign-in.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: none;\n  background-image: url('login-image.PNG');\n  background-position: top center;\n  background-repeat: no-repeat;\n  background-size: 100% 46vh; }\n  ion-content .content-section {\n    width: 100%;\n    padding: 4vh 24px 20px 20px;\n    margin-top: 38vh;\n    background-color: var(--ion-color-white);\n    border-radius: 17px 17px 0px 0px; }\n  ion-content .content-section .title {\n      font-family: \"tofini_bold\";\n      font-size: 30px;\n      margin-top: 0px; }\n  ion-content .content-section p {\n      color: var(--ion-color-gray);\n      margin: 0px;\n      font-size: 14px;\n      font-family: \"tofini_regular\"; }\n  ion-content .content-section ion-input {\n      --background: var(--ion-input-back);\n      height: 44px;\n      border-radius: 25px;\n      --padding-start: 24px;\n      --placeholder-color: var(--ion-placeholder-color);\n      --placeholder-font-style: \"tofini_regular\";\n      font-size: 15px; }\n  ion-content .content-section .email-input {\n      margin-bottom: 20px;\n      margin-top: 4vh; }\n  ion-content .content-section .btn-login {\n      --color: var(--ion-color-white);\n      height: 44px;\n      margin: 4vh 8px 0px 8px;\n      font-size: 16px;\n      --box-shadow: none;\n      font-family: \"tofini_regular\";\n      --background: var(--ion-color-gradiant); }\n  ion-content .content-section .btn-forgot {\n      --color: var(--ion-color-lightDark);\n      --color-activated: var(--ion-color-lightDark);\n      --ripple-color: var(--ion-color-white);\n      text-transform: inherit;\n      font-family: \"tofini_regular\";\n      margin-top: 18px; }\n  ion-content .content-section .account-text {\n      margin-top: 3vh;\n      font-family: \"tofini_regular\"; }\n  ion-content .content-section .account-text a {\n        color: var(--ion-color-darkYellow); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2lnbi1pbi9EOlxcaW9uaWMgNFxcQm9vayBBIFBvaW50L3NyY1xcYXBwXFxwYWdlc1xcc2lnbi1pblxcc2lnbi1pbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBYTtFQUNiLHdDQUFzRTtFQUN0RSwrQkFBK0I7RUFDL0IsNEJBQTRCO0VBQzVCLDBCQUEwQixFQUFBO0VBTDVCO0lBUUksV0FBVztJQUNYLDJCQUEyQjtJQUUzQixnQkFBZ0I7SUFDaEIsd0NBQXdDO0lBQ3hDLGdDQUFnQyxFQUFBO0VBYnBDO01BZ0JNLDBCQUEwQjtNQUMxQixlQUFlO01BQ2YsZUFBZSxFQUFBO0VBbEJyQjtNQXFCTSw0QkFBNEI7TUFDNUIsV0FBVztNQUNYLGVBQWU7TUFDZiw2QkFBNkIsRUFBQTtFQXhCbkM7TUE0Qk0sbUNBQWE7TUFDYixZQUFZO01BQ1osbUJBQW1CO01BQ25CLHFCQUFnQjtNQUNoQixpREFBb0I7TUFDcEIsMENBQXlCO01BQ3pCLGVBQWUsRUFBQTtFQWxDckI7TUFxQ00sbUJBQW1CO01BQ25CLGVBQWUsRUFBQTtFQXRDckI7TUF5Q00sK0JBQVE7TUFDUixZQUFZO01BQ1osdUJBQXVCO01BQ3ZCLGVBQWU7TUFDZixrQkFBYTtNQUNiLDZCQUE2QjtNQUM3Qix1Q0FBYSxFQUFBO0VBL0NuQjtNQWtETSxtQ0FBUTtNQUNSLDZDQUFrQjtNQUNsQixzQ0FBZTtNQUNmLHVCQUF1QjtNQUN2Qiw2QkFBNkI7TUFDN0IsZ0JBQWdCLEVBQUE7RUF2RHRCO01BMERNLGVBQWU7TUFDZiw2QkFBNkIsRUFBQTtFQTNEbkM7UUE2RFEsa0NBQWtDLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zaWduLWluL3NpZ24taW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogbm9uZTtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi8uLi9hc3NldHMvaW1hZ2VzL3NpZ25Jbi9sb2dpbi1pbWFnZS5QTkdcIik7XHJcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogdG9wIGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJSA0NnZoO1xyXG5cclxuICAuY29udGVudC1zZWN0aW9uIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogNHZoIDI0cHggMjBweCAyMHB4O1xyXG5cclxuICAgIG1hcmdpbi10b3A6IDM4dmg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTdweCAxN3B4IDBweCAwcHg7XHJcblxyXG4gICAgLnRpdGxlIHtcclxuICAgICAgZm9udC1mYW1pbHk6IFwidG9maW5pX2JvbGRcIjtcclxuICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ncmF5KTtcclxuICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgZm9udC1mYW1pbHk6IFwidG9maW5pX3JlZ3VsYXJcIjtcclxuICAgIH1cclxuXHJcbiAgICBpb24taW5wdXQge1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pbnB1dC1iYWNrKTtcclxuICAgICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgICAtLXBhZGRpbmctc3RhcnQ6IDI0cHg7XHJcbiAgICAgIC0tcGxhY2Vob2xkZXItY29sb3I6IHZhcigtLWlvbi1wbGFjZWhvbGRlci1jb2xvcik7XHJcbiAgICAgIC0tcGxhY2Vob2xkZXItZm9udC1zdHlsZTogXCJ0b2ZpbmlfcmVndWxhclwiO1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICB9XHJcbiAgICAuZW1haWwtaW5wdXQge1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA0dmg7XHJcbiAgICB9XHJcbiAgICAuYnRuLWxvZ2luIHtcclxuICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgICBtYXJnaW46IDR2aCA4cHggMHB4IDhweDtcclxuICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9yZWd1bGFyXCI7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWdyYWRpYW50KTtcclxuICAgIH1cclxuICAgIC5idG4tZm9yZ290IHtcclxuICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0RGFyayk7XHJcbiAgICAgIC0tY29sb3ItYWN0aXZhdGVkOiB2YXIoLS1pb24tY29sb3ItbGlnaHREYXJrKTtcclxuICAgICAgLS1yaXBwbGUtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgIHRleHQtdHJhbnNmb3JtOiBpbmhlcml0O1xyXG4gICAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfcmVndWxhclwiO1xyXG4gICAgICBtYXJnaW4tdG9wOiAxOHB4O1xyXG4gICAgfVxyXG4gICAgLmFjY291bnQtdGV4dCB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDN2aDtcclxuICAgICAgZm9udC1mYW1pbHk6IFwidG9maW5pX3JlZ3VsYXJcIjtcclxuICAgICAgYSB7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrWWVsbG93KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/sign-in/sign-in.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/sign-in/sign-in.page.ts ***!
  \***********************************************/
/*! exports provided: SignInPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignInPage", function() { return SignInPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var SignInPage = /** @class */ (function () {
    function SignInPage(navCtrl) {
        this.navCtrl = navCtrl;
        this.user = {};
    }
    SignInPage.prototype.ngOnInit = function () { };
    SignInPage.prototype.login = function () {
        this.navCtrl.navigateForward("/slider");
    };
    SignInPage.prototype.forgotPassword = function () {
        this.navCtrl.navigateForward("/forgot-password");
    };
    SignInPage.prototype.signUp = function () {
        this.navCtrl.navigateForward("/sign-up");
    };
    SignInPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-sign-in",
            template: __webpack_require__(/*! ./sign-in.page.html */ "./src/app/pages/sign-in/sign-in.page.html"),
            styles: [__webpack_require__(/*! ./sign-in.page.scss */ "./src/app/pages/sign-in/sign-in.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], SignInPage);
    return SignInPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-sign-in-sign-in-module.js.map