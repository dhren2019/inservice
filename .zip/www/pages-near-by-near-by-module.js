(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-near-by-near-by-module"],{

/***/ "./src/app/pages/near-by/near-by.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/near-by/near-by.module.ts ***!
  \*************************************************/
/*! exports provided: NearByPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NearByPageModule", function() { return NearByPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _near_by_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./near-by.page */ "./src/app/pages/near-by/near-by.page.ts");







var routes = [
    {
        path: '',
        component: _near_by_page__WEBPACK_IMPORTED_MODULE_6__["NearByPage"]
    }
];
var NearByPageModule = /** @class */ (function () {
    function NearByPageModule() {
    }
    NearByPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_near_by_page__WEBPACK_IMPORTED_MODULE_6__["NearByPage"]]
        })
    ], NearByPageModule);
    return NearByPageModule;
}());



/***/ }),

/***/ "./src/app/pages/near-by/near-by.page.html":
/*!*************************************************!*\
  !*** ./src/app/pages/near-by/near-by.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <p class=\"location-label\">Your location</p>\n    <p class=\"select-location ion-no-margin\">\n      <ion-icon\n        class=\"pin\"\n        src=\"../../../assets/images/General/ic_location_color.svg\"\n      ></ion-icon>\n      San Francisco City\n      <ion-icon\n        class=\"direction\"\n        src=\"../../../assets/images/General/ic_direction.svg\"\n      ></ion-icon>\n    </p>\n    <ion-buttons slot=\"end\">\n      <ion-button class=\"btn-filter\" fill=\"clear\" (click)=\"openFilter()\">\n        <ion-icon\n          src=\"../../../assets/images/General/_ionicons_svg_ios-funnel.svg\"\n        ></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-toolbar>\n    <ion-searchbar mode=\"ios\" [(ngModel)]=\"searchText\"></ion-searchbar>\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" class=\"btn-cancel\" (click)=\"searchCancel()\">\n        Cancel\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div #map id=\"map\" style=\"height: 100%;width: 100%\"></div>\n  <div class=\"map-button\">\n    <div class=\"info-icon\">\n      <ion-icon src=\"../../../assets/images/near-by/ic_info.svg\"></ion-icon>\n    </div>\n    <ion-icon\n      class=\"location\"\n      src=\"../../../assets/images/near-by/ic_location_clear.svg\"\n    ></ion-icon>\n  </div>\n\n  <ion-fab\n    vertical=\"bottom\"\n    horizontal=\"end\"\n    slot=\"fixed\"\n    (click)=\"openNearModal()\"\n  >\n    <ion-fab-button>\n      <ion-icon\n        src=\"../../../assets/images/General/noun_List_204249.svg\"\n      ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/near-by/near-by.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/near-by/near-by.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header {\n  border-bottom: 0.5px solid #dedede; }\n  ion-header ion-toolbar {\n    padding-left: 16px;\n    --background: var(--ion-color-white-light); }\n  ion-header .location-label {\n    font-size: 12px;\n    font-family: \"tofini_medium\";\n    color: var(--ion-color-simpleDark);\n    margin-bottom: 3px;\n    margin-top: 12px; }\n  ion-header .select-location {\n    font-size: 15px;\n    font-family: \"tofini_medium\";\n    color: var(--ion-color-black); }\n  ion-header .select-location .pin {\n      height: 17.7px;\n      width: 12.42px;\n      margin-bottom: -3px;\n      margin-right: 5px; }\n  ion-header .select-location .direction {\n      height: 14px;\n      width: 14px;\n      margin-bottom: -3px;\n      margin-left: 7px; }\n  ion-header .btn-filter {\n    font-size: 18px;\n    color: var(--ion-color-black);\n    --ripple-color: var(--ion-color-white); }\n  ion-header ion-searchbar {\n    padding: 0px;\n    --background: var(--ion-searchBack-color);\n    font-size: 15px;\n    font-family: \"tofini_regular\"; }\n  ion-header ion-searchbar .searchbar-clear-icon {\n      display: none !important; }\n  ion-header .btn-cancel {\n    --color: var(--ion-color-orange);\n    font-size: 15px;\n    font-family: \"tofini_bold\";\n    text-transform: initial;\n    --ripple-color: var(--ion-color-white); }\n  ion-content .map-button {\n  position: absolute;\n  top: 18px;\n  right: 8px;\n  background: rgba(255, 255, 255, 0.8);\n  border-radius: 10px;\n  border: 1px solid;\n  border-color: rgba(151, 151, 151, 0.2); }\n  ion-content .map-button ion-icon {\n    font-size: 24px; }\n  ion-content .map-button .info-icon {\n    padding: 10px;\n    border-bottom: 1px solid;\n    border-color: rgba(151, 151, 151, 0.2); }\n  ion-content .map-button .location {\n    padding: 10px; }\n  ion-content ion-fab ion-fab-button ion-icon {\n  font-size: 28px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbmVhci1ieS9EOlxcaW9uaWMgNFxcQm9vayBBIFBvaW50L3NyY1xcYXBwXFxwYWdlc1xcbmVhci1ieVxcbmVhci1ieS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQ0FBa0MsRUFBQTtFQURwQztJQUdJLGtCQUFrQjtJQUNsQiwwQ0FBYSxFQUFBO0VBSmpCO0lBT0ksZUFBZTtJQUNmLDRCQUE0QjtJQUM1QixrQ0FBa0M7SUFDbEMsa0JBQWtCO0lBQ2xCLGdCQUFnQixFQUFBO0VBWHBCO0lBY0ksZUFBZTtJQUNmLDRCQUE0QjtJQUM1Qiw2QkFBNkIsRUFBQTtFQWhCakM7TUFrQk0sY0FBYztNQUNkLGNBQWM7TUFDZCxtQkFBbUI7TUFDbkIsaUJBQWlCLEVBQUE7RUFyQnZCO01Bd0JNLFlBQVk7TUFDWixXQUFXO01BQ1gsbUJBQW1CO01BQ25CLGdCQUFnQixFQUFBO0VBM0J0QjtJQStCSSxlQUFlO0lBQ2YsNkJBQTZCO0lBQzdCLHNDQUFlLEVBQUE7RUFqQ25CO0lBb0NJLFlBQVk7SUFDWix5Q0FBYTtJQUNiLGVBQWU7SUFDZiw2QkFBNkIsRUFBQTtFQXZDakM7TUF5Q00sd0JBQXdCLEVBQUE7RUF6QzlCO0lBNkNJLGdDQUFRO0lBQ1IsZUFBZTtJQUNmLDBCQUEwQjtJQUMxQix1QkFBdUI7SUFDdkIsc0NBQWUsRUFBQTtFQUduQjtFQUVJLGtCQUFrQjtFQUNsQixTQUFTO0VBQ1QsVUFBVTtFQUNWLG9DQUFvQztFQUNwQyxtQkFBbUI7RUFDbkIsaUJBQWlCO0VBQ2pCLHNDQUEwQixFQUFBO0VBUjlCO0lBVU0sZUFBZSxFQUFBO0VBVnJCO0lBYU0sYUFBYTtJQUNiLHdCQUF3QjtJQUN4QixzQ0FBMEIsRUFBQTtFQWZoQztJQWtCTSxhQUFhLEVBQUE7RUFsQm5CO0VBeUJRLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL25lYXItYnkvbmVhci1ieS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBib3JkZXItYm90dG9tOiAwLjVweCBzb2xpZCAjZGVkZWRlO1xyXG4gIGlvbi10b29sYmFyIHtcclxuICAgIHBhZGRpbmctbGVmdDogMTZweDtcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXdoaXRlLWxpZ2h0KTtcclxuICB9XHJcbiAgLmxvY2F0aW9uLWxhYmVsIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9tZWRpdW1cIjtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2ltcGxlRGFyayk7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gIH1cclxuICAuc2VsZWN0LWxvY2F0aW9uIHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9tZWRpdW1cIjtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgLnBpbiB7XHJcbiAgICAgIGhlaWdodDogMTcuN3B4O1xyXG4gICAgICB3aWR0aDogMTIuNDJweDtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogLTNweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgICB9XHJcbiAgICAuZGlyZWN0aW9uIHtcclxuICAgICAgaGVpZ2h0OiAxNHB4O1xyXG4gICAgICB3aWR0aDogMTRweDtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogLTNweDtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDdweDtcclxuICAgIH1cclxuICB9XHJcbiAgLmJ0bi1maWx0ZXIge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjayk7XHJcbiAgICAtLXJpcHBsZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICB9XHJcbiAgaW9uLXNlYXJjaGJhciB7XHJcbiAgICBwYWRkaW5nOiAwcHg7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1zZWFyY2hCYWNrLWNvbG9yKTtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9yZWd1bGFyXCI7XHJcbiAgICAuc2VhcmNoYmFyLWNsZWFyLWljb24ge1xyXG4gICAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5idG4tY2FuY2VsIHtcclxuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFwidG9maW5pX2JvbGRcIjtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xyXG4gICAgLS1yaXBwbGUtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgfVxyXG59XHJcbmlvbi1jb250ZW50IHtcclxuICAubWFwLWJ1dHRvbiB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDE4cHg7XHJcbiAgICByaWdodDogOHB4O1xyXG4gICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkO1xyXG4gICAgYm9yZGVyLWNvbG9yOiByZ2JhKCM5Nzk3OTcsIDAuMik7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIH1cclxuICAgIC5pbmZvLWljb24ge1xyXG4gICAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQ7XHJcbiAgICAgIGJvcmRlci1jb2xvcjogcmdiYSgjOTc5Nzk3LCAwLjIpO1xyXG4gICAgfVxyXG4gICAgLmxvY2F0aW9uIHtcclxuICAgICAgcGFkZGluZzogMTBweDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlvbi1mYWIge1xyXG4gICAgaW9uLWZhYi1idXR0b24ge1xyXG4gICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyOHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/near-by/near-by.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/near-by/near-by.page.ts ***!
  \***********************************************/
/*! exports provided: NearByPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NearByPage", function() { return NearByPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _filter_filter_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../filter/filter.page */ "./src/app/pages/filter/filter.page.ts");
/* harmony import */ var _enable_location_enable_location_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../enable-location/enable-location.page */ "./src/app/pages/enable-location/enable-location.page.ts");
/* harmony import */ var _near_salon_list_near_salon_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../near-salon-list/near-salon-list.page */ "./src/app/pages/near-salon-list/near-salon-list.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");






var NearByPage = /** @class */ (function () {
    function NearByPage(modalController, navCtrl) {
        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.salonList = [
            {
                name: "RedBox Barber",
                image: "../../../assets/images/General/Rectangle.png",
                address: "288 McClure Court, Arkansas",
                star: "4.0"
            },
            {
                name: "Looks Unisex Salon",
                image: "../../../assets/images/General/Rectangle.png",
                address: "288 McClure Court, Arkansas",
                star: "4.0"
            }
        ];
        this.enableLocation();
    }
    NearByPage.prototype.enableLocation = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _enable_location_enable_location_page__WEBPACK_IMPORTED_MODULE_2__["EnableLocationPage"],
                            cssClass: "enableLocation-modal"
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NearByPage.prototype.ngOnInit = function () {
        this.initMap();
    };
    NearByPage.prototype.initMap = function () {
        var _this = this;
        var markerData = [
            { lat: 22.3, lng: 70.8, text: "Looks Unisex Salon" },
            { lat: 22.3, lng: 70.81, text: "Beauty Plus Spa" },
            { lat: 22.31, lng: 70.8, text: "RedBox Barber" },
            { lat: 22.33, lng: 70.81, text: "Divine Salon" }
        ];
        var latLng = new google.maps.LatLng(22.32, 70.81);
        var mapoption = {
            center: latLng,
            zoom: 15,
            streetViewControl: false,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        this.map = new google.maps.Map(this.mapElement.nativeElement, mapoption);
        var markerIcon = {
            url: "../../../assets/images/near-by/pin-image.png",
            labelOrigin: new google.maps.Point(25, 63),
            scaledSize: new google.maps.Size(56, 64)
        };
        var markerIconCurrent = {
            url: "../../../assets/images/near-by/nevigation-icon.gif",
            scaledSize: new google.maps.Size(35, 35),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 17)
        };
        markerData.forEach(function (element, index) {
            var marker = new google.maps.Marker({
                position: new google.maps.LatLng(element.lat, element.lng),
                map: _this.map,
                icon: markerIcon,
                label: {
                    text: element.text,
                    fontSize: "11px",
                    fontFamily: "tofini_medium",
                    width: "30px"
                }
            });
        });
        var marker4 = new google.maps.Marker({
            position: latLng,
            map: this.map,
            icon: markerIconCurrent
        });
        var circle = new google.maps.Circle({
            map: this.map,
            radius: 400,
            fillColor: "#007AFF",
            strokeWeight: 0,
            fillOpacity: 0.1
        });
        circle.bindTo("center", marker4, "position");
    };
    NearByPage.prototype.openNearModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _near_salon_list_near_salon_list_page__WEBPACK_IMPORTED_MODULE_3__["NearSalonListPage"],
                            cssClass: "nearSalon-modal"
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NearByPage.prototype.openFilter = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _filter_filter_page__WEBPACK_IMPORTED_MODULE_1__["FilterPage"]
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NearByPage.prototype.searchCancel = function () {
        this.searchText = "";
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"])("map"),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ElementRef"])
    ], NearByPage.prototype, "mapElement", void 0);
    NearByPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
            selector: "app-near-by",
            template: __webpack_require__(/*! ./near-by.page.html */ "./src/app/pages/near-by/near-by.page.html"),
            styles: [__webpack_require__(/*! ./near-by.page.scss */ "./src/app/pages/near-by/near-by.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])
    ], NearByPage);
    return NearByPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-near-by-near-by-module.js.map