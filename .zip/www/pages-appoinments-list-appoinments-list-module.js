(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-appoinments-list-appoinments-list-module"],{

/***/ "./src/app/pages/appoinments-list/appoinments-list.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/appoinments-list/appoinments-list.module.ts ***!
  \*******************************************************************/
/*! exports provided: AppoinmentsListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppoinmentsListPageModule", function() { return AppoinmentsListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _appoinments_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./appoinments-list.page */ "./src/app/pages/appoinments-list/appoinments-list.page.ts");







var routes = [
    {
        path: '',
        component: _appoinments_list_page__WEBPACK_IMPORTED_MODULE_6__["AppoinmentsListPage"]
    }
];
var AppoinmentsListPageModule = /** @class */ (function () {
    function AppoinmentsListPageModule() {
    }
    AppoinmentsListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_appoinments_list_page__WEBPACK_IMPORTED_MODULE_6__["AppoinmentsListPage"]]
        })
    ], AppoinmentsListPageModule);
    return AppoinmentsListPageModule;
}());



/***/ }),

/***/ "./src/app/pages/appoinments-list/appoinments-list.page.html":
/*!*******************************************************************!*\
  !*** ./src/app/pages/appoinments-list/appoinments-list.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-title class=\"ion-text-center\">Appoinments</ion-title>\n  </ion-toolbar>\n  <ion-toolbar>\n    <ion-segment\n      class=\"main-segment\"\n      mode=\"md\"\n      (ionChange)=\"chageViewAppoinment($event)\"\n    >\n      <ion-segment-button mode=\"md\" value=\"Upcomming\" checked>\n        <ion-label\n          >Upcomming\n          <div\n            [ngClass]=\"{ 'active-segment-line': activeTab == 'Upcomming' }\"\n          ></div>\n        </ion-label>\n      </ion-segment-button>\n      <ion-segment-button mode=\"md\" value=\"Completed\">\n        <ion-label\n          >Completed\n          <div\n            [ngClass]=\"{ 'active-segment-line': activeTab == 'Completed' }\"\n          ></div>\n        </ion-label>\n      </ion-segment-button>\n      <ion-segment-button mode=\"md\" value=\"Cancled\">\n        <ion-label\n          >Cancled\n          <div\n            [ngClass]=\"{ 'active-segment-line': activeTab == 'Cancled' }\"\n          ></div>\n        </ion-label>\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div [ngSwitch]=\"activeTab\">\n    <div *ngSwitchCase=\"'Upcomming'\">\n      <ion-item lines=\"none\" *ngFor=\"let item of [0, 1, 2, 3, 4]\">\n        <ion-thumbnail slot=\"start\">\n          <img src=\"../../../assets/images/General/Rectangle.png\" />\n        </ion-thumbnail>\n        <ion-label>\n          <h2 class=\"title\">RedBox Barber</h2>\n          <p class=\"service-name\">HairCut</p>\n          <p class=\"service-provide\">George Stephen</p>\n          <p class=\"address\">Rainbow piolly partke 4332</p>\n        </ion-label>\n        <div slot=\"end\" class=\"end-div ion-text-right\">\n          <div class=\"calendor-icon\">\n            <ion-icon\n              src=\"../../../assets/images/General/noun_Calendar_2577480.svg\"\n            ></ion-icon>\n          </div>\n          <p class=\"date\">20-jan-2019</p>\n          <h4 class=\"time\">12:45 PM</h4>\n        </div>\n      </ion-item>\n    </div>\n    <div *ngSwitchCase=\"'Completed'\">\n      <ion-item lines=\"none\" *ngFor=\"let item of [0, 1]\">\n        <ion-thumbnail slot=\"start\">\n          <img src=\"../../../assets/images/General/Rectangle.png\" />\n        </ion-thumbnail>\n        <ion-label>\n          <h2 class=\"title\">RedBox Barber</h2>\n          <p class=\"service-name\">HairCut</p>\n          <p class=\"service-provide\">George Stephen</p>\n          <p class=\"address\">Rainbow piolly partke 4332</p>\n        </ion-label>\n        <div slot=\"end\" class=\"end-div ion-text-right\">\n          <div class=\"calendor-icon\">\n            <ion-icon\n              src=\"../../../assets/images/General/noun_Calendar_2577480.svg\"\n            ></ion-icon>\n          </div>\n          <p class=\"date\">20-jan-2019</p>\n          <h4 class=\"time\">12:45 PM</h4>\n        </div>\n      </ion-item>\n    </div>\n    <div *ngSwitchCase=\"'Cancled'\">\n      <ion-item lines=\"none\" *ngFor=\"let item of [0, 1, 2]\">\n        <ion-thumbnail slot=\"start\">\n          <img src=\"../../../assets/images/General/Rectangle.png\" />\n        </ion-thumbnail>\n        <ion-label>\n          <h2 class=\"title\">RedBox Barber</h2>\n          <p class=\"service-name\">HairCut</p>\n          <p class=\"service-provide\">George Stephen</p>\n          <p class=\"address\">Rainbow piolly partke 4332</p>\n        </ion-label>\n        <div slot=\"end\" class=\"end-div ion-text-right\">\n          <div class=\"calendor-icon\">\n            <ion-icon\n              src=\"../../../assets/images/General/noun_Calendar_2577480.svg\"\n            ></ion-icon>\n          </div>\n          <p class=\"date\">20-jan-2019</p>\n          <h4 class=\"time\">12:45 PM</h4>\n        </div>\n      </ion-item>\n    </div>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/appoinments-list/appoinments-list.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/pages/appoinments-list/appoinments-list.page.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: var(--ion-color-white-light); }\n  ion-header ion-toolbar ion-segment-button {\n    text-transform: initial;\n    --background: transparent;\n    --background-activated: transparent;\n    --background-checked: transparent;\n    --background-hover: transparent;\n    --padding-start: 0px;\n    --padding-end: 0px;\n    --border-width: 0px !important;\n    --color-checked: var(--ion-color-black);\n    --color: var(--ion-color-lightGray);\n    --indicator-color: transparent !important;\n    --indicator-color-checked: transparent !important;\n    font-size: 16px;\n    font-family: 'tofini_regular'; }\n  ion-header ion-toolbar ion-segment-button:first-child {\n      margin-left: 15px; }\n  ion-header ion-toolbar ion-segment-button:last-child {\n      margin-right: 15px; }\n  ion-header ion-toolbar ion-segment-button ion-label {\n      margin-bottom: 0px; }\n  ion-header ion-toolbar ion-segment-button ion-label div {\n        height: 3px;\n        margin-top: 4px;\n        background: transparent; }\n  ion-header ion-toolbar ion-segment-button ion-label .active-segment-line {\n        background: var(--ion-color-gradiant); }\n  ion-header ion-title {\n  font-size: 16px;\n  font-family: 'tofini_medium';\n  color: var(--ion-color-black); }\n  ion-content {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  --background: rgba(253, 108, 87, 0.1); }\n  ion-content ion-item {\n    --background: var(--ion-color-white);\n    border-radius: 10px;\n    margin: 10px 0px; }\n  ion-content ion-item ion-thumbnail {\n      height: 66px;\n      width: 66px;\n      border-radius: 10px; }\n  ion-content ion-item ion-thumbnail img {\n        border-radius: 10px; }\n  ion-content ion-item .title {\n      font-size: 15px;\n      font-family: 'tofini_medium';\n      margin-bottom: 0px; }\n  ion-content ion-item .service-name {\n      font-size: 12px;\n      font-family: 'tofini_medium';\n      margin: 0px;\n      line-height: 15px;\n      color: var(--ion-color-MiddleGray); }\n  ion-content ion-item .service-provide {\n      font-size: 12px;\n      font-family: 'tofini_medium';\n      margin: 0px;\n      line-height: 15px;\n      color: var(--ion-color-gray); }\n  ion-content ion-item .address {\n      font-size: 12px;\n      line-height: 14px;\n      font-family: 'tofini_regular';\n      white-space: initial;\n      margin-top: 8px;\n      color: var(--ion-color-lightGray); }\n  ion-content ion-item .end-div {\n      margin-left: 10px; }\n  ion-content ion-item .end-div .calendor-icon {\n        padding: 3px;\n        background: rgba(253, 108, 87, 0.3);\n        border-radius: 50%;\n        height: 25px;\n        width: 25px;\n        text-align: center;\n        padding-top: 5px;\n        margin-bottom: 7px;\n        margin: 0px 0px 7px auto; }\n  ion-content ion-item .end-div .calendor-icon ion-icon {\n          font-size: 13px;\n          color: var(--ion-color-orange); }\n  ion-content ion-item .end-div .date {\n        margin: 0px;\n        font-size: 11px;\n        font-family: 'tofini_regular';\n        color: var(--ion-color-simpleDark); }\n  ion-content ion-item .end-div .time {\n        font-family: 'tofini_medium';\n        font-size: 14px;\n        margin: 3px 0px 0px 0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYXBwb2lubWVudHMtbGlzdC9EOlxcaW9uaWMgNFxcQm9vayBBIFBvaW50L3NyY1xcYXBwXFxwYWdlc1xcYXBwb2lubWVudHMtbGlzdFxcYXBwb2lubWVudHMtbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSwwQ0FBYSxFQUFBO0VBRmpCO0lBSU0sdUJBQXVCO0lBQ3ZCLHlCQUFhO0lBQ2IsbUNBQXVCO0lBQ3ZCLGlDQUFxQjtJQUNyQiwrQkFBbUI7SUFDbkIsb0JBQWdCO0lBQ2hCLGtCQUFjO0lBQ2QsOEJBQWU7SUFDZix1Q0FBZ0I7SUFDaEIsbUNBQVE7SUFDUix5Q0FBa0I7SUFDbEIsaURBQTBCO0lBQzFCLGVBQWU7SUFDZiw2QkFBNkIsRUFBQTtFQWpCbkM7TUFtQlEsaUJBQWlCLEVBQUE7RUFuQnpCO01Bc0JRLGtCQUFrQixFQUFBO0VBdEIxQjtNQTBCUSxrQkFBa0IsRUFBQTtFQTFCMUI7UUE2QlUsV0FBVztRQUNYLGVBQWU7UUFDZix1QkFBdUIsRUFBQTtFQS9CakM7UUFrQ1UscUNBQXFDLEVBQUE7RUFsQy9DO0VBeUNJLGVBQWU7RUFDZiw0QkFBNEI7RUFDNUIsNkJBQTZCLEVBQUE7RUFHakM7RUFDRSxxQkFBZ0I7RUFDaEIsbUJBQWM7RUFDZCxxQ0FBYSxFQUFBO0VBSGY7SUFNSSxvQ0FBYTtJQUNiLG1CQUFtQjtJQUNuQixnQkFBZ0IsRUFBQTtFQVJwQjtNQVdNLFlBQVk7TUFDWixXQUFXO01BQ1gsbUJBQW1CLEVBQUE7RUFiekI7UUFlUSxtQkFBbUIsRUFBQTtFQWYzQjtNQW1CTSxlQUFlO01BQ2YsNEJBQTRCO01BQzVCLGtCQUFrQixFQUFBO0VBckJ4QjtNQXdCTSxlQUFlO01BQ2YsNEJBQTRCO01BQzVCLFdBQVc7TUFDWCxpQkFBaUI7TUFDakIsa0NBQWtDLEVBQUE7RUE1QnhDO01BK0JNLGVBQWU7TUFDZiw0QkFBNEI7TUFDNUIsV0FBVztNQUNYLGlCQUFpQjtNQUNqQiw0QkFBNEIsRUFBQTtFQW5DbEM7TUFzQ00sZUFBZTtNQUNmLGlCQUFpQjtNQUNqQiw2QkFBNkI7TUFDN0Isb0JBQW9CO01BQ3BCLGVBQWU7TUFDZixpQ0FBaUMsRUFBQTtFQTNDdkM7TUE4Q00saUJBQWlCLEVBQUE7RUE5Q3ZCO1FBZ0RRLFlBQVk7UUFDWixtQ0FBbUM7UUFDbkMsa0JBQWtCO1FBQ2xCLFlBQVk7UUFDWixXQUFXO1FBQ1gsa0JBQWtCO1FBQ2xCLGdCQUFnQjtRQUNoQixrQkFBa0I7UUFDbEIsd0JBQXdCLEVBQUE7RUF4RGhDO1VBMkRVLGVBQWU7VUFDZiw4QkFBOEIsRUFBQTtFQTVEeEM7UUFnRVEsV0FBVztRQUNYLGVBQWU7UUFDZiw2QkFBNkI7UUFDN0Isa0NBQWtDLEVBQUE7RUFuRTFDO1FBc0VRLDRCQUE0QjtRQUM1QixlQUFlO1FBQ2YsdUJBQXVCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9hcHBvaW5tZW50cy1saXN0L2FwcG9pbm1lbnRzLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUtbGlnaHQpO1xyXG4gICAgaW9uLXNlZ21lbnQtYnV0dG9uIHtcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAtLWJhY2tncm91bmQtY2hlY2tlZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIC0tYmFja2dyb3VuZC1ob3ZlcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG4gICAgICAtLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgICAgIC0tYm9yZGVyLXdpZHRoOiAwcHggIWltcG9ydGFudDtcclxuICAgICAgLS1jb2xvci1jaGVja2VkOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHRHcmF5KTtcclxuICAgICAgLS1pbmRpY2F0b3ItY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICAgIC0taW5kaWNhdG9yLWNvbG9yLWNoZWNrZWQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICAgICY6Zmlyc3QtY2hpbGQge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgICB9XHJcbiAgICAgICY6bGFzdC1jaGlsZCB7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuXHJcbiAgICAgICAgZGl2IHtcclxuICAgICAgICAgIGhlaWdodDogM3B4O1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogNHB4O1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hY3RpdmUtc2VnbWVudC1saW5lIHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1ncmFkaWFudCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDI1MywgMTA4LCA4NywgMC4xKTtcclxuXHJcbiAgaW9uLWl0ZW0ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIG1hcmdpbjogMTBweCAwcHg7XHJcblxyXG4gICAgaW9uLXRodW1ibmFpbCB7XHJcbiAgICAgIGhlaWdodDogNjZweDtcclxuICAgICAgd2lkdGg6IDY2cHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgIGltZyB7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLnRpdGxlIHtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9tZWRpdW0nO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICB9XHJcbiAgICAuc2VydmljZS1uYW1lIHtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9tZWRpdW0nO1xyXG4gICAgICBtYXJnaW46IDBweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDE1cHg7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItTWlkZGxlR3JheSk7XHJcbiAgICB9XHJcbiAgICAuc2VydmljZS1wcm92aWRlIHtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9tZWRpdW0nO1xyXG4gICAgICBtYXJnaW46IDBweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDE1cHg7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZ3JheSk7XHJcbiAgICB9XHJcbiAgICAuYWRkcmVzcyB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDE0cHg7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgICB3aGl0ZS1zcGFjZTogaW5pdGlhbDtcclxuICAgICAgbWFyZ2luLXRvcDogOHB4O1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0R3JheSk7XHJcbiAgICB9XHJcbiAgICAuZW5kLWRpdiB7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICAgICAuY2FsZW5kb3ItaWNvbiB7XHJcbiAgICAgICAgcGFkZGluZzogM3B4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMjUzLCAxMDgsIDg3LCAwLjMpO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICBoZWlnaHQ6IDI1cHg7XHJcbiAgICAgICAgd2lkdGg6IDI1cHg7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiA1cHg7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogN3B4O1xyXG4gICAgICAgIG1hcmdpbjogMHB4IDBweCA3cHggYXV0bztcclxuXHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuZGF0ZSB7XHJcbiAgICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2ltcGxlRGFyayk7XHJcbiAgICAgIH1cclxuICAgICAgLnRpbWUge1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIG1hcmdpbjogM3B4IDBweCAwcHggMHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/appoinments-list/appoinments-list.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/appoinments-list/appoinments-list.page.ts ***!
  \*****************************************************************/
/*! exports provided: AppoinmentsListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppoinmentsListPage", function() { return AppoinmentsListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppoinmentsListPage = /** @class */ (function () {
    function AppoinmentsListPage() {
        this.activeTab = 'Upcomming';
    }
    AppoinmentsListPage.prototype.ngOnInit = function () { };
    AppoinmentsListPage.prototype.chageViewAppoinment = function (event) {
        this.activeTab = event.detail.value;
    };
    AppoinmentsListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-appoinments-list',
            template: __webpack_require__(/*! ./appoinments-list.page.html */ "./src/app/pages/appoinments-list/appoinments-list.page.html"),
            styles: [__webpack_require__(/*! ./appoinments-list.page.scss */ "./src/app/pages/appoinments-list/appoinments-list.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AppoinmentsListPage);
    return AppoinmentsListPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-appoinments-list-appoinments-list-module.js.map