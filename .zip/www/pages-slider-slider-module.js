(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-slider-slider-module"],{

/***/ "./src/app/pages/slider/slider.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/slider/slider.module.ts ***!
  \***********************************************/
/*! exports provided: SliderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SliderPageModule", function() { return SliderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _slider_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./slider.page */ "./src/app/pages/slider/slider.page.ts");







var routes = [
    {
        path: '',
        component: _slider_page__WEBPACK_IMPORTED_MODULE_6__["SliderPage"]
    }
];
var SliderPageModule = /** @class */ (function () {
    function SliderPageModule() {
    }
    SliderPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_slider_page__WEBPACK_IMPORTED_MODULE_6__["SliderPage"]]
        })
    ], SliderPageModule);
    return SliderPageModule;
}());



/***/ }),

/***/ "./src/app/pages/slider/slider.page.html":
/*!***********************************************!*\
  !*** ./src/app/pages/slider/slider.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <ion-slides #slides pager=\"true\" [options]=\"slideOpts\">\n    <ion-slide>\n      <div class=\"slide slide1\">\n        <img src=\"../../../assets/images/slider/Slide19.svg\" alt=\"\" />\n      </div>\n      <h3 class=\"title ion-text-center\">Find and Book Services</h3>\n      <p class=\"description ion-text-center\">\n        Find and book Barber, Beauty, Salon & Spa <br />\n        services anywhere, anytime.\n      </p>\n    </ion-slide>\n    <ion-slide>\n      <div class=\"slide slide2\">\n        <img src=\"../../../assets/images/slider/Slide19.svg\" alt=\"\" />\n      </div>\n      <h3 class=\"title ion-text-center\">Style that fit your Lifestyle</h3>\n      <p class=\"description ion-text-center\">\n        Choose our Makeup special offer price <br />\n        Package that fit your Lifestyle.\n      </p>\n    </ion-slide>\n  </ion-slides>\n  <ion-button class=\"btn-start ion-text-capitalize\" *ngIf=\"activeIndex == 0\" mode=\"md\" expand=\"full\" shape=\"round\"\n    fill=\"solid\" (click)=\"next()\">\n    Next\n  </ion-button>\n  <ion-button class=\"btn-start ion-text-capitalize\" *ngIf=\"activeIndex == 1\" mode=\"md\" expand=\"full\" shape=\"round\"\n    fill=\"solid\" (click)=\"start()\">\n    Get Started\n  </ion-button>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/slider/slider.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pages/slider/slider.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content ion-slides {\n  height: 560px;\n  --bullet-background-active: var(--ion-color-darkYellow);\n  --bullet-background: var(--ion-color-lightGray); }\n  ion-content ion-slides .swiper-slide {\n    display: block; }\n  ion-content ion-slides .slide {\n    height: 388px;\n    width: 100%;\n    display: block; }\n  ion-content ion-slides .slide img {\n      height: 100%;\n      width: 100%; }\n  ion-content ion-slides .slide1 {\n    background: url('Slide1.png') no-repeat;\n    background-size: 100% 100%; }\n  ion-content ion-slides .slide2 {\n    background: url('Slider2.png') no-repeat;\n    background-size: 100% 100%; }\n  ion-content ion-slides .title {\n    font-family: 'tofini_bold';\n    margin-top: 70px; }\n  ion-content ion-slides .description {\n    font-family: 'tofini_regular';\n    font-size: 15px;\n    color: var(--ion-color-lightGray); }\n  ion-content .btn-start {\n  --color: var(--ion-color-white);\n  height: 44px;\n  margin: 25px 32px 0px 32px;\n  font-size: 15px;\n  --box-shadow: none;\n  font-family: 'tofini_regular';\n  --background: var(--ion-color-gradiant); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2xpZGVyL0Q6XFxpb25pYyA0XFxCb29rIEEgUG9pbnQvc3JjXFxhcHBcXHBhZ2VzXFxzbGlkZXJcXHNsaWRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxhQUFhO0VBQ2IsdURBQTJCO0VBQzNCLCtDQUFvQixFQUFBO0VBSnhCO0lBTU0sY0FBYyxFQUFBO0VBTnBCO0lBU00sYUFBYTtJQUNiLFdBQVc7SUFDWCxjQUFjLEVBQUE7RUFYcEI7TUFhUSxZQUFZO01BQ1osV0FBVyxFQUFBO0VBZG5CO0lBa0JNLHVDQUFtRTtJQUNuRSwwQkFBMEIsRUFBQTtFQW5CaEM7SUFzQk0sd0NBQW9FO0lBQ3BFLDBCQUEwQixFQUFBO0VBdkJoQztJQTJCTSwwQkFBMEI7SUFDMUIsZ0JBQWdCLEVBQUE7RUE1QnRCO0lBK0JNLDZCQUE2QjtJQUM3QixlQUFlO0lBQ2YsaUNBQWlDLEVBQUE7RUFqQ3ZDO0VBcUNJLCtCQUFRO0VBQ1IsWUFBWTtFQUNaLDBCQUEwQjtFQUMxQixlQUFlO0VBQ2Ysa0JBQWE7RUFDYiw2QkFBNkI7RUFDN0IsdUNBQWEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NsaWRlci9zbGlkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIGlvbi1zbGlkZXMge1xyXG4gICAgaGVpZ2h0OiA1NjBweDtcclxuICAgIC0tYnVsbGV0LWJhY2tncm91bmQtYWN0aXZlOiB2YXIoLS1pb24tY29sb3ItZGFya1llbGxvdyk7XHJcbiAgICAtLWJ1bGxldC1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHRHcmF5KTtcclxuICAgIC5zd2lwZXItc2xpZGUge1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIH1cclxuICAgIC5zbGlkZSB7XHJcbiAgICAgIGhlaWdodDogMzg4cHg7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgaW1nIHtcclxuICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5zbGlkZTEge1xyXG4gICAgICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9zbGlkZXIvU2xpZGUxLnBuZykgbm8tcmVwZWF0O1xyXG4gICAgICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTAwJTtcclxuICAgIH1cclxuICAgIC5zbGlkZTIge1xyXG4gICAgICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9zbGlkZXIvU2xpZGVyMi5wbmcpIG5vLXJlcGVhdDtcclxuICAgICAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XHJcbiAgICB9XHJcblxyXG4gICAgLnRpdGxlIHtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfYm9sZCc7XHJcbiAgICAgIG1hcmdpbi10b3A6IDcwcHg7XHJcbiAgICB9XHJcbiAgICAuZGVzY3JpcHRpb24ge1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0R3JheSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5idG4tc3RhcnQge1xyXG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIG1hcmdpbjogMjVweCAzMnB4IDBweCAzMnB4O1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1ncmFkaWFudCk7XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/slider/slider.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/slider/slider.page.ts ***!
  \*********************************************/
/*! exports provided: SliderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SliderPage", function() { return SliderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var SliderPage = /** @class */ (function () {
    function SliderPage(navCtrl) {
        this.navCtrl = navCtrl;
        this.activeIndex = 0;
        this.slideOpts = {
            speed: 400
        };
    }
    SliderPage.prototype.ngOnInit = function () {
        this.slides.lockSwipes(true);
    };
    SliderPage.prototype.next = function () {
        this.slides.lockSwipes(false);
        this.slides.slideNext();
        this.slides.lockSwipes(true);
        this.activeIndex = 1;
    };
    SliderPage.prototype.start = function () {
        this.navCtrl.setDirection("root");
        this.navCtrl.navigateRoot("/tabs/home");
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])("slides"),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SliderPage.prototype, "slides", void 0);
    SliderPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-slider",
            template: __webpack_require__(/*! ./slider.page.html */ "./src/app/pages/slider/slider.page.html"),
            styles: [__webpack_require__(/*! ./slider.page.scss */ "./src/app/pages/slider/slider.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], SliderPage);
    return SliderPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-slider-slider-module.js.map