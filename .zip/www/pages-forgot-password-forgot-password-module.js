(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-forgot-password-forgot-password-module"],{

/***/ "./src/app/pages/forgot-password/forgot-password.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.module.ts ***!
  \*****************************************************************/
/*! exports provided: ForgotPasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordPageModule", function() { return ForgotPasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./forgot-password.page */ "./src/app/pages/forgot-password/forgot-password.page.ts");







var routes = [
    {
        path: '',
        component: _forgot_password_page__WEBPACK_IMPORTED_MODULE_6__["ForgotPasswordPage"]
    }
];
var ForgotPasswordPageModule = /** @class */ (function () {
    function ForgotPasswordPageModule() {
    }
    ForgotPasswordPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_forgot_password_page__WEBPACK_IMPORTED_MODULE_6__["ForgotPasswordPage"]]
        })
    ], ForgotPasswordPageModule);
    return ForgotPasswordPageModule;
}());



/***/ }),

/***/ "./src/app/pages/forgot-password/forgot-password.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons>\n      <ion-button fill=\"clear\" mode=\"md\" (click)=\"backPage()\">\n        <ion-icon src=\"../../../assets/images/General/noun_Arrow_1256499.svg\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <h1 class=\"title ion-text-center\">Forgot password</h1>\n  <p class=\"content ion-text-center\">Please enter your email address. You will <br> receive a code to create a new\n    password <br> via email.</p>\n  <form>\n    <ion-input placeholder=\"Your email address\" name=\"email\" [(ngModel)]=\"email\" type=\"text\"></ion-input>\n    <ion-button class=\"btn-forgot\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\" (click)=\"resetPassword()\">\n      Reset password\n    </ion-button>\n  </form>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/forgot-password/forgot-password.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-button {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --ripple-color: var(--ion-color-white);\n  margin-left: 15px; }\n  ion-header ion-button ion-icon {\n    width: 23.74px;\n    height: 20px; }\n  ion-content {\n  --padding-end: 24px;\n  --padding-start: 24px; }\n  ion-content .title {\n    font-family: 'tofini_bold';\n    font-size: 30px;\n    margin-bottom: 18px; }\n  ion-content .content {\n    color: var(--ion-color-lightDark);\n    font-size: 15px;\n    font-family: 'tofini_regular';\n    margin-bottom: 0px; }\n  ion-content ion-input {\n    --background: var(--ion-input-back);\n    height: 44px;\n    border-radius: 22px;\n    --padding-start: 24px;\n    --padding-top: 16px;\n    --padding-bottom: 13px;\n    font-family: 'tofini_regular';\n    font-size: 15px;\n    margin-top: 48px;\n    --placeholder-color: var(--ion-placeholder-color); }\n  ion-content .btn-forgot {\n    --color: var(--ion-color-white);\n    height: 44px;\n    margin: 40px 8px 0px 8px;\n    font-size: 15px;\n    --box-shadow: none;\n    font-family: 'tofini_regular';\n    --background: var(--ion-color-gradiant);\n    text-transform: inherit; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZm9yZ290LXBhc3N3b3JkL0Q6XFxpb25pYyA0XFxCb29rIEEgUG9pbnQvc3JjXFxhcHBcXHBhZ2VzXFxmb3Jnb3QtcGFzc3dvcmRcXGZvcmdvdC1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxvQkFBZ0I7RUFDaEIsa0JBQWM7RUFDZCxzQ0FBZTtFQUNmLGlCQUFpQixFQUFBO0VBTHJCO0lBT00sY0FBYztJQUNkLFlBQVksRUFBQTtFQUlsQjtFQUNFLG1CQUFjO0VBQ2QscUJBQWdCLEVBQUE7RUFGbEI7SUFJSSwwQkFBMEI7SUFDMUIsZUFBZTtJQUNmLG1CQUFtQixFQUFBO0VBTnZCO0lBU0ksaUNBQWlDO0lBQ2pDLGVBQWU7SUFDZiw2QkFBNkI7SUFDN0Isa0JBQWtCLEVBQUE7RUFadEI7SUFlSSxtQ0FBYTtJQUNiLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIscUJBQWdCO0lBQ2hCLG1CQUFjO0lBQ2Qsc0JBQWlCO0lBQ2pCLDZCQUE2QjtJQUM3QixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGlEQUFvQixFQUFBO0VBeEJ4QjtJQTRCSSwrQkFBUTtJQUNSLFlBQVk7SUFDWix3QkFBd0I7SUFDeEIsZUFBZTtJQUNmLGtCQUFhO0lBQ2IsNkJBQTZCO0lBQzdCLHVDQUFhO0lBQ2IsdUJBQXVCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9mb3Jnb3QtcGFzc3dvcmQvZm9yZ290LXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGlvbi1idXR0b24ge1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcbiAgICAtLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgICAtLXJpcHBsZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICB3aWR0aDogMjMuNzRweDtcclxuICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1wYWRkaW5nLWVuZDogMjRweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDI0cHg7XHJcbiAgLnRpdGxlIHtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX2JvbGQnO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMThweDtcclxuICB9XHJcbiAgLmNvbnRlbnQge1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodERhcmspO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgfVxyXG4gIGlvbi1pbnB1dCB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pbnB1dC1iYWNrKTtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIycHg7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDI0cHg7XHJcbiAgICAtLXBhZGRpbmctdG9wOiAxNnB4O1xyXG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMTNweDtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogNDhweDtcclxuICAgIC0tcGxhY2Vob2xkZXItY29sb3I6IHZhcigtLWlvbi1wbGFjZWhvbGRlci1jb2xvcik7XHJcbiAgfVxyXG5cclxuICAuYnRuLWZvcmdvdCB7XHJcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgbWFyZ2luOiA0MHB4IDhweCAwcHggOHB4O1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1ncmFkaWFudCk7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5oZXJpdDtcclxuICB9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/forgot-password/forgot-password.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.page.ts ***!
  \***************************************************************/
/*! exports provided: ForgotPasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordPage", function() { return ForgotPasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _code_send_modal_code_send_modal_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../code-send-modal/code-send-modal.page */ "./src/app/pages/code-send-modal/code-send-modal.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");




var ForgotPasswordPage = /** @class */ (function () {
    function ForgotPasswordPage(navCtrl, modalController) {
        this.navCtrl = navCtrl;
        this.modalController = modalController;
    }
    ForgotPasswordPage.prototype.ngOnInit = function () { };
    ForgotPasswordPage.prototype.backPage = function () {
        this.navCtrl.back();
    };
    ForgotPasswordPage.prototype.resetPassword = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _code_send_modal_code_send_modal_page__WEBPACK_IMPORTED_MODULE_1__["CodeSendModalPage"],
                            cssClass: 'code-modal'
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    ForgotPasswordPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-forgot-password',
            template: __webpack_require__(/*! ./forgot-password.page.html */ "./src/app/pages/forgot-password/forgot-password.page.html"),
            styles: [__webpack_require__(/*! ./forgot-password.page.scss */ "./src/app/pages/forgot-password/forgot-password.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], ForgotPasswordPage);
    return ForgotPasswordPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-forgot-password-forgot-password-module.js.map