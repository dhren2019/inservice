(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-booking-detail-booking-detail-module"],{

/***/ "./src/app/pages/booking-detail/booking-detail.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/booking-detail/booking-detail.module.ts ***!
  \***************************************************************/
/*! exports provided: BookingDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingDetailPageModule", function() { return BookingDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _booking_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./booking-detail.page */ "./src/app/pages/booking-detail/booking-detail.page.ts");







var routes = [
    {
        path: '',
        component: _booking_detail_page__WEBPACK_IMPORTED_MODULE_6__["BookingDetailPage"]
    }
];
var BookingDetailPageModule = /** @class */ (function () {
    function BookingDetailPageModule() {
    }
    BookingDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_booking_detail_page__WEBPACK_IMPORTED_MODULE_6__["BookingDetailPage"]]
        })
    ], BookingDetailPageModule);
    return BookingDetailPageModule;
}());



/***/ }),

/***/ "./src/app/pages/booking-detail/booking-detail.page.html":
/*!***************************************************************!*\
  !*** ./src/app/pages/booking-detail/booking-detail.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" mode=\"md\" (click)=\"backPage()\">\n        <ion-icon src=\"../../../assets/images/General/noun_Arrow_1256499.svg\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Booking Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"serviceiDetail\">\n    <ion-row no-padding>\n      <ion-col size=\"4\" size-md=\"2\" size-xl=\"1\" no-padding>\n        <img class=\"salon-img\" src=\"../../../assets/images/General/Rectangle.png\" alt=\"\" />\n      </ion-col>\n      <ion-col size=\"8\" size-md=\"10\" size-xl=\"11\" no-padding padding-left>\n        <h4 class=\"title \">\n          RedBox Barber\n          <span class=\"start-span ion-float-right\">\n            <img src=\"../../../assets/images/General/ic_star.svg\" alt=\"\" />4.0</span>\n        </h4>\n        <p class=\"address ion-no-margin\">288 McClure Court, Arkansas</p>\n        <p class=\"distance\" style=\"margin-top: 8px;\">\n          <img style=\"margin-bottom: -1px;margin-right: 3px;\" src=\"../../../assets/images/General/ic_location.svg\"\n            alt=\"\" />\n          1.2 km\n        </p>\n        <p class=\"services\">\n          <span>Services : </span> Heir cut, Facial and Makeup\n        </p>\n      </ion-col>\n    </ion-row>\n    <p class=\"amount-tolal\">Total: <span class=\"amount\">$45.00</span></p>\n    <div class=\"date-time\">\n      <p>\n        <img src=\"../../../assets/images/General/noun_Calendar_2577480.svg\" alt=\"\" /><span>Friday,</span> 25 August 2019\n        <span>@ 8:30am</span>\n      </p>\n    </div>\n  </div>\n  <div class=\"payment-section\">\n    <h4 class=\"payment-title\">\n      Payment Method\n      <ion-button class=\"btn-add-card ion-float-right\" fill=\"clear\" size=\"small\">\n        + Add a new card\n      </ion-button>\n    </h4>\n    <ion-radio-group [(ngModel)]=\"paymentType\">\n\n      <ion-item lines=\"none\" [ngClass]=\"{ active: paymentType == 'Bank Account' }\">\n        <img slot=\"start\" class=\"bank\" src=\"../../../assets/images/General/bank-image.PNG\" />\n        <ion-label>\n          <h4>Bank Account</h4>\n          <p>Ending in 9473</p>\n        </ion-label>\n        <ion-radio slot=\"end\" mode=\"md\" value=\"Bank Account\"></ion-radio>\n      </ion-item>\n      <ion-item lines=\"none\" [ngClass]=\"{ active: paymentType == 'PayPal' }\">\n        <img slot=\"start\" class=\"paypal\" class=\"bank\" src=\"../../../assets/images/General/paypal.PNG\" />\n        <ion-label>\n          <h4>PayPal</h4>\n          <p>my.paypal@gmail.com</p>\n        </ion-label>\n        <ion-radio slot=\"end\" mode=\"md\" value=\"PayPal\" checked></ion-radio>\n      </ion-item>\n    </ion-radio-group>\n\n    <ion-button class=\"btn-continue\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\" (click)=\"continue()\">\n      Continue with {{ paymentType }}\n    </ion-button>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/booking-detail/booking-detail.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/pages/booking-detail/booking-detail.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: var(--ion-color-white-light);\n  border-bottom: 1px solid var(--ion-border-color); }\n\nion-header ion-button {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --ripple-color: var(--ion-color-white);\n  margin-left: 15px; }\n\nion-header ion-button ion-icon {\n    width: 23.74px;\n    height: 20px; }\n\nion-header ion-title {\n  font-size: 17px;\n  font-family: 'tofini_medium';\n  --color: var(--ion-color-black);\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  text-align: center; }\n\nion-content {\n  --background: #f7f8f9; }\n\nion-content .serviceiDetail {\n    padding: 16px 16px 24px 16px;\n    border-radius: 0px 0px 10px 10px;\n    box-shadow: 0px 4px 8px #ddd;\n    background: var(--ion-color-white); }\n\nion-content .serviceiDetail .salon-img {\n      width: 100px;\n      height: 90px;\n      border-radius: 10px; }\n\nion-content .serviceiDetail .title {\n      font-size: 18px;\n      font-family: 'tofini_medium';\n      margin-top: 0px;\n      margin-bottom: 5px; }\n\nion-content .serviceiDetail .title .start-span {\n        font-size: 13px;\n        color: var(--ion-color-simpleDark); }\n\nion-content .serviceiDetail .title .start-span img {\n          margin-right: 4px; }\n\nion-content .serviceiDetail .address,\n    ion-content .serviceiDetail .distance {\n      font-size: 12px;\n      font-family: 'tofini_regular';\n      color: var(--ion-color-lightGray); }\n\nion-content .serviceiDetail .services {\n      font-size: 12px;\n      font-family: 'tofini_regular';\n      color: var(--ion-color-lightGray);\n      margin-bottom: 0px;\n      margin-top: 14px; }\n\nion-content .serviceiDetail .services span {\n        color: var(--ion-color-black);\n        font-family: 'tofini_medium';\n        font-weight: 600; }\n\nion-content .serviceiDetail .amount-tolal {\n      font-size: 14px;\n      font-family: 'tofini_medium';\n      margin-top: 7px; }\n\nion-content .serviceiDetail .amount-tolal .amount {\n        color: var(--ion-color-orange);\n        font-family: 'tofini_bold'; }\n\nion-content .serviceiDetail .date-time {\n      background: var(--ion-input-back);\n      border-radius: 22px;\n      text-align: center;\n      padding: 11px 0px 13px;\n      margin-top: 18px; }\n\nion-content .serviceiDetail .date-time p {\n        font-size: 14px;\n        font-family: 'tofini_regular';\n        color: var(--ion-color-lightGray);\n        margin: 0px; }\n\nion-content .serviceiDetail .date-time p img {\n          height: 21px;\n          width: 21px;\n          margin-bottom: -5px;\n          margin-right: 13px; }\n\nion-content .serviceiDetail .date-time p span {\n          color: var(--ion-color-lightDark); }\n\nion-content .payment-section {\n    padding: 0px 16px 24px 16px; }\n\nion-content .payment-section .payment-title {\n      margin-top: 4vh;\n      font-size: 16px;\n      font-family: 'tofini_medium';\n      color: var(--ion-color-MiddleGray); }\n\nion-content .payment-section .payment-title .btn-add-card {\n        height: 1em;\n        font-size: 14px;\n        text-transform: initial;\n        --padding-start: 0em;\n        --padding-end: 0em;\n        margin-top: 2px; }\n\nion-content .payment-section ion-item {\n      --min-height: 76px;\n      --padding-start: 22px;\n      border-radius: 10px;\n      box-shadow: 0px 4px 8px #dbdbdb;\n      border: 2px solid var(--ion-color-white);\n      margin-bottom: 14px;\n      --ripple-color: var(--ion-color-white); }\n\nion-content .payment-section ion-item img {\n        margin-right: 18px; }\n\nion-content .payment-section ion-item .card {\n        height: 40px;\n        width: 46px; }\n\nion-content .payment-section ion-item .bank {\n        height: 46px;\n        width: 46px; }\n\nion-content .payment-section ion-item .paypal {\n        height: 40px;\n        width: 34px; }\n\nion-content .payment-section ion-item h4 {\n        font-size: 18px;\n        font-family: 'tofini_medium';\n        margin-top: 0px; }\n\nion-content .payment-section ion-item p {\n        font-size: 13px;\n        font-family: 'tofini_regular';\n        color: var(--ion-color-simpleDark); }\n\nion-content .payment-section ion-item ion-radio {\n        -webkit-margin-start: 11px;\n                margin-inline-start: 11px;\n        --border-width: 1px;\n        --color: var(--ion-color-simpleDark);\n        --color-checked: var(--ion-color-orange); }\n\nion-content .payment-section .active {\n      border-color: var(--ion-color-orange); }\n\nion-content .payment-section .btn-continue {\n      --color: var(--ion-color-white);\n      height: 44px;\n      margin: 40px 8px 0px 8px;\n      font-size: 15px;\n      --box-shadow: none;\n      font-family: 'tofini_regular';\n      --background: var(--ion-color-gradiant);\n      text-transform: inherit;\n      --padding-top: 3px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYm9va2luZy1kZXRhaWwvRDpcXGlvbmljIDRcXEJvb2sgQSBQb2ludC9zcmNcXGFwcFxccGFnZXNcXGJvb2tpbmctZGV0YWlsXFxib29raW5nLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSwwQ0FBYTtFQUNiLGdEQUFnRCxFQUFBOztBQUhwRDtFQU1JLG9CQUFnQjtFQUNoQixrQkFBYztFQUNkLHNDQUFlO0VBQ2YsaUJBQWlCLEVBQUE7O0FBVHJCO0lBV00sY0FBYztJQUNkLFlBQVksRUFBQTs7QUFabEI7RUFnQkksZUFBZTtFQUNmLDRCQUE0QjtFQUM1QiwrQkFBUTtFQUNSLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0UscUJBQWEsRUFBQTs7QUFEZjtJQUdJLDRCQUE0QjtJQUM1QixnQ0FBZ0M7SUFDaEMsNEJBQTRCO0lBQzVCLGtDQUFrQyxFQUFBOztBQU50QztNQVFNLFlBQVk7TUFDWixZQUFZO01BQ1osbUJBQW1CLEVBQUE7O0FBVnpCO01BYU0sZUFBZTtNQUNmLDRCQUE0QjtNQUM1QixlQUFlO01BQ2Ysa0JBQWtCLEVBQUE7O0FBaEJ4QjtRQWtCUSxlQUFlO1FBQ2Ysa0NBQWtDLEVBQUE7O0FBbkIxQztVQXFCVSxpQkFBaUIsRUFBQTs7QUFyQjNCOztNQTJCTSxlQUFlO01BQ2YsNkJBQTZCO01BQzdCLGlDQUFpQyxFQUFBOztBQTdCdkM7TUFnQ00sZUFBZTtNQUNmLDZCQUE2QjtNQUM3QixpQ0FBaUM7TUFDakMsa0JBQWtCO01BQ2xCLGdCQUFnQixFQUFBOztBQXBDdEI7UUFzQ1EsNkJBQTZCO1FBQzdCLDRCQUE0QjtRQUM1QixnQkFBZ0IsRUFBQTs7QUF4Q3hCO01BNENNLGVBQWU7TUFDZiw0QkFBNEI7TUFDNUIsZUFBZSxFQUFBOztBQTlDckI7UUFpRFEsOEJBQThCO1FBQzlCLDBCQUEwQixFQUFBOztBQWxEbEM7TUFzRE0saUNBQWlDO01BQ2pDLG1CQUFtQjtNQUNuQixrQkFBa0I7TUFDbEIsc0JBQXNCO01BQ3RCLGdCQUFnQixFQUFBOztBQTFEdEI7UUE0RFEsZUFBZTtRQUNmLDZCQUE2QjtRQUM3QixpQ0FBaUM7UUFDakMsV0FBVyxFQUFBOztBQS9EbkI7VUFpRVUsWUFBWTtVQUNaLFdBQVc7VUFDWCxtQkFBbUI7VUFDbkIsa0JBQWtCLEVBQUE7O0FBcEU1QjtVQXVFVSxpQ0FBaUMsRUFBQTs7QUF2RTNDO0lBNkVJLDJCQUEyQixFQUFBOztBQTdFL0I7TUErRU0sZUFBZTtNQUNmLGVBQWU7TUFDZiw0QkFBNEI7TUFDNUIsa0NBQWtDLEVBQUE7O0FBbEZ4QztRQW9GUSxXQUFXO1FBQ1gsZUFBZTtRQUNmLHVCQUF1QjtRQUN2QixvQkFBZ0I7UUFDaEIsa0JBQWM7UUFDZCxlQUFlLEVBQUE7O0FBekZ2QjtNQTZGTSxrQkFBYTtNQUNiLHFCQUFnQjtNQUNoQixtQkFBbUI7TUFDbkIsK0JBQStCO01BQy9CLHdDQUF3QztNQUN4QyxtQkFBbUI7TUFDbkIsc0NBQWUsRUFBQTs7QUFuR3JCO1FBcUdRLGtCQUFrQixFQUFBOztBQXJHMUI7UUF3R1EsWUFBWTtRQUNaLFdBQVcsRUFBQTs7QUF6R25CO1FBNEdRLFlBQVk7UUFDWixXQUFXLEVBQUE7O0FBN0duQjtRQWdIUSxZQUFZO1FBQ1osV0FBVyxFQUFBOztBQWpIbkI7UUFvSFEsZUFBZTtRQUNmLDRCQUE0QjtRQUM1QixlQUFlLEVBQUE7O0FBdEh2QjtRQXlIUSxlQUFlO1FBQ2YsNkJBQTZCO1FBQzdCLGtDQUFrQyxFQUFBOztBQTNIMUM7UUE4SFEsMEJBQXlCO2dCQUF6Qix5QkFBeUI7UUFDekIsbUJBQWU7UUFDZixvQ0FBUTtRQUNSLHdDQUFnQixFQUFBOztBQWpJeEI7TUFxSU0scUNBQXFDLEVBQUE7O0FBckkzQztNQXdJTSwrQkFBUTtNQUNSLFlBQVk7TUFDWix3QkFBd0I7TUFDeEIsZUFBZTtNQUNmLGtCQUFhO01BQ2IsNkJBQTZCO01BQzdCLHVDQUFhO01BQ2IsdUJBQXVCO01BQ3ZCLGtCQUFjLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ib29raW5nLWRldGFpbC9ib29raW5nLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci13aGl0ZS1saWdodCk7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taW9uLWJvcmRlci1jb2xvcik7XHJcbiAgfVxyXG4gIGlvbi1idXR0b24ge1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcbiAgICAtLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgICAtLXJpcHBsZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICB3aWR0aDogMjMuNzRweDtcclxuICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgfVxyXG4gIH1cclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjayk7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG59XHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICNmN2Y4Zjk7XHJcbiAgLnNlcnZpY2VpRGV0YWlsIHtcclxuICAgIHBhZGRpbmc6IDE2cHggMTZweCAyNHB4IDE2cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDEwcHggMTBweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCA0cHggOHB4ICNkZGQ7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgLnNhbG9uLWltZyB7XHJcbiAgICAgIHdpZHRoOiAxMDBweDtcclxuICAgICAgaGVpZ2h0OiA5MHB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgfVxyXG4gICAgLnRpdGxlIHtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9tZWRpdW0nO1xyXG4gICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgICAgLnN0YXJ0LXNwYW4ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNpbXBsZURhcmspO1xyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5hZGRyZXNzLFxyXG4gICAgLmRpc3RhbmNlIHtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodEdyYXkpO1xyXG4gICAgfVxyXG4gICAgLnNlcnZpY2VzIHtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodEdyYXkpO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE0cHg7XHJcbiAgICAgIHNwYW4ge1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmFtb3VudC10b2xhbCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgICAgbWFyZ2luLXRvcDogN3B4O1xyXG5cclxuICAgICAgLmFtb3VudCB7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX2JvbGQnO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuZGF0ZS10aW1lIHtcclxuICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWlucHV0LWJhY2spO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAyMnB4O1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIHBhZGRpbmc6IDExcHggMHB4IDEzcHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE4cHg7XHJcbiAgICAgIHAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0R3JheSk7XHJcbiAgICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgICAgaW1nIHtcclxuICAgICAgICAgIGhlaWdodDogMjFweDtcclxuICAgICAgICAgIHdpZHRoOiAyMXB4O1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogLTVweDtcclxuICAgICAgICAgIG1hcmdpbi1yaWdodDogMTNweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0RGFyayk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5wYXltZW50LXNlY3Rpb24ge1xyXG4gICAgcGFkZGluZzogMHB4IDE2cHggMjRweCAxNnB4O1xyXG4gICAgLnBheW1lbnQtdGl0bGUge1xyXG4gICAgICBtYXJnaW4tdG9wOiA0dmg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1NaWRkbGVHcmF5KTtcclxuICAgICAgLmJ0bi1hZGQtY2FyZCB7XHJcbiAgICAgICAgaGVpZ2h0OiAxZW07XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xyXG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMGVtO1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDBlbTtcclxuICAgICAgICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlvbi1pdGVtIHtcclxuICAgICAgLS1taW4taGVpZ2h0OiA3NnB4O1xyXG4gICAgICAtLXBhZGRpbmctc3RhcnQ6IDIycHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgIGJveC1zaGFkb3c6IDBweCA0cHggOHB4ICNkYmRiZGI7XHJcbiAgICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDE0cHg7XHJcbiAgICAgIC0tcmlwcGxlLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDogMThweDtcclxuICAgICAgfVxyXG4gICAgICAuY2FyZCB7XHJcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgIHdpZHRoOiA0NnB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5iYW5rIHtcclxuICAgICAgICBoZWlnaHQ6IDQ2cHg7XHJcbiAgICAgICAgd2lkdGg6IDQ2cHg7XHJcbiAgICAgIH1cclxuICAgICAgLnBheXBhbCB7XHJcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgIHdpZHRoOiAzNHB4O1xyXG4gICAgICB9XHJcbiAgICAgIGg0IHtcclxuICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfbWVkaXVtJztcclxuICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICAgIH1cclxuICAgICAgcCB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2ltcGxlRGFyayk7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLXJhZGlvIHtcclxuICAgICAgICBtYXJnaW4taW5saW5lLXN0YXJ0OiAxMXB4O1xyXG4gICAgICAgIC0tYm9yZGVyLXdpZHRoOiAxcHg7XHJcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNpbXBsZURhcmspO1xyXG4gICAgICAgIC0tY29sb3ItY2hlY2tlZDogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5hY3RpdmUge1xyXG4gICAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgfVxyXG4gICAgLmJ0bi1jb250aW51ZSB7XHJcbiAgICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgIGhlaWdodDogNDRweDtcclxuICAgICAgbWFyZ2luOiA0MHB4IDhweCAwcHggOHB4O1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWdyYWRpYW50KTtcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IGluaGVyaXQ7XHJcbiAgICAgIC0tcGFkZGluZy10b3A6IDNweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/booking-detail/booking-detail.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/booking-detail/booking-detail.page.ts ***!
  \*************************************************************/
/*! exports provided: BookingDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingDetailPage", function() { return BookingDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _booking_successfully_booking_successfully_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../booking-successfully/booking-successfully.page */ "./src/app/pages/booking-successfully/booking-successfully.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");




var BookingDetailPage = /** @class */ (function () {
    function BookingDetailPage(modalController, navCtrl) {
        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.paymentType = 'Bank Account';
    }
    BookingDetailPage.prototype.ngOnInit = function () { };
    BookingDetailPage.prototype.backPage = function () {
        this.navCtrl.back();
    };
    BookingDetailPage.prototype.continue = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _booking_successfully_booking_successfully_page__WEBPACK_IMPORTED_MODULE_1__["BookingSuccessfullyPage"],
                            cssClass: 'success-modal'
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    BookingDetailPage.prototype.gotoAppoinment = function () { };
    BookingDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-booking-detail',
            template: __webpack_require__(/*! ./booking-detail.page.html */ "./src/app/pages/booking-detail/booking-detail.page.html"),
            styles: [__webpack_require__(/*! ./booking-detail.page.scss */ "./src/app/pages/booking-detail/booking-detail.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], BookingDetailPage);
    return BookingDetailPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-booking-detail-booking-detail-module.js.map