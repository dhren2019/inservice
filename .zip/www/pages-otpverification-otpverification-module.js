(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-otpverification-otpverification-module"],{

/***/ "./src/app/pages/otpverification/otpverification.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/otpverification/otpverification.module.ts ***!
  \*****************************************************************/
/*! exports provided: OTPVerificationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OTPVerificationPageModule", function() { return OTPVerificationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _otpverification_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./otpverification.page */ "./src/app/pages/otpverification/otpverification.page.ts");







var routes = [
    {
        path: '',
        component: _otpverification_page__WEBPACK_IMPORTED_MODULE_6__["OTPVerificationPage"]
    }
];
var OTPVerificationPageModule = /** @class */ (function () {
    function OTPVerificationPageModule() {
    }
    OTPVerificationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_otpverification_page__WEBPACK_IMPORTED_MODULE_6__["OTPVerificationPage"]]
        })
    ], OTPVerificationPageModule);
    return OTPVerificationPageModule;
}());



/***/ }),

/***/ "./src/app/pages/otpverification/otpverification.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/otpverification/otpverification.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons>\n      <ion-button fill=\"clear\" mode=\"md\" (click)=\"backPage()\">\n        <ion-icon\n          src=\"../../../assets/images/General/noun_Arrow_1256499.svg\"\n        ></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <h1 class=\"title ion-text-center\">Phone Verification</h1>\n  <p class=\"description ion-text-center\">Enter your OTP code here</p>\n\n  <div class=\"otp-input-div\">\n    <ion-input\n      autofocus\n      type=\"tel\"\n      name=\"a\"\n      [(ngModel)]=\"opt.a\"\n      #a\n      [ngClass]=\"{ 'otp-fill': opt.a?.length > 0 }\"\n      (keyup)=\"moveFocus($event, b, '')\"\n      maxlength=\"1\"\n    ></ion-input>\n    <ion-input\n      type=\"tel\"\n      name=\"b\"\n      [(ngModel)]=\"opt.b\"\n      #b\n      [ngClass]=\"{ 'otp-fill': opt.b?.length > 0 }\"\n      (keyup)=\"moveFocus($event, c, a)\"\n      maxlength=\"1\"\n    ></ion-input>\n    <ion-input\n      type=\"tel\"\n      name=\"c\"\n      [(ngModel)]=\"opt.c\"\n      #c\n      [ngClass]=\"{ 'otp-fill': opt.c?.length > 0 }\"\n      (keyup)=\"moveFocus($event, d, b)\"\n      maxlength=\"1\"\n    ></ion-input>\n    <ion-input\n      type=\"tel\"\n      name=\"d\"\n      [(ngModel)]=\"opt.d\"\n      #d\n      [ngClass]=\"{ 'otp-fill': opt.d?.length > 0 }\"\n      (keyup)=\"moveFocus($event, '', c)\"\n      maxlength=\"1\"\n    ></ion-input>\n  </div>\n  <p class=\"timer-text ion-text-center\">00 : 25</p>\n  <p class=\"social-link ion-text-center\">Didn’t you received any code?</p>\n  <ion-button\n    class=\"btn-resend\"\n    (click)=\"resendCode()\"\n    mode=\"md\"\n    fill=\"clear\"\n    expand=\"full\"\n    size=\"small\"\n  >\n    Resend a new code.\n  </ion-button>\n  <ion-button\n    class=\"btn-continue\"\n    mode=\"md\"\n    expand=\"full\"\n    shape=\"round\"\n    fill=\"solid\"\n    (click)=\"continue()\"\n  >\n    Continue\n  </ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/otpverification/otpverification.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/otpverification/otpverification.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-button {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --ripple-color: var(--ion-color-white);\n  margin-left: 15px; }\n  ion-header ion-button ion-icon {\n    width: 23.74px;\n    height: 20px; }\n  ion-content {\n  --padding-end: 24px;\n  --padding-start: 24px; }\n  ion-content .title {\n    font-family: 'tofini_bold';\n    font-size: 30px;\n    margin-bottom: 23px; }\n  ion-content .description {\n    color: var(--ion-color-lightDark);\n    font-size: 15px;\n    font-family: 'tofini_regular';\n    margin-bottom: 0px;\n    line-height: 20px; }\n  ion-content .otp-input-div {\n    display: inline-flex;\n    transform: translateX(-50%);\n    left: 50%;\n    position: relative;\n    margin-top: 56px; }\n  ion-content .otp-input-div ion-input {\n      width: 44px;\n      height: 44px;\n      border-radius: 50%;\n      background: var(--ion-input-back);\n      margin-right: 24px;\n      text-align: center;\n      --padding-start: 0px;\n      font-size: 22px;\n      font-family: 'tofini_medium'; }\n  ion-content .otp-input-div ion-input:last-child {\n        margin-right: 0px; }\n  ion-content .otp-input-div .otp-fill {\n      background: var(--ion-color-orange);\n      color: var(--ion-color-white); }\n  ion-content .timer-text {\n    font-size: 13px;\n    font-family: 'tofini_regular';\n    color: var(--ion-color-lightDark);\n    margin-top: 20px; }\n  ion-content .social-link {\n    font-size: 14px;\n    font-family: 'tofini_regular';\n    color: var(--ion-color-lightGray);\n    margin-top: 61px;\n    margin-bottom: 0px; }\n  ion-content .btn-resend {\n    font-family: 'tofini_regular';\n    text-transform: inherit;\n    font-size: 14px;\n    --color: var(--ion-color-darkYellow);\n    --color-activated: var(--ion-color-darkYellow);\n    --ripple-color: var(--ion-color-white);\n    margin: 0px; }\n  ion-content .btn-continue {\n    --color: var(--ion-color-white);\n    height: 44px;\n    margin: 21px 8px 0px 8px;\n    font-size: 15px;\n    --box-shadow: none;\n    font-family: 'tofini_regular';\n    --background: var(--ion-color-gradiant);\n    text-transform: inherit; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvb3RwdmVyaWZpY2F0aW9uL0Q6XFxpb25pYyA0XFxCb29rIEEgUG9pbnQvc3JjXFxhcHBcXHBhZ2VzXFxvdHB2ZXJpZmljYXRpb25cXG90cHZlcmlmaWNhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxvQkFBZ0I7RUFDaEIsa0JBQWM7RUFDZCxzQ0FBZTtFQUNmLGlCQUFpQixFQUFBO0VBTHJCO0lBT00sY0FBYztJQUNkLFlBQVksRUFBQTtFQUlsQjtFQUNFLG1CQUFjO0VBQ2QscUJBQWdCLEVBQUE7RUFGbEI7SUFJSSwwQkFBMEI7SUFDMUIsZUFBZTtJQUNmLG1CQUFtQixFQUFBO0VBTnZCO0lBU0ksaUNBQWlDO0lBQ2pDLGVBQWU7SUFDZiw2QkFBNkI7SUFDN0Isa0JBQWtCO0lBQ2xCLGlCQUFpQixFQUFBO0VBYnJCO0lBZ0JJLG9CQUFvQjtJQUNwQiwyQkFBMkI7SUFDM0IsU0FBUztJQUNULGtCQUFrQjtJQUNsQixnQkFBZ0IsRUFBQTtFQXBCcEI7TUFzQk0sV0FBVztNQUNYLFlBQVk7TUFDWixrQkFBa0I7TUFDbEIsaUNBQWlDO01BQ2pDLGtCQUFrQjtNQUNsQixrQkFBa0I7TUFDbEIsb0JBQWdCO01BQ2hCLGVBQWU7TUFDZiw0QkFBNEIsRUFBQTtFQTlCbEM7UUFnQ1EsaUJBQWlCLEVBQUE7RUFoQ3pCO01Bb0NNLG1DQUFtQztNQUNuQyw2QkFBNkIsRUFBQTtFQXJDbkM7SUF5Q0ksZUFBZTtJQUNmLDZCQUE2QjtJQUM3QixpQ0FBaUM7SUFDakMsZ0JBQWdCLEVBQUE7RUE1Q3BCO0lBK0NJLGVBQWU7SUFDZiw2QkFBNkI7SUFDN0IsaUNBQWlDO0lBQ2pDLGdCQUFnQjtJQUNoQixrQkFBa0IsRUFBQTtFQW5EdEI7SUFzREksNkJBQTZCO0lBQzdCLHVCQUF1QjtJQUN2QixlQUFlO0lBQ2Ysb0NBQVE7SUFDUiw4Q0FBa0I7SUFDbEIsc0NBQWU7SUFDZixXQUFXLEVBQUE7RUE1RGY7SUErREksK0JBQVE7SUFDUixZQUFZO0lBQ1osd0JBQXdCO0lBQ3hCLGVBQWU7SUFDZixrQkFBYTtJQUNiLDZCQUE2QjtJQUM3Qix1Q0FBYTtJQUNiLHVCQUF1QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvb3RwdmVyaWZpY2F0aW9uL290cHZlcmlmaWNhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tYnV0dG9uIHtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDogMHB4O1xyXG4gICAgLS1yaXBwbGUtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgd2lkdGg6IDIzLjc0cHg7XHJcbiAgICAgIGhlaWdodDogMjBweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tcGFkZGluZy1lbmQ6IDI0cHg7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAyNHB4O1xyXG4gIC50aXRsZSB7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9ib2xkJztcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDIzcHg7XHJcbiAgfVxyXG4gIC5kZXNjcmlwdGlvbiB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0RGFyayk7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gIH1cclxuICAub3RwLWlucHV0LWRpdiB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIG1hcmdpbi10b3A6IDU2cHg7XHJcbiAgICBpb24taW5wdXQge1xyXG4gICAgICB3aWR0aDogNDRweDtcclxuICAgICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1pbnB1dC1iYWNrKTtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAyNHB4O1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICAgICY6bGFzdC1jaGlsZCB7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5vdHAtZmlsbCB7XHJcbiAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIH1cclxuICB9XHJcbiAgLnRpbWVyLXRleHQge1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0RGFyayk7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIH1cclxuICAuc29jaWFsLWxpbmsge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0R3JheSk7XHJcbiAgICBtYXJnaW4tdG9wOiA2MXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIH1cclxuICAuYnRuLXJlc2VuZCB7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIHRleHQtdHJhbnNmb3JtOiBpbmhlcml0O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmtZZWxsb3cpO1xyXG4gICAgLS1jb2xvci1hY3RpdmF0ZWQ6IHZhcigtLWlvbi1jb2xvci1kYXJrWWVsbG93KTtcclxuICAgIC0tcmlwcGxlLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgfVxyXG4gIC5idG4tY29udGludWUge1xyXG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIG1hcmdpbjogMjFweCA4cHggMHB4IDhweDtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX3JlZ3VsYXInO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZ3JhZGlhbnQpO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGluaGVyaXQ7XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/otpverification/otpverification.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/otpverification/otpverification.page.ts ***!
  \***************************************************************/
/*! exports provided: OTPVerificationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OTPVerificationPage", function() { return OTPVerificationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var OTPVerificationPage = /** @class */ (function () {
    function OTPVerificationPage(navCtrl) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.opt = {};
        setTimeout(function () {
            _this.a.setFocus();
        }, 200);
    }
    OTPVerificationPage.prototype.ngOnInit = function () { };
    OTPVerificationPage.prototype.backPage = function () {
        this.navCtrl.back();
    };
    OTPVerificationPage.prototype.moveFocus = function (event, nextElement, previousElement) {
        if (event.keyCode == 8 && previousElement) {
            previousElement.setFocus();
        }
        else if (event.keyCode >= 48 && event.keyCode <= 57) {
            if (nextElement) {
                nextElement.setFocus();
            }
        }
        else {
            event.path[0].value = "";
        }
    };
    OTPVerificationPage.prototype.resendCode = function () {
        this.navCtrl.back();
    };
    OTPVerificationPage.prototype.continue = function () {
        this.navCtrl.navigateRoot("/tabs");
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])("a"),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], OTPVerificationPage.prototype, "a", void 0);
    OTPVerificationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-otpverification",
            template: __webpack_require__(/*! ./otpverification.page.html */ "./src/app/pages/otpverification/otpverification.page.html"),
            styles: [__webpack_require__(/*! ./otpverification.page.scss */ "./src/app/pages/otpverification/otpverification.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], OTPVerificationPage);
    return OTPVerificationPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-otpverification-otpverification-module.js.map