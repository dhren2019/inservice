(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-starter-starter-module"],{

/***/ "./src/app/pages/starter/starter.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/starter/starter.module.ts ***!
  \*************************************************/
/*! exports provided: StarterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StarterPageModule", function() { return StarterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _starter_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./starter.page */ "./src/app/pages/starter/starter.page.ts");







var routes = [
    {
        path: '',
        component: _starter_page__WEBPACK_IMPORTED_MODULE_6__["StarterPage"]
    }
];
var StarterPageModule = /** @class */ (function () {
    function StarterPageModule() {
    }
    StarterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_starter_page__WEBPACK_IMPORTED_MODULE_6__["StarterPage"]]
        })
    ], StarterPageModule);
    return StarterPageModule;
}());



/***/ }),

/***/ "./src/app/pages/starter/starter.page.html":
/*!*************************************************!*\
  !*** ./src/app/pages/starter/starter.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div class=\"main-container\">\n    <div class=\"bottom-container\">\n      <div class=\"logo-section\">\n        <img src=\"../../../assets/images/starter/noun_barbershop_79139.svg\" alt=\"\">\n      </div>\n      <h2 class=\"title\">Book an Appointment for <br> Salon, Spa & Barber.</h2>\n\n      <ion-button class=\"btn-social-login google\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\">\n        <img src=\"../../../assets/images/starter/google-fill.svg\" alt=\"\">\n        Connect with&nbsp;<strong>Google</strong>\n      </ion-button>\n\n      <ion-button class=\"btn-social-login facebook\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\">\n        <img src=\"../../../assets/images/starter/facebook-fill.svg\" alt=\"\">\n        Connect with&nbsp;<strong>Facebook</strong>\n      </ion-button>\n      <p class=\"ion-text-center\">\n        Already have an account? <a class=\"btn-signIn\" (click)=\"signInPage()\">Sign in</a>\n      </p>\n    </div>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/starter/starter.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/starter/starter.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: url('Starter_back_img.png')\r\n    top/cover fixed; }\n  ion-content .main-container {\n    height: 100%;\n    width: 100%;\n    padding: 0px 32px 0px 31px;\n    background: linear-gradient(180deg, transparent 25%, #000000 130%); }\n  ion-content .main-container .bottom-container {\n      bottom: 0px;\n      position: absolute;\n      right: 32px;\n      left: 31px; }\n  ion-content .main-container .bottom-container .logo-section {\n        height: 73px;\n        width: 73px;\n        border-radius: 17px;\n        padding: 15px 20px;\n        background-image: linear-gradient(to right bottom, #fe457c, #ff4e72, #ff5868, #ff625f, #fd6c57); }\n  ion-content .main-container .bottom-container .logo-section img {\n          width: 31.65px;\n          height: 42.85px; }\n  ion-content .main-container .bottom-container .title {\n        margin-top: 20px;\n        margin-bottom: 0px;\n        font-family: 'tofini_bold';\n        height: 65px;\n        font-size: 23px;\n        color: var(--ion-color-white); }\n  ion-content .main-container .bottom-container .btn-social-login {\n        --color: var(--ion-color-white);\n        height: 44px;\n        margin: 0px;\n        font-size: 15px;\n        --box-shadow: none;\n        text-transform: inherit; }\n  ion-content .main-container .bottom-container .btn-social-login img {\n          position: absolute;\n          left: 26px; }\n  ion-content .main-container .bottom-container .google {\n        --background: var(--ion-color-gradiant);\n        margin-top: 40px; }\n  ion-content .main-container .bottom-container .facebook {\n        --background: var(--ion-colo-blue);\n        margin-top: 24px; }\n  ion-content .main-container .bottom-container .facebook img {\n          left: 29px; }\n  ion-content .main-container .bottom-container p {\n        font-size: 14px;\n        margin: 40px 0px 58px 0px;\n        color: var(--ion-color-white); }\n  ion-content .main-container .bottom-container p .btn-signIn {\n          color: var(--ion-color-orange);\n          font-family: 'tofini_medium'; }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc3RhcnRlci9EOlxcaW9uaWMgNFxcQm9vayBBIFBvaW50L3NyY1xcYXBwXFxwYWdlc1xcc3RhcnRlclxcc3RhcnRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRTttQkFBYSxFQUFBO0VBRGY7SUFLSSxZQUFZO0lBQ1osV0FBVztJQUNYLDBCQUEwQjtJQUMxQixrRUFBa0UsRUFBQTtFQVJ0RTtNQVVNLFdBQVc7TUFDWCxrQkFBa0I7TUFDbEIsV0FBVztNQUNYLFVBQVUsRUFBQTtFQWJoQjtRQWdCUSxZQUFZO1FBQ1osV0FBVztRQUNYLG1CQUFtQjtRQUNuQixrQkFBa0I7UUFDbEIsK0ZBT0MsRUFBQTtFQTNCVDtVQTZCVSxjQUFjO1VBQ2QsZUFBZSxFQUFBO0VBOUJ6QjtRQWtDUSxnQkFBZ0I7UUFDaEIsa0JBQWtCO1FBQ2xCLDBCQUEwQjtRQUMxQixZQUFZO1FBQ1osZUFBZTtRQUNmLDZCQUE2QixFQUFBO0VBdkNyQztRQTBDUSwrQkFBUTtRQUNSLFlBQVk7UUFDWixXQUFXO1FBQ1gsZUFBZTtRQUNmLGtCQUFhO1FBQ2IsdUJBQXVCLEVBQUE7RUEvQy9CO1VBaURVLGtCQUFrQjtVQUNsQixVQUFVLEVBQUE7RUFsRHBCO1FBc0RRLHVDQUFhO1FBQ2IsZ0JBQWdCLEVBQUE7RUF2RHhCO1FBMERRLGtDQUFhO1FBQ2IsZ0JBQWdCLEVBQUE7RUEzRHhCO1VBNkRVLFVBQVUsRUFBQTtFQTdEcEI7UUFpRVEsZUFBZTtRQUNmLHlCQUF5QjtRQUN6Qiw2QkFBNkIsRUFBQTtFQW5FckM7VUFxRVUsOEJBQThCO1VBQzlCLDRCQUE0QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc3RhcnRlci9zdGFydGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IHVybCgnLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9zdGFydGVyL1N0YXJ0ZXJfYmFja19pbWcucG5nJylcclxuICAgIHRvcC9jb3ZlciBmaXhlZDtcclxuXHJcbiAgLm1haW4tY29udGFpbmVyIHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMHB4IDMycHggMHB4IDMxcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCB0cmFuc3BhcmVudCAyNSUsICMwMDAwMDAgMTMwJSk7XHJcbiAgICAuYm90dG9tLWNvbnRhaW5lciB7XHJcbiAgICAgIGJvdHRvbTogMHB4O1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIHJpZ2h0OiAzMnB4O1xyXG4gICAgICBsZWZ0OiAzMXB4O1xyXG5cclxuICAgICAgLmxvZ28tc2VjdGlvbiB7XHJcbiAgICAgICAgaGVpZ2h0OiA3M3B4O1xyXG4gICAgICAgIHdpZHRoOiA3M3B4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDE3cHg7XHJcbiAgICAgICAgcGFkZGluZzogMTVweCAyMHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudChcclxuICAgICAgICAgIHRvIHJpZ2h0IGJvdHRvbSxcclxuICAgICAgICAgICNmZTQ1N2MsXHJcbiAgICAgICAgICAjZmY0ZTcyLFxyXG4gICAgICAgICAgI2ZmNTg2OCxcclxuICAgICAgICAgICNmZjYyNWYsXHJcbiAgICAgICAgICAjZmQ2YzU3XHJcbiAgICAgICAgKTtcclxuICAgICAgICBpbWcge1xyXG4gICAgICAgICAgd2lkdGg6IDMxLjY1cHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDQyLjg1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC50aXRsZSB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfYm9sZCc7XHJcbiAgICAgICAgaGVpZ2h0OiA2NXB4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjNweDtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgfVxyXG4gICAgICAuYnRuLXNvY2lhbC1sb2dpbiB7XHJcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogaW5oZXJpdDtcclxuICAgICAgICBpbWcge1xyXG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgbGVmdDogMjZweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgLmdvb2dsZSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZ3JhZGlhbnQpO1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDQwcHg7XHJcbiAgICAgIH1cclxuICAgICAgLmZhY2Vib29rIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvLWJsdWUpO1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDI0cHg7XHJcbiAgICAgICAgaW1nIHtcclxuICAgICAgICAgIGxlZnQ6IDI5cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBtYXJnaW46IDQwcHggMHB4IDU4cHggMHB4O1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICAgIC5idG4tc2lnbkluIHtcclxuICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiAndG9maW5pX21lZGl1bSc7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/starter/starter.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/starter/starter.page.ts ***!
  \***********************************************/
/*! exports provided: StarterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StarterPage", function() { return StarterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var StarterPage = /** @class */ (function () {
    function StarterPage(navController) {
        this.navController = navController;
    }
    StarterPage.prototype.ngOnInit = function () { };
    StarterPage.prototype.signInPage = function () {
        this.navController.navigateForward('sign-in');
    };
    StarterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-starter',
            template: __webpack_require__(/*! ./starter.page.html */ "./src/app/pages/starter/starter.page.html"),
            styles: [__webpack_require__(/*! ./starter.page.scss */ "./src/app/pages/starter/starter.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], StarterPage);
    return StarterPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-starter-starter-module.js.map