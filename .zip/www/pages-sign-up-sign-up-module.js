(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-sign-up-sign-up-module"],{

/***/ "./src/app/pages/sign-up/sign-up.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/sign-up/sign-up.module.ts ***!
  \*************************************************/
/*! exports provided: SignUpPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignUpPageModule", function() { return SignUpPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _sign_up_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sign-up.page */ "./src/app/pages/sign-up/sign-up.page.ts");







var routes = [
    {
        path: '',
        component: _sign_up_page__WEBPACK_IMPORTED_MODULE_6__["SignUpPage"]
    }
];
var SignUpPageModule = /** @class */ (function () {
    function SignUpPageModule() {
    }
    SignUpPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_sign_up_page__WEBPACK_IMPORTED_MODULE_6__["SignUpPage"]]
        })
    ], SignUpPageModule);
    return SignUpPageModule;
}());



/***/ }),

/***/ "./src/app/pages/sign-up/sign-up.page.html":
/*!*************************************************!*\
  !*** ./src/app/pages/sign-up/sign-up.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons>\n      <ion-button fill=\"clear\" mode=\"md\" (click)=\"backPage()\">\n        <ion-icon src=\"../../../assets/images/General/noun_Arrow_1256499.svg\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <h1 class=\"title ion-text-center\">Create an Account</h1>\n  <form>\n    <ion-input name=\"userName\" [(ngModel)]=\"user.username\" placeholder=\"User name\" type=\"text\">\n    </ion-input>\n\n    <ion-input placeholder=\"Email address\" name=\"email\" [(ngModel)]=\"user.email\" type=\"text\"></ion-input>\n\n    <ion-input placeholder=\"Phone number\" name=\"phone\" [(ngModel)]=\"user.phone_no\" type=\"text\"></ion-input>\n\n    <ion-datetime class=\"date_picker\" placeholder=\"Date of Birth\" displayFormat=\"DD-MM-YYYY\"></ion-datetime>\n\n    <ion-input placeholder=\"Password\" name=\"password\" [(ngModel)]=\"user.password\" type=\"password\"></ion-input>\n\n    <ion-input placeholder=\"Confirm password\" name=\"confirm_password\" [(ngModel)]=\"user.confirm_password\"\n      type=\"password\"></ion-input>\n\n    <ion-button class=\"btn-SignUp\" mode=\"md\" expand=\"full\" shape=\"round\" fill=\"solid\" (click)=\"register()\">\n      Sign up\n    </ion-button>\n  </form>\n  <p class=\"terms-text ion-text-center\">By continuing <span class=\"light-text\">Sign up</span> you agree to the following\n    <br> <span class=\"light-text\">Terms &\n      Conditions</span>\n    without\n    reservation.\n  </p>\n  <p class=\"ion-text-center account-text\">Already have an account? <a (click)=\"signIn()\"> Sign in</a></p>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/sign-up/sign-up.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/sign-up/sign-up.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-button {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --ripple-color: var(--ion-color-white);\n  margin-left: 15px; }\n  ion-header ion-button ion-icon {\n    width: 23.74px;\n    height: 20px; }\n  ion-content {\n  --padding-end: 24px;\n  --padding-start: 24px; }\n  ion-content .title {\n    font-family: 'tofini_bold';\n    font-size: 30px;\n    margin-bottom: 20px; }\n  ion-content ion-input,\n  ion-content .date_picker {\n    --background: var(--ion-input-back);\n    height: 44px;\n    border-radius: 22px;\n    --padding-start: 24px;\n    --padding-top: 16px;\n    --padding-bottom: 13px;\n    font-family: 'tofini_regular';\n    font-size: 15px;\n    margin-bottom: 20px;\n    --placeholder-color: var(--ion-placeholder-color); }\n  ion-content ion-datetime {\n    background: var(--ion-input-back);\n    font-size: 15px;\n    --padding-top: 13px;\n    font-family: 'tofini_regular';\n    --placeholder-color: var(--ion-placeholder-color); }\n  ion-content .btn-SignUp {\n    --color: var(--ion-color-white);\n    height: 44px;\n    margin: 42px 8px 0px 8px;\n    font-size: 15px;\n    --box-shadow: none;\n    font-family: 'tofini_regular';\n    --background: var(--ion-color-gradiant);\n    margin-top: 40px;\n    text-transform: inherit; }\n  ion-content .terms-text {\n    font-size: 11px;\n    color: var(--ion-color-lightGray);\n    font-family: 'tofini_regular';\n    margin: 16px 0px 0px 0px; }\n  ion-content .terms-text .light-text {\n      color: var(--ion-color-black);\n      font-family: 'tofini_medium'; }\n  ion-content .account-text {\n    margin-top: 42px;\n    font-family: 'tofini_regular';\n    color: var(--ion-color-gray);\n    font-size: 14px; }\n  ion-content .account-text a {\n      color: var(--ion-color-darkYellow); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2lnbi11cC9EOlxcaW9uaWMgNFxcQm9vayBBIFBvaW50L3NyY1xcYXBwXFxwYWdlc1xcc2lnbi11cFxcc2lnbi11cC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxvQkFBZ0I7RUFDaEIsa0JBQWM7RUFDZCxzQ0FBZTtFQUNmLGlCQUFpQixFQUFBO0VBTHJCO0lBT00sY0FBYztJQUNkLFlBQVksRUFBQTtFQUlsQjtFQUNFLG1CQUFjO0VBQ2QscUJBQWdCLEVBQUE7RUFGbEI7SUFJSSwwQkFBMEI7SUFDMUIsZUFBZTtJQUNmLG1CQUFtQixFQUFBO0VBTnZCOztJQVVJLG1DQUFhO0lBQ2IsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixxQkFBZ0I7SUFDaEIsbUJBQWM7SUFDZCxzQkFBaUI7SUFDakIsNkJBQTZCO0lBQzdCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsaURBQW9CLEVBQUE7RUFuQnhCO0lBc0JJLGlDQUFpQztJQUNqQyxlQUFlO0lBQ2YsbUJBQWM7SUFDZCw2QkFBNkI7SUFDN0IsaURBQW9CLEVBQUE7RUExQnhCO0lBNkJJLCtCQUFRO0lBQ1IsWUFBWTtJQUNaLHdCQUF3QjtJQUN4QixlQUFlO0lBQ2Ysa0JBQWE7SUFDYiw2QkFBNkI7SUFDN0IsdUNBQWE7SUFDYixnQkFBZ0I7SUFDaEIsdUJBQXVCLEVBQUE7RUFyQzNCO0lBd0NJLGVBQWU7SUFDZixpQ0FBaUM7SUFDakMsNkJBQTZCO0lBQzdCLHdCQUF3QixFQUFBO0VBM0M1QjtNQTZDTSw2QkFBNkI7TUFDN0IsNEJBQTRCLEVBQUE7RUE5Q2xDO0lBa0RJLGdCQUFnQjtJQUNoQiw2QkFBNkI7SUFDN0IsNEJBQTRCO0lBQzVCLGVBQWUsRUFBQTtFQXJEbkI7TUF1RE0sa0NBQWtDLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zaWduLXVwL3NpZ24tdXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgaW9uLWJ1dHRvbiB7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAgIC0tcGFkZGluZy1lbmQ6IDBweDtcclxuICAgIC0tcmlwcGxlLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIHdpZHRoOiAyMy43NHB4O1xyXG4gICAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbmlvbi1jb250ZW50IHtcclxuICAtLXBhZGRpbmctZW5kOiAyNHB4O1xyXG4gIC0tcGFkZGluZy1zdGFydDogMjRweDtcclxuICAudGl0bGUge1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfYm9sZCc7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIH1cclxuICBpb24taW5wdXQsXHJcbiAgLmRhdGVfcGlja2VyIHtcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWlucHV0LWJhY2spO1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjJweDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMjRweDtcclxuICAgIC0tcGFkZGluZy10b3A6IDE2cHg7XHJcbiAgICAtLXBhZGRpbmctYm90dG9tOiAxM3B4O1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLXBsYWNlaG9sZGVyLWNvbG9yKTtcclxuICB9XHJcbiAgaW9uLWRhdGV0aW1lIHtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1pbnB1dC1iYWNrKTtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIC0tcGFkZGluZy10b3A6IDEzcHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIC0tcGxhY2Vob2xkZXItY29sb3I6IHZhcigtLWlvbi1wbGFjZWhvbGRlci1jb2xvcik7XHJcbiAgfVxyXG4gIC5idG4tU2lnblVwIHtcclxuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICBtYXJnaW46IDQycHggOHB4IDBweCA4cHg7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWdyYWRpYW50KTtcclxuICAgIG1hcmdpbi10b3A6IDQwcHg7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5oZXJpdDtcclxuICB9XHJcbiAgLnRlcm1zLXRleHQge1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodEdyYXkpO1xyXG4gICAgZm9udC1mYW1pbHk6ICd0b2ZpbmlfcmVndWxhcic7XHJcbiAgICBtYXJnaW46IDE2cHggMHB4IDBweCAwcHg7XHJcbiAgICAubGlnaHQtdGV4dCB7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgICBmb250LWZhbWlseTogJ3RvZmluaV9tZWRpdW0nO1xyXG4gICAgfVxyXG4gIH1cclxuICAuYWNjb3VudC10ZXh0IHtcclxuICAgIG1hcmdpbi10b3A6IDQycHg7XHJcbiAgICBmb250LWZhbWlseTogJ3RvZmluaV9yZWd1bGFyJztcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZ3JheSk7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBhIHtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrWWVsbG93KTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/sign-up/sign-up.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/sign-up/sign-up.page.ts ***!
  \***********************************************/
/*! exports provided: SignUpPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignUpPage", function() { return SignUpPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var SignUpPage = /** @class */ (function () {
    function SignUpPage(navCtrl) {
        this.navCtrl = navCtrl;
        this.user = {};
    }
    SignUpPage.prototype.ngOnInit = function () { };
    SignUpPage.prototype.backPage = function () {
        this.navCtrl.back();
    };
    SignUpPage.prototype.register = function () {
        this.navCtrl.navigateBack("/phone-verification");
    };
    SignUpPage.prototype.signIn = function () {
        this.navCtrl.navigateBack("/sign-in");
    };
    SignUpPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-sign-up",
            template: __webpack_require__(/*! ./sign-up.page.html */ "./src/app/pages/sign-up/sign-up.page.html"),
            styles: [__webpack_require__(/*! ./sign-up.page.scss */ "./src/app/pages/sign-up/sign-up.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], SignUpPage);
    return SignUpPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-sign-up-sign-up-module.js.map