(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-book-appointment-book-appointment-module"],{

/***/ "./src/app/pages/book-appointment/book-appointment.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/book-appointment/book-appointment.module.ts ***!
  \*******************************************************************/
/*! exports provided: BookAppointmentPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookAppointmentPageModule", function() { return BookAppointmentPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _book_appointment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./book-appointment.page */ "./src/app/pages/book-appointment/book-appointment.page.ts");







var routes = [
    {
        path: '',
        component: _book_appointment_page__WEBPACK_IMPORTED_MODULE_6__["BookAppointmentPage"]
    }
];
var BookAppointmentPageModule = /** @class */ (function () {
    function BookAppointmentPageModule() {
    }
    BookAppointmentPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_book_appointment_page__WEBPACK_IMPORTED_MODULE_6__["BookAppointmentPage"]]
        })
    ], BookAppointmentPageModule);
    return BookAppointmentPageModule;
}());



/***/ }),

/***/ "./src/app/pages/book-appointment/book-appointment.page.html":
/*!*******************************************************************!*\
  !*** ./src/app/pages/book-appointment/book-appointment.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" mode=\"md\" (click)=\"backPage()\">\n        <ion-icon\n          src=\"../../../assets/images/General/noun_Arrow_white_1256499.svg\"\n        ></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Book Appointment</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n  <div class=\"main-containt\">\n    <div class=\"scroll-div\">\n      <h4 class=\"title\">Select your date</h4>\n      <div class=\"select-date\">\n        <ion-datetime\n          #picker\n          displayFormat=\"DD MMMM, YYYY\"\n          [(ngModel)]=\"bookDate\"\n          min=\"{{ minYear }}\"\n          max=\"{{ maxYear }}\"\n        ></ion-datetime>\n        <ion-icon\n          (click)=\"picker.open()\"\n          class=\"calendar-icon\"\n          src=\"../../../assets/images/General/noun_Calendar_2577480.svg\"\n        ></ion-icon>\n      </div>\n      <h4 class=\"title\">Select specialist</h4>\n      <ion-row nowrap class=\"ion-no-padding employee-row\">\n        <ion-col\n          size=\"3\"\n          size-md=\"1.5\"\n          size-xl=\"1\"\n          *ngFor=\"let emp of employeeList\"\n          (click)=\"setEmployee(emp)\"\n        >\n          <div\n            class=\"image-div\"\n            [ngClass]=\"{ active: emp.index == selectedEmployee }\"\n          >\n            <img [src]=\"emp.image\" alt=\"\" />\n          </div>\n          <p class=\"emp-name ion-text-center\">{{ emp.name }}</p>\n        </ion-col>\n      </ion-row>\n      <h4 class=\"title\">Available slot</h4>\n      <div class=\"booking-slot-div\">\n        <ion-row>\n          <ion-col\n            [ngClass]=\"{\n              'no-right-padding': (i + 1) % 4 == 0,\n              'no-left-padding': i == 0 || i % 4 == 0\n            }\"\n            size=\"3\"\n            *ngFor=\"let time of timeSlot; let i = index\"\n            (click)=\"setTimeSlot(time)\"\n          >\n            <div class=\"slot\" [ngClass]=\"{ active: activeTimeSlot == time }\">\n              {{ time }}\n            </div>\n          </ion-col>\n        </ion-row>\n      </div>\n      <ion-button\n        class=\"btn-continue\"\n        mode=\"md\"\n        expand=\"full\"\n        shape=\"round\"\n        fill=\"solid\"\n        (click)=\"continue()\"\n      >\n        Continue\n      </ion-button>\n    </div>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/book-appointment/book-appointment.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/pages/book-appointment/book-appointment.page.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: transparent;\n  --ion-color-base: transparent !important; }\n\nion-header ion-title {\n  font-size: 19px;\n  color: var(--ion-color-white);\n  font-family: \"tofini_bold\"; }\n\nion-header ion-button {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --ripple-color: var(--ion-color-white);\n  margin-left: 15px; }\n\nion-header ion-button ion-icon {\n    width: 23.74px;\n    height: 20px; }\n\nion-content {\n  --background: url('Rectangle.png') no-repeat\r\n    0px 0px / 100%; }\n\nion-content .main-containt {\n    padding: 3vh 24px 0px 24px;\n    background-color: var(--ion-color-white);\n    height: 100%;\n    border-radius: 17px 17px 0px 0px;\n    position: fixed;\n    left: 0px;\n    right: 0px;\n    top: 28vh;\n    border-radius: 17px 17px 0px 0px; }\n\nion-content .main-containt .scroll-div {\n      height: 70vh;\n      overflow-y: scroll; }\n\nion-content .main-containt .scroll-div::-webkit-scrollbar {\n        display: none; }\n\nion-content .main-containt .title {\n      font-size: 16px;\n      font-family: \"tofini_bold\";\n      margin-top: 0px; }\n\nion-content .main-containt .select-date {\n      position: relative; }\n\nion-content .main-containt .select-date ion-datetime {\n        height: 44px;\n        border-radius: 22px;\n        --padding-start: 24px;\n        --padding-top: 16px;\n        --padding-bottom: 13px;\n        font-family: \"tofini_regular\";\n        font-size: 15px;\n        margin-bottom: 35px;\n        --placeholder-color: var(--ion-placeholder-color);\n        background: var(--ion-input-back);\n        font-size: 15px; }\n\nion-content .main-containt .select-date .calendar-icon {\n        position: absolute;\n        top: 10px;\n        right: 24px;\n        z-index: 100;\n        height: 24px;\n        width: 24px; }\n\nion-content .main-containt .employee-row {\n      padding-bottom: 20px;\n      overflow-x: scroll; }\n\nion-content .main-containt .employee-row::-webkit-scrollbar {\n        display: none; }\n\nion-content .main-containt .employee-row .image-div {\n        height: 56px;\n        width: 56px;\n        margin: 0px auto;\n        border-radius: 50%;\n        border: 2px solid transparent; }\n\nion-content .main-containt .employee-row .image-div img {\n          height: 100%;\n          width: 100%;\n          border-radius: 50%; }\n\nion-content .main-containt .employee-row .active {\n        border-color: var(--ion-color-orange); }\n\nion-content .main-containt .emp-name {\n      font-size: 12px;\n      font-family: \"tofini_regular\";\n      color: var(--ion-color-lightDark); }\n\nion-content .main-containt .booking-slot-div .slot {\n      padding: 6px 0px 4px;\n      width: 100%;\n      text-align: center;\n      border: 1px solid var(--ion-border-color);\n      font-size: 13px;\n      padding: 9px 0px 7px;\n      font-family: \"tofini_regular\";\n      border-radius: 2px; }\n\nion-content .main-containt .booking-slot-div .active {\n      color: var(--ion-color-white);\n      background: var(--ion-color-orange);\n      border-color: var(--ion-color-orange); }\n\nion-content .main-containt .no-left-padding {\n      padding-left: 0px; }\n\nion-content .main-containt .no-right-padding {\n      padding-right: 0px; }\n\nion-content .main-containt .btn-continue {\n      --color: var(--ion-color-white);\n      height: 44px;\n      margin: 35px 8px 20px 8px;\n      font-size: 15px;\n      --box-shadow: none;\n      font-family: \"tofini_regular\";\n      --background: var(--ion-color-gradiant);\n      text-transform: inherit; }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYm9vay1hcHBvaW50bWVudC9EOlxcaW9uaWMgNFxcQm9vayBBIFBvaW50L3NyY1xcYXBwXFxwYWdlc1xcYm9vay1hcHBvaW50bWVudFxcYm9vay1hcHBvaW50bWVudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSx5QkFBYTtFQUNiLHdDQUFpQixFQUFBOztBQUhyQjtFQU1JLGVBQWU7RUFDZiw2QkFBNkI7RUFDN0IsMEJBQTBCLEVBQUE7O0FBUjlCO0VBV0ksb0JBQWdCO0VBQ2hCLGtCQUFjO0VBQ2Qsc0NBQWU7RUFDZixpQkFBaUIsRUFBQTs7QUFkckI7SUFnQk0sY0FBYztJQUNkLFlBQVksRUFBQTs7QUFJbEI7RUFDRTtrQkFBYSxFQUFBOztBQURmO0lBSUksMEJBQTBCO0lBQzFCLHdDQUF3QztJQUN4QyxZQUFZO0lBQ1osZ0NBQWdDO0lBQ2hDLGVBQWU7SUFDZixTQUFTO0lBQ1QsVUFBVTtJQUNWLFNBQVM7SUFDVCxnQ0FBZ0MsRUFBQTs7QUFacEM7TUFjTSxZQUFZO01BQ1osa0JBQWtCLEVBQUE7O0FBZnhCO1FBaUJRLGFBQWEsRUFBQTs7QUFqQnJCO01BcUJNLGVBQWU7TUFDZiwwQkFBMEI7TUFDMUIsZUFBZSxFQUFBOztBQXZCckI7TUEwQk0sa0JBQWtCLEVBQUE7O0FBMUJ4QjtRQTRCUSxZQUFZO1FBQ1osbUJBQW1CO1FBQ25CLHFCQUFnQjtRQUNoQixtQkFBYztRQUNkLHNCQUFpQjtRQUNqQiw2QkFBNkI7UUFDN0IsZUFBZTtRQUNmLG1CQUFtQjtRQUNuQixpREFBb0I7UUFDcEIsaUNBQWlDO1FBQ2pDLGVBQWUsRUFBQTs7QUF0Q3ZCO1FBeUNRLGtCQUFrQjtRQUNsQixTQUFTO1FBQ1QsV0FBVztRQUNYLFlBQVk7UUFDWixZQUFZO1FBQ1osV0FBVyxFQUFBOztBQTlDbkI7TUFtRE0sb0JBQW9CO01BQ3BCLGtCQUFrQixFQUFBOztBQXBEeEI7UUFzRFEsYUFBYSxFQUFBOztBQXREckI7UUF5RFEsWUFBWTtRQUNaLFdBQVc7UUFDWCxnQkFBZ0I7UUFDaEIsa0JBQWtCO1FBQ2xCLDZCQUE2QixFQUFBOztBQTdEckM7VUErRFUsWUFBWTtVQUNaLFdBQVc7VUFDWCxrQkFBa0IsRUFBQTs7QUFqRTVCO1FBcUVRLHFDQUFxQyxFQUFBOztBQXJFN0M7TUF5RU0sZUFBZTtNQUNmLDZCQUE2QjtNQUM3QixpQ0FBaUMsRUFBQTs7QUEzRXZDO01BK0VRLG9CQUFvQjtNQUNwQixXQUFXO01BQ1gsa0JBQWtCO01BQ2xCLHlDQUF5QztNQUN6QyxlQUFlO01BQ2Ysb0JBQW9CO01BQ3BCLDZCQUE2QjtNQUM3QixrQkFBa0IsRUFBQTs7QUF0RjFCO01BeUZRLDZCQUE2QjtNQUM3QixtQ0FBbUM7TUFDbkMscUNBQXFDLEVBQUE7O0FBM0Y3QztNQStGTSxpQkFBaUIsRUFBQTs7QUEvRnZCO01Ba0dNLGtCQUFrQixFQUFBOztBQWxHeEI7TUFxR00sK0JBQVE7TUFDUixZQUFZO01BQ1oseUJBQXlCO01BQ3pCLGVBQWU7TUFDZixrQkFBYTtNQUNiLDZCQUE2QjtNQUM3Qix1Q0FBYTtNQUNiLHVCQUF1QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYm9vay1hcHBvaW50bWVudC9ib29rLWFwcG9pbnRtZW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAtLWlvbi1jb2xvci1iYXNlOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAxOXB4O1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfYm9sZFwiO1xyXG4gIH1cclxuICBpb24tYnV0dG9uIHtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDogMHB4O1xyXG4gICAgLS1yaXBwbGUtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgd2lkdGg6IDIzLjc0cHg7XHJcbiAgICAgIGhlaWdodDogMjBweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9HZW5lcmFsL1JlY3RhbmdsZS5wbmdcIikgbm8tcmVwZWF0XHJcbiAgICAwcHggMHB4IC8gMTAwJTtcclxuICAubWFpbi1jb250YWludCB7XHJcbiAgICBwYWRkaW5nOiAzdmggMjRweCAwcHggMjRweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxN3B4IDE3cHggMHB4IDBweDtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGxlZnQ6IDBweDtcclxuICAgIHJpZ2h0OiAwcHg7XHJcbiAgICB0b3A6IDI4dmg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxN3B4IDE3cHggMHB4IDBweDtcclxuICAgIC5zY3JvbGwtZGl2IHtcclxuICAgICAgaGVpZ2h0OiA3MHZoO1xyXG4gICAgICBvdmVyZmxvdy15OiBzY3JvbGw7XHJcbiAgICAgICY6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAudGl0bGUge1xyXG4gICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9ib2xkXCI7XHJcbiAgICAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgIH1cclxuICAgIC5zZWxlY3QtZGF0ZSB7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgaW9uLWRhdGV0aW1lIHtcclxuICAgICAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMjJweDtcclxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDI0cHg7XHJcbiAgICAgICAgLS1wYWRkaW5nLXRvcDogMTZweDtcclxuICAgICAgICAtLXBhZGRpbmctYm90dG9tOiAxM3B4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9yZWd1bGFyXCI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDM1cHg7XHJcbiAgICAgICAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLXBsYWNlaG9sZGVyLWNvbG9yKTtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24taW5wdXQtYmFjayk7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5jYWxlbmRhci1pY29uIHtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgdG9wOiAxMHB4O1xyXG4gICAgICAgIHJpZ2h0OiAyNHB4O1xyXG4gICAgICAgIHotaW5kZXg6IDEwMDtcclxuICAgICAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgICAgICAgd2lkdGg6IDI0cHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuZW1wbG95ZWUtcm93IHtcclxuICAgICAgcGFkZGluZy1ib3R0b206IDIwcHg7XHJcbiAgICAgIG92ZXJmbG93LXg6IHNjcm9sbDtcclxuICAgICAgJjo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgIH1cclxuICAgICAgLmltYWdlLWRpdiB7XHJcbiAgICAgICAgaGVpZ2h0OiA1NnB4O1xyXG4gICAgICAgIHdpZHRoOiA1NnB4O1xyXG4gICAgICAgIG1hcmdpbjogMHB4IGF1dG87XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIGJvcmRlcjogMnB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgLmFjdGl2ZSB7XHJcbiAgICAgICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmVtcC1uYW1lIHtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfcmVndWxhclwiO1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0RGFyayk7XHJcbiAgICB9XHJcbiAgICAuYm9va2luZy1zbG90LWRpdiB7XHJcbiAgICAgIC5zbG90IHtcclxuICAgICAgICBwYWRkaW5nOiA2cHggMHB4IDRweDtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWJvcmRlci1jb2xvcik7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIHBhZGRpbmc6IDlweCAwcHggN3B4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9yZWd1bGFyXCI7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMnB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5hY3RpdmUge1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW9yYW5nZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5uby1sZWZ0LXBhZGRpbmcge1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDBweDtcclxuICAgIH1cclxuICAgIC5uby1yaWdodC1wYWRkaW5nIHtcclxuICAgICAgcGFkZGluZy1yaWdodDogMHB4O1xyXG4gICAgfVxyXG4gICAgLmJ0bi1jb250aW51ZSB7XHJcbiAgICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgIGhlaWdodDogNDRweDtcclxuICAgICAgbWFyZ2luOiAzNXB4IDhweCAyMHB4IDhweDtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9yZWd1bGFyXCI7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWdyYWRpYW50KTtcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IGluaGVyaXQ7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/book-appointment/book-appointment.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/book-appointment/book-appointment.page.ts ***!
  \*****************************************************************/
/*! exports provided: BookAppointmentPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookAppointmentPage", function() { return BookAppointmentPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var BookAppointmentPage = /** @class */ (function () {
    function BookAppointmentPage(navCtrl) {
        this.navCtrl = navCtrl;
        this.employeeList = [
            {
                index: 1,
                image: "../../../assets/images/General/Bitmap.png",
                name: "Ben Jhonson"
            },
            {
                index: 2,
                image: "../../../assets/images/General/Bitmap1.png",
                name: "Kieran Dely"
            },
            {
                index: 3,
                image: "../../../assets/images/General/Bitmap2.png",
                name: "Helen White"
            },
            {
                index: 4,
                image: "../../../assets/images/General/Bitmap3.png",
                name: "Daniel William"
            }
        ];
        this.timeSlot = [
            "9:30 AM",
            "10:00 AM",
            "10:30 AM",
            "11:00 AM",
            "11:30 AM",
            "12:00 PM",
            "1:30 PM",
            "2:00 PM",
            "2:30 PM",
            "3:00 PM",
            "3:30 PM",
            "4:00 PM",
            "4:30 PM",
            "5:00 PM",
            "5:30 PM",
            "6:00 PM"
        ];
        this.selectedEmployee = 2;
        this.activeTimeSlot = "12:00 PM";
        this.minYear = new Date().getFullYear();
        this.maxYear = new Date().getFullYear() + 5;
        this.bookDate = new Date();
    }
    BookAppointmentPage.prototype.ngOnInit = function () { };
    BookAppointmentPage.prototype.backPage = function () {
        this.navCtrl.back();
    };
    BookAppointmentPage.prototype.setEmployee = function (emp) {
        this.selectedEmployee = emp.index;
    };
    BookAppointmentPage.prototype.setTimeSlot = function (time) {
        this.activeTimeSlot = time;
    };
    BookAppointmentPage.prototype.continue = function () {
        this.navCtrl.navigateForward("/booking-detail");
    };
    BookAppointmentPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: "app-book-appointment",
            template: __webpack_require__(/*! ./book-appointment.page.html */ "./src/app/pages/book-appointment/book-appointment.page.html"),
            styles: [__webpack_require__(/*! ./book-appointment.page.scss */ "./src/app/pages/book-appointment/book-appointment.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], BookAppointmentPage);
    return BookAppointmentPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-book-appointment-book-appointment-module.js.map