(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"],{

/***/ "./src/app/pages/home/home.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");







var routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
    }
];
var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/pages/home/home.page.html":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <p class=\"location-label\">Your location</p>\n    <p class=\"select-location ion-no-margin\">\n      <ion-icon class=\"pin\" src=\"../../../assets/images/General/ic_location_color.svg\"></ion-icon>\n      San Francisco City\n      <ion-icon class=\"direction\" src=\"../../../assets/images/General/ic_direction.svg\"></ion-icon>\n    </p>\n    <ion-buttons slot=\"end\">\n      <ion-button class=\"btn-filter\" fill=\"clear\" (click)=\"openFilter()\">\n        <ion-icon src=\"../../../assets/images/General/_ionicons_svg_ios-funnel.svg\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-toolbar>\n    <ion-searchbar mode=\"ios\" [(ngModel)]=\"searchText\"></ion-searchbar>\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" class=\"btn-cancel\" (click)=\"searchCancel()\">\n        Cancel\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div #map id=\"map\" style=\"height: 100%;width: 100%\"></div>\n  <div class=\"map-button\">\n    <div class=\"info-icon\">\n      <ion-icon src=\"../../../assets/images/near-by/ic_info.svg\"></ion-icon>\n    </div>\n    <ion-icon class=\"location\" src=\"../../../assets/images/near-by/ic_location_clear.svg\"></ion-icon>\n  </div>\n  <ion-row class=\"salonList-row\" nowrap>\n    <ion-col size=\"8\" size-md=\"5\" size-xl=\"4\" *ngFor=\"let salon of salonList\" (click)=\"salonDetail($event)\">\n      <div class=\"salon-section\">\n        <div class=\"salon-image\">\n          <img class=\"salon-img\" [src]=\"salon.image\" alt=\"\" />\n        </div>\n        <div class=\"salon-detail\">\n          <h5 class=\"salon-name\">\n            {{ salon.name }}\n            <span class=\"start-span ion-float-right\"><img src=\"../../../assets/images/General/ic_star.svg\" alt=\"\" />{{\n                salon.star\n              }}</span>\n          </h5>\n          <p class=\"salon-address\">{{ salon.address }}</p>\n          <ion-button class=\"btn-book ion-float-right\" mode=\"md\" size=\"small\" (click)=\"bookSalon($event)\">\n            Book\n          </ion-button>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/home/home.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header {\n  border-bottom: 0.5px solid var(--ion-border-color); }\n  ion-header ion-toolbar {\n    padding-left: 16px;\n    --background: var(--ion-color-white-light); }\n  ion-header .location-label {\n    font-size: 12px;\n    font-family: \"tofini_medium\";\n    color: var(--ion-color-simpleDark);\n    margin-bottom: 3px;\n    margin-top: 12px; }\n  ion-header .select-location {\n    font-size: 15px;\n    font-family: \"tofini_medium\";\n    color: var(--ion-color-black); }\n  ion-header .select-location .pin {\n      height: 17.7px;\n      width: 12.42px;\n      margin-bottom: -3px;\n      margin-right: 5px; }\n  ion-header .select-location .direction {\n      height: 14px;\n      width: 14px;\n      margin-bottom: -3px;\n      margin-left: 7px; }\n  ion-header .btn-filter {\n    font-size: 18px;\n    color: var(--ion-color-black);\n    --ripple-color: var(--ion-color-white); }\n  ion-header ion-searchbar {\n    padding: 0px;\n    --background: var(--ion-searchBack-color);\n    font-size: 15px;\n    font-family: \"tofini_regular\"; }\n  ion-header ion-searchbar .searchbar-clear-icon {\n      display: none !important; }\n  ion-header .btn-cancel {\n    --color: var(--ion-color-orange);\n    font-size: 15px;\n    font-family: \"tofini_bold\";\n    text-transform: initial;\n    --ripple-color: var(--ion-color-white); }\n  ion-content .map-button {\n  position: absolute;\n  top: 18px;\n  right: 8px;\n  background: rgba(255, 255, 255, 0.8);\n  border-radius: 10px;\n  border: 1px solid;\n  border-color: rgba(151, 151, 151, 0.2); }\n  ion-content .map-button ion-icon {\n    font-size: 24px; }\n  ion-content .map-button .info-icon {\n    padding: 10px;\n    border-bottom: 1px solid;\n    border-color: rgba(151, 151, 151, 0.2); }\n  ion-content .map-button .location {\n    padding: 10px; }\n  ion-content .salonList-row {\n  position: absolute;\n  bottom: 8px;\n  left: 5px;\n  overflow-x: scroll; }\n  ion-content .salonList-row::-webkit-scrollbar {\n    display: none; }\n  ion-content .salonList-row .salon-section {\n    background: var(--ion-color-white);\n    border-radius: 10px;\n    box-shadow: 0px 3px 8px #dbdbdb;\n    border: 1px solid var(--ion-border-color); }\n  ion-content .salonList-row .salon-section .salon-image {\n      height: 100px;\n      width: 100%;\n      border-radius: 10px 10px 0px 0px; }\n  ion-content .salonList-row .salon-section .salon-image img {\n        border-radius: 10px 10px 0px 0px;\n        height: 100%;\n        width: 100%; }\n  ion-content .salonList-row .salon-section .salon-detail {\n      padding-left: 14px;\n      display: flow-root; }\n  ion-content .salonList-row .salon-section .salon-detail .salon-name {\n        font-size: 15px;\n        font-family: \"tofini_medium\";\n        margin-top: 6px;\n        margin-bottom: 5px;\n        padding-right: 11px; }\n  ion-content .salonList-row .salon-section .salon-detail .salon-name .start-span {\n          font-size: 13px;\n          color: var(--ion-color-simpleDark); }\n  ion-content .salonList-row .salon-section .salon-detail .salon-name .start-span img {\n            margin-right: 5px; }\n  ion-content .salonList-row .salon-section .salon-detail .salon-address {\n        font-size: 12px;\n        font-family: \"tofini_regular\";\n        margin-top: 0px;\n        margin-bottom: 1px;\n        color: var(--ion-color-simpleDark);\n        padding-right: 11px; }\n  ion-content .salonList-row .salon-section .salon-detail .btn-book {\n        font-size: 13px;\n        font-family: \"tofini_medium\";\n        text-transform: initial;\n        --box-shadow: none;\n        height: 30px;\n        margin: 0px;\n        --border-radius: 8px 0px 8px 0px;\n        --padding-start: 17px;\n        --padding-end: 15px; }\n  ion-content ion-fab ion-fab-button ion-icon {\n  font-size: 28px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9EOlxcaW9uaWMgNFxcQm9vayBBIFBvaW50L3NyY1xcYXBwXFxwYWdlc1xcaG9tZVxcaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrREFBa0QsRUFBQTtFQURwRDtJQUdJLGtCQUFrQjtJQUNsQiwwQ0FBYSxFQUFBO0VBSmpCO0lBT0ksZUFBZTtJQUNmLDRCQUE0QjtJQUM1QixrQ0FBa0M7SUFDbEMsa0JBQWtCO0lBQ2xCLGdCQUFnQixFQUFBO0VBWHBCO0lBY0ksZUFBZTtJQUNmLDRCQUE0QjtJQUM1Qiw2QkFBNkIsRUFBQTtFQWhCakM7TUFrQk0sY0FBYztNQUNkLGNBQWM7TUFDZCxtQkFBbUI7TUFDbkIsaUJBQWlCLEVBQUE7RUFyQnZCO01Bd0JNLFlBQVk7TUFDWixXQUFXO01BQ1gsbUJBQW1CO01BQ25CLGdCQUFnQixFQUFBO0VBM0J0QjtJQStCSSxlQUFlO0lBQ2YsNkJBQTZCO0lBQzdCLHNDQUFlLEVBQUE7RUFqQ25CO0lBb0NJLFlBQVk7SUFDWix5Q0FBYTtJQUNiLGVBQWU7SUFDZiw2QkFBNkIsRUFBQTtFQXZDakM7TUF5Q00sd0JBQXdCLEVBQUE7RUF6QzlCO0lBNkNJLGdDQUFRO0lBQ1IsZUFBZTtJQUNmLDBCQUEwQjtJQUMxQix1QkFBdUI7SUFDdkIsc0NBQWUsRUFBQTtFQUduQjtFQUVJLGtCQUFrQjtFQUNsQixTQUFTO0VBQ1QsVUFBVTtFQUNWLG9DQUFvQztFQUNwQyxtQkFBbUI7RUFDbkIsaUJBQWlCO0VBQ2pCLHNDQUEwQixFQUFBO0VBUjlCO0lBVU0sZUFBZSxFQUFBO0VBVnJCO0lBYU0sYUFBYTtJQUNiLHdCQUF3QjtJQUN4QixzQ0FBMEIsRUFBQTtFQWZoQztJQWtCTSxhQUFhLEVBQUE7RUFsQm5CO0VBc0JJLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsU0FBUztFQUNULGtCQUFrQixFQUFBO0VBekJ0QjtJQTJCTSxhQUFhLEVBQUE7RUEzQm5CO0lBOEJNLGtDQUFrQztJQUNsQyxtQkFBbUI7SUFDbkIsK0JBQStCO0lBQy9CLHlDQUF5QyxFQUFBO0VBakMvQztNQW1DUSxhQUFhO01BQ2IsV0FBVztNQUNYLGdDQUFnQyxFQUFBO0VBckN4QztRQXVDVSxnQ0FBZ0M7UUFDaEMsWUFBWTtRQUNaLFdBQVcsRUFBQTtFQXpDckI7TUE2Q1Esa0JBQWtCO01BQ2xCLGtCQUFrQixFQUFBO0VBOUMxQjtRQWdEVSxlQUFlO1FBQ2YsNEJBQTRCO1FBQzVCLGVBQWU7UUFDZixrQkFBa0I7UUFDbEIsbUJBQW1CLEVBQUE7RUFwRDdCO1VBc0RZLGVBQWU7VUFDZixrQ0FBa0MsRUFBQTtFQXZEOUM7WUF5RGMsaUJBQWlCLEVBQUE7RUF6RC9CO1FBOERVLGVBQWU7UUFDZiw2QkFBNkI7UUFDN0IsZUFBZTtRQUNmLGtCQUFrQjtRQUNsQixrQ0FBa0M7UUFDbEMsbUJBQW1CLEVBQUE7RUFuRTdCO1FBc0VVLGVBQWU7UUFDZiw0QkFBNEI7UUFDNUIsdUJBQXVCO1FBQ3ZCLGtCQUFhO1FBQ2IsWUFBWTtRQUNaLFdBQVc7UUFDWCxnQ0FBZ0I7UUFDaEIscUJBQWdCO1FBQ2hCLG1CQUFjLEVBQUE7RUE5RXhCO0VBc0ZRLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBib3JkZXItYm90dG9tOiAwLjVweCBzb2xpZCB2YXIoLS1pb24tYm9yZGVyLWNvbG9yKTtcclxuICBpb24tdG9vbGJhciB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci13aGl0ZS1saWdodCk7XHJcbiAgfVxyXG4gIC5sb2NhdGlvbi1sYWJlbCB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfbWVkaXVtXCI7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNpbXBsZURhcmspO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogM3B4O1xyXG4gICAgbWFyZ2luLXRvcDogMTJweDtcclxuICB9XHJcbiAgLnNlbGVjdC1sb2NhdGlvbiB7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfbWVkaXVtXCI7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWJsYWNrKTtcclxuICAgIC5waW4ge1xyXG4gICAgICBoZWlnaHQ6IDE3LjdweDtcclxuICAgICAgd2lkdGg6IDEyLjQycHg7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IC0zcHg7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgfVxyXG4gICAgLmRpcmVjdGlvbiB7XHJcbiAgICAgIGhlaWdodDogMTRweDtcclxuICAgICAgd2lkdGg6IDE0cHg7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IC0zcHg7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiA3cHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5idG4tZmlsdGVyIHtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgLS1yaXBwbGUtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgfVxyXG4gIGlvbi1zZWFyY2hiYXIge1xyXG4gICAgcGFkZGluZzogMHB4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tc2VhcmNoQmFjay1jb2xvcik7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfcmVndWxhclwiO1xyXG4gICAgLnNlYXJjaGJhci1jbGVhci1pY29uIHtcclxuICAgICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gIH1cclxuICAuYnRuLWNhbmNlbCB7XHJcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itb3JhbmdlKTtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9ib2xkXCI7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcclxuICAgIC0tcmlwcGxlLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLm1hcC1idXR0b24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxOHB4O1xyXG4gICAgcmlnaHQ6IDhweDtcclxuICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC44KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZDtcclxuICAgIGJvcmRlci1jb2xvcjogcmdiYSgjOTc5Nzk3LCAwLjIpO1xyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICB9XHJcbiAgICAuaW5mby1pY29uIHtcclxuICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkO1xyXG4gICAgICBib3JkZXItY29sb3I6IHJnYmEoIzk3OTc5NywgMC4yKTtcclxuICAgIH1cclxuICAgIC5sb2NhdGlvbiB7XHJcbiAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5zYWxvbkxpc3Qtcm93IHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogOHB4O1xyXG4gICAgbGVmdDogNXB4O1xyXG4gICAgb3ZlcmZsb3cteDogc2Nyb2xsO1xyXG4gICAgJjo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgfVxyXG4gICAgLnNhbG9uLXNlY3Rpb24ge1xyXG4gICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICBib3gtc2hhZG93OiAwcHggM3B4IDhweCAjZGJkYmRiO1xyXG4gICAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tYm9yZGVyLWNvbG9yKTtcclxuICAgICAgLnNhbG9uLWltYWdlIHtcclxuICAgICAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwcHggMHB4O1xyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDBweDtcclxuICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuc2Fsb24tZGV0YWlsIHtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDE0cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxvdy1yb290O1xyXG4gICAgICAgIC5zYWxvbi1uYW1lIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiBcInRvZmluaV9tZWRpdW1cIjtcclxuICAgICAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDExcHg7XHJcbiAgICAgICAgICAuc3RhcnQtc3BhbiB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zaW1wbGVEYXJrKTtcclxuICAgICAgICAgICAgaW1nIHtcclxuICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAuc2Fsb24tYWRkcmVzcyB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfcmVndWxhclwiO1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogMXB4O1xyXG4gICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zaW1wbGVEYXJrKTtcclxuICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDExcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5idG4tYm9vayB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogXCJ0b2ZpbmlfbWVkaXVtXCI7XHJcbiAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcclxuICAgICAgICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgIGhlaWdodDogMzBweDtcclxuICAgICAgICAgIG1hcmdpbjogMHB4O1xyXG4gICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA4cHggMHB4IDhweCAwcHg7XHJcbiAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDE3cHg7XHJcbiAgICAgICAgICAtLXBhZGRpbmctZW5kOiAxNXB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBpb24tZmFiIHtcclxuICAgIGlvbi1mYWItYnV0dG9uIHtcclxuICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/home/home.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _filter_filter_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../filter/filter.page */ "./src/app/pages/filter/filter.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _enable_location_enable_location_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../enable-location/enable-location.page */ "./src/app/pages/enable-location/enable-location.page.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");





var HomePage = /** @class */ (function () {
    function HomePage(modalController, navCtrl) {
        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.salonList = [
            {
                name: 'RedBox Barber',
                image: '../../../assets/images/General/Rectangle.png',
                address: '288 McClure Court, Arkansas',
                star: '4.0'
            },
            {
                name: 'Looks Unisex Salon',
                image: '../../../assets/images/General/Rectangle.png',
                address: '288 McClure Court, Arkansas',
                star: '4.0'
            }
        ];
        this.enableLocation();
    }
    HomePage.prototype.enableLocation = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _enable_location_enable_location_page__WEBPACK_IMPORTED_MODULE_3__["EnableLocationPage"],
                            cssClass: 'enableLocation-modal'
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    HomePage.prototype.ngOnInit = function () {
        this.initMap();
    };
    HomePage.prototype.initMap = function () {
        var _this = this;
        var markerData = [
            { lat: 22.3, lng: 70.8, text: 'Looks Unisex Salon' },
            { lat: 22.3, lng: 70.81, text: 'Beauty Plus Spa' },
            { lat: 22.31, lng: 70.8, text: 'RedBox Barber' },
            { lat: 22.33, lng: 70.81, text: 'Divine Salon' }
        ];
        var latLng = new google.maps.LatLng(22.3, 70.8);
        var mapoption = {
            center: latLng,
            zoom: 15,
            streetViewControl: false,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        this.map = new google.maps.Map(this.mapElement.nativeElement, mapoption);
        var markerIcon = {
            url: '../../../assets/images/near-by/pin-image.png',
            labelOrigin: new google.maps.Point(25, 63),
            scaledSize: new google.maps.Size(56, 64)
        };
        markerData.forEach(function (element, index) {
            var marker = new google.maps.Marker({
                position: new google.maps.LatLng(element.lat, element.lng),
                map: _this.map,
                icon: markerIcon,
                label: {
                    text: element.text,
                    fontSize: '12px',
                    fontFamily: 'tofini_medium',
                    width: '30px'
                }
            });
        });
    };
    HomePage.prototype.bookSalon = function (event) {
        event.stopPropagation();
        this.navCtrl.navigateForward('/select-service');
    };
    HomePage.prototype.salonDetail = function (event) {
        event.stopPropagation();
        this.navCtrl.navigateForward('/salon-detail');
    };
    HomePage.prototype.searchCancel = function () {
        this.searchText = '';
    };
    HomePage.prototype.openFilter = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _filter_filter_page__WEBPACK_IMPORTED_MODULE_1__["FilterPage"]
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"])('map'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"])
    ], HomePage.prototype, "mapElement", void 0);
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/pages/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/pages/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-home-home-module.js.map